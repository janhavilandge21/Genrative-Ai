"""
Memory layer for multi-turn conversations.
"""

