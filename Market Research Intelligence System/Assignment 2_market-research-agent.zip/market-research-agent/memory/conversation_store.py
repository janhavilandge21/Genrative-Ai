from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

from diskcache import Cache

from config.settings import get_settings


@dataclass
class ConversationState:
    # Store last extracted entity identifiers/names for follow-up resolution.
    last_company_names: list[str]
    last_technology_titles: list[str]
    last_industries: list[str]
    last_countries: list[str]
    last_question_norm: str | None = None


def _get_cache() -> Cache:
    settings = get_settings()
    return Cache(str(settings.cache_dir / "conversation"))


_CACHE: Cache | None = None


def get_conversation_cache() -> Cache:
    global _CACHE
    if _CACHE is None:
        _CACHE = _get_cache()
    return _CACHE


def get_state(conversation_id: str) -> ConversationState:
    key = f"conv:{conversation_id}"
    cached = get_conversation_cache().get(key, default=None)
    if cached is None:
        return ConversationState(
            last_company_names=[],
            last_technology_titles=[],
            last_industries=[],
            last_countries=[],
            last_question_norm=None,
        )
    return ConversationState(**cached)


def set_state(conversation_id: str, state: ConversationState) -> None:
    key = f"conv:{conversation_id}"
    settings = get_settings()
    # TTL: auto-expire old contexts to reduce state drift.
    get_conversation_cache().set(key, asdict(state), expire=settings.cache_ttl)

