"""
frontend/app.py
Advanced Streamlit Frontend for Market Research Agent.

Features:
  - Research query input with example prompts
  - Live agent pipeline visualizer (5 steps with timing)
  - Company profiles with relevance scores
  - Technology cards with maturity/novelty badges
  - Intent parsing breakdown
  - Analytics dashboard
  - Export to JSON
"""

import streamlit as st
import requests
import json
import time
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime

API_BASE = "http://localhost:8001/api/v1"

st.set_page_config(
    page_title="Market Research Agent",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap');

:root {
    --bg:#040609;--s1:#080d16;--s2:#0e1523;--s3:#172035;--s4:#1f2d47;
    --accent:#22d3ee;--accent2:#818cf8;--green:#10b981;--yellow:#f59e0b;
    --red:#f43f5e;--purple:#a855f7;--text:#e2e8f0;--muted:#64748b;--border:#1e293b;
}
html,body,[data-testid="stAppViewContainer"]{background:var(--bg)!important;color:var(--text);font-family:'Inter',sans-serif;}
[data-testid="stSidebar"]{background:var(--s1)!important;border-right:1px solid var(--border);}
[data-testid="stSidebar"] *{color:var(--text)!important;}
.stTabs [data-baseweb="tab-list"]{background:var(--s2)!important;border-radius:12px;padding:4px;gap:4px;}
.stTabs [data-baseweb="tab"]{color:var(--muted)!important;font-weight:500;border-radius:8px!important;}
.stTabs [aria-selected="true"]{background:var(--s4)!important;color:var(--text)!important;}
.stButton>button{background:linear-gradient(135deg,#06b6d4,#6366f1)!important;color:white!important;border:none!important;border-radius:8px!important;font-weight:700!important;font-size:1rem!important;}
.stTextArea textarea,.stTextInput input{background:var(--s2)!important;color:var(--text)!important;border:1px solid var(--border)!important;border-radius:8px!important;font-family:'Inter',sans-serif!important;}

/* Pipeline step */
.step-box{background:var(--s2);border:1px solid var(--border);border-radius:10px;padding:14px 18px;margin:6px 0;}
.step-done{border-left:4px solid var(--green);}
.step-skip{border-left:4px solid var(--muted);}
.step-fail{border-left:4px solid var(--red);}
.step-name{font-weight:700;font-size:0.95rem;letter-spacing:0.03em;}
.step-note{font-size:0.78rem;color:var(--muted);margin-top:4px;font-family:'JetBrains Mono',monospace;}

/* Company card */
.company-card{background:var(--s2);border:1px solid var(--border);border-left:4px solid var(--accent);border-radius:12px;padding:18px 20px;margin:10px 0;}
.company-name{font-weight:800;font-size:1.05rem;color:var(--text);}
.company-meta{color:var(--muted);font-size:0.82rem;margin:4px 0 10px 0;}

/* Tech card */
.tech-card{background:var(--s2);border:1px solid var(--border);border-left:4px solid var(--purple);border-radius:12px;padding:16px 18px;margin:8px 0;}
.tech-title{font-weight:700;font-size:0.95rem;color:var(--text);}

/* Score bar */
.score-bar-bg{background:var(--s3);border-radius:4px;height:8px;width:100%;margin:6px 0;}

/* Badges */
.badge{display:inline-block;border-radius:6px;padding:2px 10px;font-size:0.74rem;font-family:'JetBrains Mono',monospace;font-weight:600;margin:2px 3px;}
.badge-comm{background:#052e16;color:#4ade80;border:1px solid #14532d;}
.badge-proto{background:#422006;color:#fb923c;border:1px solid #7c2d12;}
.badge-dev{background:#1e1b4b;color:#a5b4fc;border:1px solid #3730a3;}
.badge-high{background:#2e1065;color:#c084fc;border:1px solid #6b21a8;}
.badge-med{background:#422006;color:#fbbf24;border:1px solid #78350f;}
.badge-low{background:#1e2a3d;color:#64748b;border:1px solid #334155;}
.badge-ind{background:#0c1a2e;color:#22d3ee;border:1px solid #155e75;}
.badge-geo{background:#052e16;color:#4ade80;border:1px solid #14532d;}
.badge-type{background:#1e1b4b;color:#818cf8;border:1px solid #3730a3;}

/* Intent card */
.intent-card{background:var(--s2);border:1px solid var(--border);border-radius:10px;padding:14px 18px;margin:6px 0;}

/* Metric tile */
.metric-tile{background:var(--s2);border:1px solid var(--border);border-radius:12px;padding:16px;text-align:center;}
.metric-value{font-size:1.9rem;font-weight:800;background:linear-gradient(135deg,#22d3ee,#818cf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.metric-label{font-size:0.75rem;color:var(--muted);margin-top:4px;text-transform:uppercase;letter-spacing:.1em;}

/* Hero */
.hero-title{font-size:2.3rem;font-weight:800;background:linear-gradient(135deg,#22d3ee,#818cf8,#10b981);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}

/* Justification box */
.just-box{background:var(--s3);border:1px solid var(--border);border-radius:8px;padding:10px 14px;font-size:0.82rem;color:var(--muted);line-height:1.6;margin-top:8px;}

/* Signal chip */
.signal{display:inline-block;background:var(--s3);border:1px solid var(--border);border-radius:20px;padding:2px 10px;font-size:0.72rem;color:var(--muted);margin:2px 2px;}
</style>
""", unsafe_allow_html=True)

# ── API helpers ────────────────────────────────────────────────────────────────
def api_get(path, params=None):
    try:
        r = requests.get(f"{API_BASE}{path}", params=params, timeout=10)
        r.raise_for_status(); return r.json()
    except Exception as e:
        return {"error": str(e)}

def api_post(path, payload):
    try:
        r = requests.post(f"{API_BASE}{path}", json=payload, timeout=120)
        r.raise_for_status(); return r.json()
    except requests.exceptions.ConnectionError:
        return {"error": "backend_offline"}
    except Exception as e:
        return {"error": str(e)}

def maturity_badge(m):
    m_lower = m.lower()
    if "comm" in m_lower: return f'<span class="badge badge-comm">⚙️ {m}</span>'
    if "proto" in m_lower: return f'<span class="badge badge-proto">🔬 {m}</span>'
    return f'<span class="badge badge-dev">📐 {m}</span>'

def novelty_badge(n):
    n_lower = n.lower()
    if "high" in n_lower: return f'<span class="badge badge-high">✨ {n}</span>'
    if "med" in n_lower:  return f'<span class="badge badge-med">⚡ {n}</span>'
    return f'<span class="badge badge-low">◽ {n}</span>'

def score_bar(score, color="#22d3ee"):
    pct = int(score * 100)
    return (
        f'<div style="display:flex;align-items:center;gap:8px">'
        f'<div style="flex:1;background:#1e2a3d;border-radius:4px;height:8px">'
        f'<div style="width:{pct}%;height:100%;background:{color};border-radius:4px"></div>'
        f'</div>'
        f'<span style="font-size:0.82rem;color:#e2e8f0;font-weight:600;min-width:36px">{pct}%</span>'
        f'</div>'
    )

# ── Session state ──────────────────────────────────────────────────────────────
for k, v in [("result", None), ("history", [])]:
    if k not in st.session_state: st.session_state[k] = v

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<p style="font-size:1.2rem;font-weight:800;background:linear-gradient(135deg,#22d3ee,#818cf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent">🔬 Market Research Agent</p>', unsafe_allow_html=True)
    st.markdown('<p style="color:#64748b;font-size:0.78rem">Agentic AI · Assignment 2</p>', unsafe_allow_html=True)
    st.divider()

    # Health
    health = api_get("/health")
    if health and not health.get("error"):
        st.success("✅ Agent Online")
        c1, c2 = st.columns(2)
        c1.metric("Companies", health.get("companies_count", 0))
        c2.metric("Technologies", health.get("technologies_count", 0))
        groq = health.get("groq_configured", False)
        faiss = health.get("faiss_ready", False)
        st.markdown(f"FAISS: {'✅' if faiss else '⏳'} | Groq: {'✅' if groq else '⚠️'}")
    else:
        st.error("❌ Agent Offline\n`uvicorn main:app --port 8001`")

    st.divider()

    # Max results
    max_results = st.slider("Max Companies", 1, 30, 10)

    st.divider()

    # LLM stats
    if health and not health.get("error"):
        usage = health.get("llm_usage_stats", {})
        st.markdown("**LLM Usage** (synthesis only)")
        st.markdown(f"Calls: **{usage.get('total_calls', 0)}**")
        st.markdown(f"Tokens: **{usage.get('total_tokens', 0):,}**")
        st.markdown(f"Policy: LLM used for exec summary only")

    st.divider()
    if st.button("🗑 Clear History", use_container_width=True):
        st.session_state.result  = None
        st.session_state.history = []
        st.rerun()

# ── Main ───────────────────────────────────────────────────────────────────────
st.markdown('<h1 class="hero-title">🔬 Market Research Agent</h1>', unsafe_allow_html=True)
st.markdown('<p style="color:#64748b;font-size:0.92rem">Agentic 5-step pipeline: <b style="color:#22d3ee">PARSE</b> → <b style="color:#22d3ee">DISCOVER</b> → <b style="color:#22d3ee">SEARCH</b> → <b style="color:#22d3ee">VALIDATE</b> → <b style="color:#22d3ee">SYNTHESIZE</b></p>', unsafe_allow_html=True)

tab_research, tab_pipeline, tab_companies, tab_techs, tab_analytics = st.tabs([
    "🔍 Research", "⚙️ Pipeline", "🏢 Companies", "💡 Technologies", "📊 Analytics"
])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1: RESEARCH
# ══════════════════════════════════════════════════════════════════════════════
with tab_research:
    st.markdown("**Enter a natural language market research query:**")

    EXAMPLES = [
        "Industrial AI startups working on predictive maintenance in oil & gas",
        "Semiconductor companies developing smart sensors in Asia",
        "Large enterprises focused on automation and Industry 4.0",
        "Companies with commercialized IoT technologies",
        "Analog semiconductor companies in USA and Europe with high novelty technologies",
        "Companies working on connected machinery and zero-defect manufacturing",
    ]

    ex_cols = st.columns(3)
    for i, ex in enumerate(EXAMPLES[:3]):
        if ex_cols[i].button(ex[:42]+"…", key=f"e{i}", use_container_width=True):
            st.session_state["_pq"] = ex
    ex_cols2 = st.columns(3)
    for i, ex in enumerate(EXAMPLES[3:]):
        if ex_cols2[i].button(ex[:42]+"…", key=f"e2{i}", use_container_width=True):
            st.session_state["_pq"] = ex

    query = st.text_area(
        "Research query:",
        value=st.session_state.pop("_pq", ""),
        height=90,
        placeholder="e.g. 'Industrial AI startups working on predictive maintenance'",
        label_visibility="collapsed",
    )

    if st.button("🚀 Run Market Research Agent", use_container_width=True, type="primary"):
        if not query.strip():
            st.warning("Please enter a research query.")
        elif not health or health.get("error"):
            st.error("API is offline. Please start the backend.")
        else:
            with st.spinner("🤖 Agent running 5-step pipeline..."):
                result = api_post("/research", {"query": query, "max_results": max_results})

            if result.get("error") == "backend_offline":
                st.error("Cannot connect to backend. Run: `python -m uvicorn main:app --reload --port 8001`")
            elif result.get("error"):
                st.error(f"Agent error: {result['error']}")
            else:
                st.session_state.result = result
                st.session_state.history.append({
                    "query":    query,
                    "ts":       datetime.now().strftime("%H:%M:%S"),
                    "companies":len(result.get("companies", [])),
                    "techs":    len(result.get("technologies", [])),
                    "latency":  result.get("total_latency_ms", 0),
                    "llm":      result.get("llm_used", False),
                })
                st.rerun()

    if st.session_state.result:
        res = st.session_state.result

        # ── Summary metrics
        st.divider()
        m1, m2, m3, m4, m5 = st.columns(5)
        m1.markdown(f'<div class="metric-tile"><div class="metric-value">{len(res.get("companies",[]))}</div><div class="metric-label">Companies</div></div>', unsafe_allow_html=True)
        m2.markdown(f'<div class="metric-tile"><div class="metric-value">{len(res.get("technologies",[]))}</div><div class="metric-label">Technologies</div></div>', unsafe_allow_html=True)
        m3.markdown(f'<div class="metric-tile"><div class="metric-value">{res.get("total_latency_ms",0):.0f}ms</div><div class="metric-label">Total Time</div></div>', unsafe_allow_html=True)
        cands = res.get("total_candidates_found", {})
        m4.markdown(f'<div class="metric-tile"><div class="metric-value">{cands.get("companies",0)}</div><div class="metric-label">Candidates Found</div></div>', unsafe_allow_html=True)
        llm_icon = "✅" if res.get("llm_used") else "⚡"
        m5.markdown(f'<div class="metric-tile"><div class="metric-value">{llm_icon}</div><div class="metric-label">LLM {"Used" if res.get("llm_used") else "Saved"}</div></div>', unsafe_allow_html=True)

        # ── Intent breakdown
        intent = res.get("parsed_intent", {})
        st.markdown('<p style="font-weight:700;font-size:0.78rem;text-transform:uppercase;letter-spacing:.1em;color:#22d3ee;margin-top:16px">🧠 Parsed Intent</p>', unsafe_allow_html=True)
        intent_html = ""
        for ind in intent.get("industries", []):
            intent_html += f'<span class="badge badge-ind">🏭 {ind}</span>'
        for geo in intent.get("geographies", []):
            intent_html += f'<span class="badge badge-geo">🌍 {geo}</span>'
        for ct in intent.get("company_types", []):
            intent_html += f'<span class="badge badge-type">🏢 {ct}</span>'
        for tech in intent.get("technologies", [])[:4]:
            intent_html += f'<span class="badge badge-high">⚙️ {tech}</span>'
        if intent.get("maturity"):
            intent_html += maturity_badge(intent["maturity"])
        if intent.get("novelty"):
            intent_html += novelty_badge(intent["novelty"])
        if intent_html:
            st.markdown(f'<div class="intent-card">{intent_html}</div>', unsafe_allow_html=True)

        # ── Executive summary
        if res.get("executive_summary"):
            st.markdown('<p style="font-weight:700;font-size:0.78rem;text-transform:uppercase;letter-spacing:.1em;color:#22d3ee;margin-top:16px">📋 Executive Summary</p>', unsafe_allow_html=True)
            st.info(res["executive_summary"])

        # ── Download
        st.download_button(
            "⬇️ Download Full Research Report (JSON)",
            data=json.dumps(res, indent=2, default=str),
            file_name=f"research_{int(time.time())}.json",
            mime="application/json",
        )

# ══════════════════════════════════════════════════════════════════════════════
# TAB 2: PIPELINE VISUALIZER
# ══════════════════════════════════════════════════════════════════════════════
with tab_pipeline:
    if not st.session_state.result:
        st.info("Run a research query first to see the agent pipeline.")
    else:
        res = st.session_state.result
        st.markdown(f"**Query:** `{res['query'][:100]}`")
        st.divider()

        steps = res.get("agent_steps", [])
        total_ms = res.get("total_latency_ms", 0)

        # Timeline chart
        if steps:
            step_names   = [s["name"] for s in steps]
            step_latency = [s["latency_ms"] for s in steps]
            colors = {
                "PARSE":     "#22d3ee",
                "DISCOVER":  "#818cf8",
                "SEARCH":    "#10b981",
                "VALIDATE":  "#f59e0b",
                "SYNTHESIZE":"#f43f5e",
            }
            bar_colors = [colors.get(n, "#64748b") for n in step_names]

            fig = go.Figure(go.Bar(
                x=step_latency, y=step_names, orientation="h",
                marker_color=bar_colors,
                text=[f"{ms:.1f}ms" for ms in step_latency],
                textposition="outside", textfont=dict(color="#e2e8f0"),
            ))
            fig.update_layout(
                paper_bgcolor="#0e1523", plot_bgcolor="#0e1523",
                font=dict(color="#e2e8f0"),
                xaxis=dict(title="Latency (ms)", gridcolor="#1e293b"),
                yaxis=dict(autorange="reversed"),
                height=260, margin=dict(l=10,r=80,t=20,b=40),
                title=dict(text=f"Agent Pipeline — Total: {total_ms:.0f}ms", font=dict(color="#94a3b8", size=13)),
            )
            st.plotly_chart(fig, use_container_width=True)

        # Step cards
        STEP_ICONS = {
            "PARSE":"🧠","DISCOVER":"🔍","SEARCH":"📡","VALIDATE":"✅","SYNTHESIZE":"📝"
        }
        STEP_DESC = {
            "PARSE":    "NL query → structured constraints (0 LLM, pure rule-based)",
            "DISCOVER": "Multi-signal digital footprint discovery from dataset",
            "SEARCH":   "FAISS semantic search for additional coverage",
            "VALIDATE": "Relevance scoring: industry + geo + tech + semantic",
            "SYNTHESIZE":"Structured output + LLM executive summary (only LLM call)",
        }

        for s in steps:
            status_cls = {"completed":"step-done","skipped":"step-skip","failed":"step-fail"}.get(s["status"],"step-skip")
            status_icon = {"completed":"✅","skipped":"⏭","failed":"❌"}.get(s["status"],"⏭")
            icon = STEP_ICONS.get(s["name"],"⚙️")
            desc = STEP_DESC.get(s["name"],"")

            st.markdown(
                f'<div class="step-box {status_cls}">'
                f'<div style="display:flex;justify-content:space-between;align-items:center">'
                f'<span class="step-name">{icon} {s["name"]} {status_icon}</span>'
                f'<span style="font-family:monospace;color:#22d3ee;font-size:0.85rem">{s["latency_ms"]}ms | {s["output_count"]} items</span>'
                f'</div>'
                f'<div class="step-note">{desc}</div>'
                f'<div class="step-note" style="color:#334155">{s["notes"][:120]}</div>'
                f'</div>',
                unsafe_allow_html=True,
            )

        # Intent detail
        intent = res.get("parsed_intent", {})
        st.markdown('<p style="font-weight:700;color:#818cf8;margin-top:16px">Extracted Intent</p>', unsafe_allow_html=True)
        intent_df = {
            "Dimension": ["Industries", "Technologies", "Company Types", "Geographies", "Maturity", "Novelty"],
            "Extracted": [
                ", ".join(intent.get("industries", [])) or "—",
                ", ".join(intent.get("technologies", [])[:3]) or "—",
                ", ".join(intent.get("company_types", [])) or "—",
                ", ".join(intent.get("geographies", [])) or "—",
                intent.get("maturity") or "—",
                intent.get("novelty") or "—",
            ]
        }
        st.dataframe(pd.DataFrame(intent_df), use_container_width=True, hide_index=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3: COMPANIES
# ══════════════════════════════════════════════════════════════════════════════
with tab_companies:
    if not st.session_state.result:
        # Fallback: show dataset browser
        st.markdown("Run a research query to see matched companies, or browse the dataset:")
        data = api_get("/companies", {"limit": 20})
        if data and not data.get("error"):
            for c in data.get("companies", []):
                st.markdown(
                    f'<div class="company-card">'
                    f'<span class="company-name">{c["name"]}</span>'
                    f'<div class="company-meta">🏢 {c["type"]} | 📍 {c["hq"]} | 🌍 {", ".join(c["countries"][:3])}</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )
    else:
        res = st.session_state.result
        companies = res.get("companies", [])

        if not companies:
            st.warning("No companies matched your research criteria. Try a broader query.")
        else:
            st.markdown(f"**{len(companies)} companies matched** — ranked by relevance score")

            # Score distribution chart
            df_c = pd.DataFrame([{
                "Name":  c["name"][:25],
                "Score": c["relevance_score"],
                "Type":  c["company_type"],
            } for c in companies])

            fig = px.bar(
                df_c, x="Score", y="Name", orientation="h",
                color="Score", color_continuous_scale=[[0,"#1e293b"],[0.5,"#22d3ee"],[1,"#818cf8"]],
                text=df_c["Score"].apply(lambda x: f"{x*100:.0f}%"),
            )
            fig.update_layout(
                paper_bgcolor="#0e1523", plot_bgcolor="#0e1523",
                font=dict(color="#e2e8f0"), height=max(200, len(companies)*36),
                xaxis=dict(range=[0,1.1], gridcolor="#1e293b"),
                yaxis=dict(autorange="reversed"),
                margin=dict(l=10,r=80,t=20,b=20),
                coloraxis_showscale=False,
                title=dict(text="Company Relevance Scores", font=dict(color="#94a3b8",size=13)),
            )
            fig.update_traces(textfont_color="#e2e8f0", textposition="outside")
            st.plotly_chart(fig, use_container_width=True)

            # Company cards
            for i, c in enumerate(companies):
                rank_icon = ["🥇","🥈","🥉"][i] if i < 3 else f"#{i+1}"
                inds_html = "".join(f'<span class="badge badge-ind">{ind[:30]}</span>' for ind in c.get("industries", [])[:2])
                geo_html  = "".join(f'<span class="badge badge-geo">{co}</span>'   for co in c.get("countries", [])[:3])
                sig_html  = "".join(f'<span class="signal">{s}</span>' for s in c.get("discovery_signals",[])[:3])
                tech_html = "".join(
                    f'<span class="badge badge-dev">{t.get("title","")[:25]}</span>'
                    for t in c.get("technologies", [])[:3]
                )

                with st.expander(
                    f"{rank_icon} **{c['name']}** | Score: {c['relevance_score']*100:.0f}% | {c['company_type']}",
                    expanded=(i < 2)
                ):
                    col1, col2 = st.columns([2, 1])
                    with col1:
                        st.markdown(f"**📌 {c.get('headquarters','N/A')}** &nbsp;|&nbsp; **🌐** [{c.get('website','—')}]({c.get('website','#')})")
                        st.markdown(inds_html + geo_html, unsafe_allow_html=True)
                        if c.get("description"):
                            st.markdown(f"*{c['description'][:300]}...*")
                        if tech_html:
                            st.markdown(f"**Technologies:** {tech_html}", unsafe_allow_html=True)

                        # Matched criteria
                        if c.get("matched_criteria"):
                            st.markdown("**Why matched:**")
                            for mc in c["matched_criteria"][:4]:
                                st.markdown(f"  ✅ {mc}")

                        # Discovery signals
                        if sig_html:
                            st.markdown(f"**Discovery signals:** {sig_html}", unsafe_allow_html=True)

                    with col2:
                        st.markdown("**Relevance Score**")
                        st.markdown(score_bar(c["relevance_score"]), unsafe_allow_html=True)
                        if c.get("revenue"):
                            st.markdown(f"**Revenue:** {c['revenue']}")
                        # Justification
                        st.markdown(f'<div class="just-box">{c.get("justification","")}</div>', unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 4: TECHNOLOGIES
# ══════════════════════════════════════════════════════════════════════════════
with tab_techs:
    if not st.session_state.result:
        st.markdown("Run a research query to see matched technologies, or browse:")
        data = api_get("/technologies")
        if data and not data.get("error"):
            for t in data.get("technologies", []):
                st.markdown(
                    f'<div class="tech-card">'
                    f'<span class="tech-title">{t["title"]}</span>'
                    f'<div style="color:#64748b;font-size:0.8rem;margin-top:4px">'
                    f'🏭 {t["company"]} &nbsp;|&nbsp; {maturity_badge(t["maturity"])} {novelty_badge(t["novelty"])}</div>'
                    f'</div>',
                    unsafe_allow_html=True,
                )
    else:
        res = st.session_state.result
        technologies = res.get("technologies", [])

        if not technologies:
            st.warning("No technologies matched your research criteria.")
        else:
            st.markdown(f"**{len(technologies)} technologies matched** — ranked by relevance score")

            # Maturity + Novelty charts
            ch1, ch2 = st.columns(2)
            df_t = pd.DataFrame([{
                "Title":    t["title"][:30],
                "Maturity": t["maturity"],
                "Novelty":  t["novelty"],
                "Score":    t["relevance_score"],
                "Company":  t["company"],
            } for t in technologies])

            with ch1:
                if "Maturity" in df_t.columns:
                    mat_counts = df_t["Maturity"].value_counts()
                    fig_m = go.Figure(go.Pie(
                        labels=mat_counts.index, values=mat_counts.values,
                        hole=0.55,
                        marker_colors=["#10b981","#f59e0b","#818cf8"],
                        textfont=dict(color="#e2e8f0"),
                    ))
                    fig_m.update_layout(
                        paper_bgcolor="#0e1523", font=dict(color="#e2e8f0"),
                        height=220, margin=dict(l=10,r=10,t=20,b=10),
                        title=dict(text="Maturity", font=dict(size=12, color="#94a3b8")),
                        legend=dict(bgcolor="#0e1523"),
                    )
                    st.plotly_chart(fig_m, use_container_width=True)

            with ch2:
                if "Novelty" in df_t.columns:
                    nov_counts = df_t["Novelty"].value_counts()
                    fig_n = go.Figure(go.Bar(
                        x=nov_counts.values, y=nov_counts.index, orientation="h",
                        marker_color=["#a855f7","#f59e0b","#64748b"],
                        text=nov_counts.values, textfont=dict(color="#e2e8f0"),
                    ))
                    fig_n.update_layout(
                        paper_bgcolor="#0e1523", plot_bgcolor="#0e1523",
                        font=dict(color="#e2e8f0"), height=220,
                        margin=dict(l=10,r=50,t=20,b=10),
                        title=dict(text="Novelty", font=dict(size=12, color="#94a3b8")),
                        xaxis=dict(gridcolor="#1e293b"), yaxis=dict(color="#e2e8f0"),
                    )
                    st.plotly_chart(fig_n, use_container_width=True)

            # Tech cards
            col_a, col_b = st.columns(2)
            for i, t in enumerate(technologies):
                col = col_a if i % 2 == 0 else col_b
                apps_html = "".join(f"• {a[:60]}<br>" for a in t.get("applications",[])[:3])
                highlights_html = "".join(f"• {h[:70]}<br>" for h in t.get("key_highlights",[])[:3])

                with col.expander(
                    f"{'🥇' if i==0 else '🔬'} **{t['title']}** — {t['maturity']} | {t['novelty']} novelty",
                    expanded=(i < 2),
                ):
                    st.markdown(maturity_badge(t["maturity"]) + " " + novelty_badge(t["novelty"]), unsafe_allow_html=True)
                    st.markdown(f"**Company:** {t['company']} &nbsp;|&nbsp; **Category:** {t.get('category','')}")
                    if t.get("description"):
                        st.markdown(f"*{t['description'][:250]}*")
                    if apps_html:
                        st.markdown(f"**Applications:**\n{apps_html}", unsafe_allow_html=True)
                    if highlights_html:
                        st.markdown(f"**Key Highlights:**\n{highlights_html}", unsafe_allow_html=True)
                    st.markdown("**Relevance Score:**")
                    st.markdown(score_bar(t["relevance_score"], "#818cf8"), unsafe_allow_html=True)
                    st.markdown(f'<div class="just-box">{t.get("justification","")}</div>', unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 5: ANALYTICS
# ══════════════════════════════════════════════════════════════════════════════
with tab_analytics:
    if not st.session_state.history:
        st.info("Run research queries to see analytics.")
    else:
        history = st.session_state.history
        df_h = pd.DataFrame(history)

        m1, m2, m3, m4 = st.columns(4)
        m1.markdown(f'<div class="metric-tile"><div class="metric-value">{len(history)}</div><div class="metric-label">Queries Run</div></div>', unsafe_allow_html=True)
        avg_comp = sum(h["companies"] for h in history) / len(history)
        m2.markdown(f'<div class="metric-tile"><div class="metric-value">{avg_comp:.1f}</div><div class="metric-label">Avg Companies</div></div>', unsafe_allow_html=True)
        avg_lat = sum(h["latency"] for h in history) / len(history)
        m3.markdown(f'<div class="metric-tile"><div class="metric-value">{avg_lat:.0f}ms</div><div class="metric-label">Avg Latency</div></div>', unsafe_allow_html=True)
        llm_count = sum(1 for h in history if h["llm"])
        m4.markdown(f'<div class="metric-tile"><div class="metric-value">{llm_count}</div><div class="metric-label">LLM Calls</div></div>', unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # Latency over time
        df_h["Q#"] = range(1, len(df_h)+1)
        fig_lat = go.Figure(go.Scatter(
            x=df_h["Q#"], y=df_h["latency"],
            mode="lines+markers",
            line=dict(color="#22d3ee", width=2),
            marker=dict(color=["#f43f5e" if h["llm"] else "#22d3ee" for h in history], size=10),
        ))
        fig_lat.update_layout(
            paper_bgcolor="#0e1523", plot_bgcolor="#0e1523",
            font=dict(color="#e2e8f0"),
            xaxis=dict(title="Query #", gridcolor="#1e293b"),
            yaxis=dict(title="Latency (ms)", gridcolor="#1e293b"),
            height=250, margin=dict(l=40,r=20,t=20,b=40),
            title=dict(text="Research Latency Over Time (🔴=LLM, 🔵=No LLM)", font=dict(color="#94a3b8",size=12)),
        )
        st.plotly_chart(fig_lat, use_container_width=True)

        # Companies found per query
        fig_comp = go.Figure(go.Bar(
            x=df_h["Q#"],
            y=df_h["companies"],
            marker_color="#818cf8",
            text=df_h["companies"], textfont=dict(color="#e2e8f0"),
        ))
        fig_comp.update_layout(
            paper_bgcolor="#0e1523", plot_bgcolor="#0e1523",
            font=dict(color="#e2e8f0"),
            xaxis=dict(title="Query #", gridcolor="#1e293b"),
            yaxis=dict(title="Companies Matched", gridcolor="#1e293b"),
            height=220, margin=dict(l=40,r=20,t=20,b=40),
            title=dict(text="Companies Matched Per Query", font=dict(color="#94a3b8",size=12)),
        )
        st.plotly_chart(fig_comp, use_container_width=True)

        # History log
        st.markdown("**Query History**")
        df_display = df_h[["ts","query","companies","techs","latency","llm"]].copy()
        df_display.columns = ["Time","Query","Companies","Techs","Latency(ms)","LLM Used"]
        df_display["LLM Used"] = df_display["LLM Used"].map({True:"✅ Yes", False:"⚡ No"})
        df_display["Query"] = df_display["Query"].str[:55] + "…"
        st.dataframe(df_display, use_container_width=True, hide_index=True)

    # Architecture reference
    st.markdown("---")
    st.markdown("**Agent Architecture**")
    st.markdown("""
    <div style="background:#0e1523;border:1px solid #1e293b;border-radius:12px;padding:18px;font-size:0.83rem;color:#64748b">
    <pre style="color:#94a3b8;margin:0">
Query → [PARSE: IntentParser] → structured constraints (0 LLM, 100% rule-based)
      → [DISCOVER: DigitalFootprintDiscovery] → multi-signal company discovery
           · FAISS semantic search
           · Industry text matching
           · Technology keyword matching
           · Geographic filtering
           · Focus keyword scanning
      → [SEARCH: FAISSEngine] → semantic tech retrieval
      → [VALIDATE: RelevanceValidator] → score each result:
           · Industry alignment (+0.35)
           · Geographic match (+0.20)
           · Technology capability (+0.25)
           · Company type match (+0.10)
           · Semantic similarity (+0.10)
      → [SYNTHESIZE: LLMSynthesizer] → ONLY LLM call: executive summary
    </pre>
    <p style="margin-top:12px;color:#334155">⚡ 80%+ of computation is deterministic. LLM called only once per query for synthesis.</p>
    </div>
    """, unsafe_allow_html=True)
