@echo off
echo =========================================
echo   Market Research Agent
echo   Starting Backend + Frontend
echo =========================================
echo.
echo [1/3] Installing dependencies...
pip install -r requirements.txt -q

echo.
echo [2/3] Starting FastAPI backend on http://localhost:8001 ...
start "Market Research Agent API" cmd /k "python -m uvicorn main:app --reload --port 8001"

echo.
echo [3/3] Waiting 15 seconds for FAISS index to build...
timeout /t 15 /nobreak > nul

echo Starting Streamlit frontend on http://localhost:8502 ...
start "Market Research Frontend" cmd /k "python -m streamlit run frontend/app.py --server.port 8502"

echo.
echo =========================================
echo   RUNNING!
echo   Backend:  http://localhost:8001/docs
echo   Frontend: http://localhost:8502
echo =========================================
pause
