import time

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger

from app.routes.query import router as query_router
from config.settings import get_settings
from retrieval.data_store import get_data_store


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(
        title="Market Research Agent",
        version="1.0.0",
        description="Agentic hybrid retrieval + validation system for market research.",
    )

    # CORS for frontend (local development).
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    app.include_router(query_router)

    @app.middleware("http")
    async def timing_middleware(request: Request, call_next):
        start = time.perf_counter()
        try:
            response = await call_next(request)
            return response
        finally:
            elapsed_ms = (time.perf_counter() - start) * 1000
            logger.info(
                "request path={path} method={method} status={status} latency_ms={latency_ms:.2f}",
                path=str(request.url.path),
                method=request.method,
                status=getattr(locals().get("response", None), "status_code", None),
                latency_ms=elapsed_ms,
            )

    @app.on_event("startup")
    def on_startup() -> None:
        # Load data once for low-latency requests.
        try:
            get_data_store()
        except Exception as e:
            logger.error("Startup failed to load datastore: {}", e)
            # Let the server start; the first request will surface the error.

    return app


app = create_app()

