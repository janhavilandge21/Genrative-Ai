import time

from fastapi import APIRouter, HTTPException

from app.schemas.query import QueryRequest
from app.schemas.response import QueryResponse
from services.orchestrator.hybrid_orchestrator import HybridQueryOrchestrator


router = APIRouter(prefix="/v1", tags=["query"])
orchestrator = HybridQueryOrchestrator()


@router.get("/health")
def health() -> dict:
    return {"status": "ok"}


@router.post("/query", response_model=QueryResponse)
def query(request: QueryRequest) -> QueryResponse:
    start = time.perf_counter()
    try:
        res = orchestrator.handle(request)
        res.latency_ms = (time.perf_counter() - start) * 1000
        return res
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal error: {e}")

