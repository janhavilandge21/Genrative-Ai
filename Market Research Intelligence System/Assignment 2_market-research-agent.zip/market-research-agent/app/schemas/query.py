from pydantic import BaseModel, Field


class QueryRequest(BaseModel):
    conversation_id: str = Field(..., min_length=1, max_length=128)
    question: str = Field(..., min_length=1, max_length=2000)
    top_k: int = Field(10, ge=1, le=50)
    # Optional hints to keep latency predictable.
    enable_semantic: bool = Field(True, description="Allow FAISS semantic retrieval")
    enable_llm: bool = Field(True, description="Allow LLM for explanation/summarization")


class QueryMetadata(BaseModel):
    query_type: str
    llm_used: bool
    llm_reason: str | None = None
    confidence: str
    latency_ms: float

