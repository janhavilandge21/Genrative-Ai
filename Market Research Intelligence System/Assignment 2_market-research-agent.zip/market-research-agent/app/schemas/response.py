from typing import Any

from pydantic import BaseModel, Field


class DataRef(BaseModel):
    type: str = Field(..., description="company|technology")
    id: str
    name: str | None = None


class QueryResponse(BaseModel):
    answer: str
    source: list[str] = Field(default_factory=list)
    data_used: list[DataRef] = Field(default_factory=list)
    confidence: str = Field(..., description="high|medium|low")
    llm_used: bool

    # Diagnostics for assignment evaluation / frontend.
    query_type: str
    latency_ms: float
    llm_reason: str | None = None

    # Extra structured information for frontend without bloating answer.
    data_used_raw: list[dict[str, Any]] = Field(default_factory=list)

