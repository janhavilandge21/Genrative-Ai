"""
Pydantic request/response schemas.
"""

