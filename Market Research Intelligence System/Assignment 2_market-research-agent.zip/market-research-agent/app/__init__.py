"""
FastAPI application package.
"""

