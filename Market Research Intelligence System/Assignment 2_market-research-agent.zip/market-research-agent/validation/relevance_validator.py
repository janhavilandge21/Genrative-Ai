"""
validation/relevance_validator.py
Validates that discovered companies and technologies are truly relevant.
Uses deterministic scoring rules first; LLM only for borderline cases.

Assignment requirement:
  - Validate industry/domain match
  - Confirm technology capability alignment
  - Ensure geographic alignment
  - Avoid weak keyword matches
  - Provide justification for inclusion
"""

import time
from dataclasses import dataclass, field
from loguru import logger
from agent.intent_parser import ParsedIntent
from core.data_loader import get_data_store


@dataclass
class ValidationResult:
    entity_id:   str
    entity_name: str
    entity_type: str        # "company" | "technology"
    is_relevant: bool
    relevance_score: float  # 0.0 – 1.0
    justification: str
    matched_criteria: list[str] = field(default_factory=list)
    failed_criteria:  list[str] = field(default_factory=list)
    confidence:  str = "high"  # high | medium | low


class RelevanceValidator:
    """
    Multi-criterion relevance validation.
    Returns scored ValidationResult for each candidate.
    """

    INCLUDE_THRESHOLD = 0.30   # Min score to include
    LLM_BORDER_LOW    = 0.25   # Below this → reject without LLM
    LLM_BORDER_HIGH   = 0.55   # Above this → accept without LLM

    def validate_company(self, company: dict, intent: ParsedIntent) -> ValidationResult:
        score = 0.0
        matched, failed = [], []

        # ── 1. Industry alignment (weight: 0.35) ─────────────────────────────
        if intent.industries:
            company_industries = " ".join(str(i) for i in company.get("industries", [])).lower()
            company_full       = company.get("full_text", "").lower()
            matched_inds = [
                ind for ind in intent.industries
                if ind.lower() in company_industries or ind.lower() in company_full
            ]
            if matched_inds:
                score += 0.35
                matched.append(f"Industry match: {', '.join(matched_inds)}")
            else:
                failed.append(f"Industry mismatch: expected {intent.industries}")
        else:
            score += 0.20  # Partial credit when no industry constraint
            matched.append("No industry constraint — partial credit")

        # ── 2. Geographic alignment (weight: 0.20) ────────────────────────────
        if intent.geographies:
            company_countries = [c.lower() for c in company.get("countries", [])]
            company_full      = company.get("full_text", "").lower()
            matched_geos = [
                geo for geo in intent.geographies
                if any(geo.lower() in cc for cc in company_countries)
                or geo.lower() in company_full
            ]
            if matched_geos:
                score += 0.20
                matched.append(f"Geographic match: {', '.join(matched_geos)}")
            else:
                failed.append(f"Geographic mismatch: expected {intent.geographies}")
        else:
            score += 0.10
            matched.append("No geographic constraint")

        # ── 3. Technology capability (weight: 0.25) ───────────────────────────
        if intent.technologies or intent.focus_keywords:
            company_full = company.get("full_text", "").lower()
            company_desc = company.get("description", "").lower()

            # Check technology keywords
            matched_techs = [
                tech for tech in intent.technologies
                if tech.lower() in company_full
            ]
            # Check focus keywords
            matched_focus = [
                kw for kw in intent.focus_keywords[:8]
                if kw.lower() in company_full or kw.lower() in company_desc
            ]
            total_matched = len(matched_techs) + len(matched_focus)
            total_expected = len(intent.technologies) + min(len(intent.focus_keywords), 5)

            if total_expected > 0:
                tech_score = min(total_matched / total_expected, 1.0) * 0.25
                score += tech_score
                if matched_techs:
                    matched.append(f"Technology match: {', '.join(matched_techs[:3])}")
                if matched_focus:
                    matched.append(f"Focus match: {', '.join(matched_focus[:3])}")
                if total_matched == 0:
                    failed.append("No technology/focus keyword match in company data")
            else:
                score += 0.15

        # ── 4. Company type alignment (weight: 0.10) ──────────────────────────
        if intent.company_types:
            ctype = company.get("company_type", "").lower()
            matched_types = [ct for ct in intent.company_types if ct.lower() in ctype]
            if matched_types:
                score += 0.10
                matched.append(f"Company type match: {', '.join(matched_types)}")
            else:
                failed.append(f"Company type mismatch: expected {intent.company_types}")
        else:
            score += 0.05

        # ── 5. Semantic score bonus (weight: 0.10) ────────────────────────────
        sem_score = company.get("semantic_score", 0.0)
        if sem_score > 0.4:
            score += 0.10
            matched.append(f"High semantic similarity: {sem_score:.3f}")
        elif sem_score > 0.25:
            score += 0.05
            matched.append(f"Moderate semantic similarity: {sem_score:.3f}")

        # ── Build justification ───────────────────────────────────────────────
        score = round(min(score, 1.0), 4)
        is_relevant = score >= self.INCLUDE_THRESHOLD

        if is_relevant:
            justification = (
                f"Company qualifies with relevance score {score:.2f}. "
                f"Key matches: {'; '.join(matched[:3])}."
            )
        else:
            justification = (
                f"Company excluded — relevance score {score:.2f} below threshold. "
                f"Issues: {'; '.join(failed[:3])}."
            )

        confidence = "high" if score > self.LLM_BORDER_HIGH or score < self.LLM_BORDER_LOW else "medium"

        return ValidationResult(
            entity_id=company["id"],
            entity_name=company["name"],
            entity_type="company",
            is_relevant=is_relevant,
            relevance_score=score,
            justification=justification,
            matched_criteria=matched,
            failed_criteria=failed,
            confidence=confidence,
        )

    def validate_technology(self, tech: dict, intent: ParsedIntent, company: dict | None = None) -> ValidationResult:
        score = 0.0
        matched, failed = [], []

        tech_full = tech.get("full_text", "").lower()
        tech_desc = tech.get("description", "").lower()

        # ── 1. Technology keyword match (0.40) ────────────────────────────────
        if intent.technologies or intent.focus_keywords:
            all_kws = intent.technologies + intent.focus_keywords[:5]
            matched_kws = [kw for kw in all_kws if kw.lower() in tech_full]
            if matched_kws:
                kw_score = min(len(matched_kws) / max(len(all_kws), 1), 1.0) * 0.40
                score += kw_score
                matched.append(f"Technology keyword match: {', '.join(matched_kws[:3])}")
            else:
                failed.append("No technology keyword found in technology profile")
        else:
            score += 0.20

        # ── 2. Industry relevance (0.25) ──────────────────────────────────────
        if intent.industries:
            matched_inds = [ind for ind in intent.industries if ind.lower() in tech_full]
            if matched_inds:
                score += 0.25
                matched.append(f"Industry relevance: {', '.join(matched_inds)}")
            else:
                failed.append(f"Industry not found in tech profile")
        else:
            score += 0.15

        # ── 3. Maturity filter (0.15) ─────────────────────────────────────────
        if intent.maturity:
            if intent.maturity.lower() in tech.get("maturity_lower", ""):
                score += 0.15
                matched.append(f"Maturity match: {tech['maturity']}")
            else:
                failed.append(f"Maturity mismatch: {tech['maturity']} vs {intent.maturity}")
        else:
            score += 0.08

        # ── 4. Novelty filter (0.10) ──────────────────────────────────────────
        if intent.novelty:
            if intent.novelty.lower() in tech.get("novelty_lower", ""):
                score += 0.10
                matched.append(f"Novelty match: {tech['novelty']}")
            else:
                failed.append(f"Novelty mismatch")
        else:
            score += 0.05

        # ── 5. Semantic score bonus (0.10) ────────────────────────────────────
        sem = tech.get("semantic_score", 0)
        if sem > 0.4:
            score += 0.10; matched.append(f"High semantic score: {sem:.3f}")
        elif sem > 0.25:
            score += 0.05; matched.append(f"Moderate semantic score: {sem:.3f}")

        score      = round(min(score, 1.0), 4)
        is_relevant = score >= self.INCLUDE_THRESHOLD

        justification = (
            f"Technology {'qualifies' if is_relevant else 'excluded'} with score {score:.2f}. "
            + (f"Matches: {'; '.join(matched[:3])}." if matched else "")
            + (f" Issues: {'; '.join(failed[:2])}." if failed else "")
        )
        confidence = "high" if score > self.LLM_BORDER_HIGH or score < self.LLM_BORDER_LOW else "medium"

        return ValidationResult(
            entity_id=tech["id"],
            entity_name=tech["title"],
            entity_type="technology",
            is_relevant=is_relevant,
            relevance_score=score,
            justification=justification,
            matched_criteria=matched,
            failed_criteria=failed,
            confidence=confidence,
        )

    def batch_validate_companies(self, companies: list[dict], intent: ParsedIntent, top_n: int = 10) -> list[dict]:
        """Validate and rank a list of companies. Returns top_n relevant ones."""
        results = []
        for c in companies:
            vr = self.validate_company(c, intent)
            if vr.is_relevant:
                results.append({
                    "company":          c,
                    "validation":       vr,
                    "relevance_score":  vr.relevance_score,
                    "justification":    vr.justification,
                    "matched_criteria": vr.matched_criteria,
                })

        results.sort(key=lambda x: x["relevance_score"], reverse=True)
        return results[:top_n]

    def batch_validate_technologies(self, technologies: list[dict], intent: ParsedIntent) -> list[dict]:
        """Validate and rank a list of technologies."""
        results = []
        for t in technologies:
            vr = self.validate_technology(t, intent)
            if vr.is_relevant:
                results.append({
                    "technology":       t,
                    "validation":       vr,
                    "relevance_score":  vr.relevance_score,
                    "justification":    vr.justification,
                    "matched_criteria": vr.matched_criteria,
                })
        results.sort(key=lambda x: x["relevance_score"], reverse=True)
        return results
