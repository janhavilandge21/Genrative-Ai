"""
retrieval/data_store.py
Loads, normalizes, and indexes company + technology data.
Provides the in-memory data layer used by all tools.
Handles the triple-quoted JSON fix from the raw dataset.
"""

import json
from pathlib import Path
from functools import lru_cache
from loguru import logger
from config.settings import get_settings


# ── JSON parser (handles triple-quoted strings in raw data) ───────────────────
def _fix_triple_quotes(content: str) -> str:
    result = []
    i = 0
    n = len(content)
    while i < n:
        if content[i:i+3] == '"""':
            end = content.find('"""', i + 3)
            if end == -1:
                result.append('"'); i += 3
            else:
                inner = content[i+3:end]
                inner = (inner.replace('\\', '\\\\').replace('"', '\\"')
                         .replace('\n', '\\n').replace('\r', '\\r')
                         .replace('\t', '\\t'))
                result.append('"' + inner + '"')
                i = end + 3
        else:
            result.append(content[i])
            i += 1
    return ''.join(result)


def _load_json(path: Path) -> list:
    with open(path, encoding='utf-8') as f:
        content = f.read()
    return json.loads(_fix_triple_quotes(content))


# ── Field extractors ──────────────────────────────────────────────────────────
def _first(lst, key="content", default="") -> str:
    if not lst: return default
    if isinstance(lst, list) and lst:
        item = lst[0]
        if isinstance(item, dict):
            val = item.get(key, default)
            if isinstance(val, list): return ", ".join(str(x) for x in val)
            return str(val).strip()
    return default


def _all_contents(lst, key="content") -> list[str]:
    if not lst or not isinstance(lst, list): return []
    out = []
    for item in lst:
        if isinstance(item, dict):
            val = item.get(key, "")
            if isinstance(val, list):
                out.extend([str(x) for x in val if x])
            elif val:
                out.append(str(val))
    return [x.strip() for x in out if x.strip()]


def _all_tags(lst) -> list[str]:
    """Extract tags from nested list structure."""
    tags = []
    for item in (lst or []):
        if isinstance(item, dict):
            val = item.get("content", [])
            if isinstance(val, list):
                tags.extend([str(t) for t in val if t])
            elif val:
                tags.append(str(val))
    return [t.lower().strip() for t in tags if t.strip()]


# ── Company normalizer ────────────────────────────────────────────────────────
def normalize_company(raw: dict) -> dict:
    doc_id = raw.get("_id", "")
    src    = raw.get("_source", {})
    bi_list = src.get("basic_information", [])
    bi = bi_list[0] if isinstance(bi_list, list) and bi_list else (bi_list or {})

    name = _first(bi.get("name_suggestion", [])) or _first(bi.get("name", []))
    company_id  = src.get("id") or doc_id
    website     = _first(bi.get("website", []))
    description = _first(bi.get("description", []))
    company_type= _first(bi.get("company_type", []))
    domain      = _first(bi.get("domain", []))
    ticker      = _first(bi.get("company_ticker_symbol", []))
    employees   = _first(bi.get("total_employee", []))
    founded     = _first(bi.get("founded_year", []))

    # Industries — flatten nested list
    industries = _all_contents(bi.get("industries", []))

    # Focus areas & tags
    focus_areas, all_tags_list = [], []
    for fa in (bi.get("focusarea", []) or []):
        if isinstance(fa, dict):
            focus_areas.extend(fa.get("topic", []))
            all_tags_list.extend(fa.get("tags", []))
            all_tags_list.extend(fa.get("sub_topic", []))

    # Geography
    addresses, hq, all_countries = [], "", []
    for addr in (bi.get("address_info", []) or []):
        if isinstance(addr, dict):
            country = addr.get("country", "")
            city    = addr.get("city", "")
            if addr.get("headquarter", "").lower() == "yes":
                hq = f"{city}, {country}".strip(", ")
            if country:
                all_countries.append(country)

    # Financial
    fi_list = src.get("financial_information", [])
    fi = fi_list[0] if isinstance(fi_list, list) and fi_list else {}
    prof = fi.get("profitability_performance", {}) if isinstance(fi, dict) else {}
    revenue    = _first(prof.get("revenue", []) if isinstance(prof, dict) else [])
    net_margin = _first(prof.get("net_margin", []) if isinstance(prof, dict) else [])

    # Activities
    activities = []
    for act in (src.get("activity_information", []) or []):
        if isinstance(act, dict) and act.get("description"):
            activities.append({
                "title":       act.get("title", ""),
                "description": act.get("description", "")[:300],
                "type":        act.get("type", ""),
                "date":        act.get("published_date", ""),
            })

    # Competitors
    competitors = []
    for c in (bi.get("competitor_info", []) or []):
        if isinstance(c, dict) and c.get("name"):
            competitors.append(c["name"])

    # Build searchable text blob
    tags_lower = [t.lower().strip() for t in all_tags_list if t.strip()]
    search_text = " ".join([
        name, description, company_type,
        " ".join(industries), " ".join(focus_areas),
        " ".join(tags_lower), " ".join(all_countries),
    ]).lower()

    return {
        "id":           company_id,
        "name":         name,
        "name_lower":   name.lower(),
        "website":      website,
        "domain":       domain,
        "ticker":       ticker,
        "company_type": company_type,
        "description":  description,
        "industries":   industries,
        "focus_areas":  focus_areas,
        "tags":         tags_lower,
        "headquarters": hq,
        "countries":    list(set(all_countries)),
        "employees":    employees,
        "founded_year": founded,
        "revenue":      revenue,
        "net_margin":   net_margin,
        "activities":   activities[:5],
        "competitors":  competitors[:5],
        "search_text":  search_text,
    }


# ── Technology normalizer ─────────────────────────────────────────────────────
def normalize_technology(raw: dict) -> dict:
    doc_id = raw.get("_id", "")
    src    = raw.get("_source", {})

    title       = _first(src.get("title", []))
    description = _first(src.get("description", []))
    principle   = _first(src.get("principle", []))
    maturity    = _first(src.get("maturity", []))
    novelty     = _first(src.get("novelty", []))
    category    = _first(src.get("category", []))
    innovation  = _first(src.get("innovation", []))

    company_info = src.get("company", {}) or {}
    company_id   = company_info.get("companyid", "")
    company_name = company_info.get("name", "")

    applications = _all_contents(src.get("applications", []))
    highlights   = []
    for kh in (src.get("key_highlights", []) or []):
        if isinstance(kh, dict):
            items = kh.get("content", [])
            if isinstance(items, list):
                highlights.extend([str(x) for x in items if x])
            elif items:
                highlights.append(str(items))

    diff_factors = _all_contents(src.get("differentiating_factor", []))
    comp_adv     = _all_contents(src.get("competition_advantage", []))
    tags         = _all_tags(src.get("tags", []))
    patents      = _first(src.get("noofpatents", []))

    search_text = " ".join([
        title, description, principle, category, innovation,
        maturity, novelty, " ".join(applications),
        " ".join(highlights), " ".join(tags), company_name,
    ]).lower()

    tech_id = src.get("id", doc_id)

    return {
        "id":           tech_id,
        "title":        title,
        "title_lower":  title.lower(),
        "description":  description,
        "principle":    principle,
        "maturity":     maturity,
        "maturity_lower": maturity.lower(),
        "novelty":      novelty,
        "novelty_lower":novelty.lower(),
        "category":     category,
        "innovation":   innovation,
        "company_id":   company_id,
        "company_name": company_name,
        "applications": applications,
        "highlights":   highlights,
        "diff_factors": diff_factors,
        "comp_adv":     comp_adv,
        "tags":         tags,
        "patents":      patents,
        "search_text":  search_text,
    }


# ── DataStore ─────────────────────────────────────────────────────────────────
class DataStore:
    """
    In-memory data layer. Single source of truth for all tools.
    Builds multi-index at load time for O(1) lookups.
    """

    def __init__(self):
        self.companies:    list[dict] = []
        self.technologies: list[dict] = []
        # Fast-access indexes
        self._by_company_id:  dict[str, dict]       = {}
        self._by_name_lower:  dict[str, dict]       = {}
        self._tech_by_id:     dict[str, dict]       = {}
        self._tech_by_title_lower: dict[str, dict] = {}
        self._techs_by_company: dict[str, list[dict]] = {}
        # Inverted indexes for O(1) filtering
        self._by_industry:  dict[str, list[dict]] = {}
        self._by_country:   dict[str, list[dict]] = {}
        self._by_tag:       dict[str, list[dict]] = {}
        self._techs_by_category: dict[str, list[dict]] = {}
        self._by_tech_tag:       dict[str, list[dict]] = {}
        self._loaded = False

    def load(self):
        if self._loaded: return
        settings = get_settings()
        logger.info("DataStore: loading company & technology data...")
        if not settings.companies_file.exists():
            raise FileNotFoundError(
                f"Missing dataset file: {settings.companies_file}\n"
                f"Expected JSON list of company documents."
            )
        if not settings.technologies_file.exists():
            raise FileNotFoundError(
                f"Missing dataset file: {settings.technologies_file}\n"
                f"Expected JSON list of technology documents."
            )

        raw_c = _load_json(settings.companies_file)
        raw_t = _load_json(settings.technologies_file)

        self.companies    = [normalize_company(c) for c in raw_c]
        self.technologies = [normalize_technology(t) for t in raw_t]

        # Build company indexes
        for c in self.companies:
            self._by_company_id[c["id"]] = c
            self._by_name_lower[c["name_lower"]] = c
            for ind in c["industries"]:
                self._by_industry.setdefault(ind.lower(), []).append(c)
            for country in c["countries"]:
                self._by_country.setdefault(country.lower(), []).append(c)
            for tag in c["tags"]:
                self._by_tag.setdefault(tag, []).append(c)

        # Build tech indexes
        for t in self.technologies:
            self._tech_by_id[t["id"]] = t
            if t.get("title_lower"):
                self._tech_by_title_lower[t["title_lower"]] = t
            cat = (t.get("category") or "").lower().strip()
            if cat:
                self._techs_by_category.setdefault(cat, []).append(t)
            cid = t["company_id"]
            if cid:
                self._techs_by_company.setdefault(cid, []).append(t)
            for tag in (t.get("tags") or []):
                if tag:
                    self._by_tech_tag.setdefault(str(tag).lower().strip(), []).append(t)

        self._loaded = True
        logger.info(f"DataStore: {len(self.companies)} companies, {len(self.technologies)} technologies loaded")

    # ── Query methods ─────────────────────────────────────────────────────────
    def get_company(self, company_id: str) -> dict | None:
        return self._by_company_id.get(company_id)

    def get_by_name(self, name: str) -> dict | None:
        nl = name.lower().strip()
        if nl in self._by_name_lower: return self._by_name_lower[nl]
        for key, c in self._by_name_lower.items():
            if nl in key or key in nl: return c
        return None

    def get_techs_for_company(self, company_id: str) -> list[dict]:
        return self._techs_by_company.get(company_id, [])

    def get_technology_by_name(self, name: str) -> dict | None:
        nl = name.lower().strip()
        if not nl:
            return None
        if nl in self._tech_by_title_lower:
            return self._tech_by_title_lower[nl]
        # Fallback partial match for short names.
        for key, t in self._tech_by_title_lower.items():
            if nl in key or key in nl:
                return t
        return None

    def get_technologies_by_category(self, category_kw: str) -> list[dict]:
        kw = (category_kw or "").lower().strip()
        if not kw:
            return []
        matches: list[dict] = []
        seen: set[str] = set()
        for cat_key, techs in self._techs_by_category.items():
            if kw in cat_key or cat_key in kw:
                for t in techs:
                    if t["id"] not in seen:
                        seen.add(t["id"])
                        matches.append(t)
        return matches

    def search_companies_by_keyword(self, keywords: list[str]) -> list[dict]:
        """Full-text keyword search over normalized search_text blobs."""
        results = {}
        for kw in keywords:
            kw_lower = kw.lower().strip()
            for c in self.companies:
                if kw_lower in c["search_text"]:
                    cid = c["id"]
                    if cid not in results:
                        results[cid] = {"company": c, "score": 0}
                    results[cid]["score"] += 1
        return sorted(results.values(), key=lambda x: x["score"], reverse=True)

    def search_companies_by_industry(self, industry_kw: str) -> list[dict]:
        """Industry-based company search using inverted index."""
        kw = industry_kw.lower().strip()
        matches = []
        seen = set()
        for ind_key, companies in self._by_industry.items():
            if kw in ind_key or ind_key in kw:
                for c in companies:
                    if c["id"] not in seen:
                        seen.add(c["id"])
                        matches.append(c)
        return matches

    def filter_by_country(self, companies: list[dict], country_kw: str) -> list[dict]:
        """Filter to companies with presence in specified geography."""
        kw = country_kw.lower().strip()
        return [c for c in companies
                if any(kw in ctry.lower() for ctry in c["countries"])]

    def search_technologies_by_keyword(self, keywords: list[str]) -> list[dict]:
        """Full-text keyword search over technology search_text."""
        results = {}
        for kw in keywords:
            kw_lower = kw.lower().strip()
            for t in self.technologies:
                if kw_lower in t["search_text"]:
                    tid = t["id"]
                    if tid not in results:
                        results[tid] = {"tech": t, "score": 0}
                    results[tid]["score"] += 1
        return sorted(results.values(), key=lambda x: x["score"], reverse=True)

    def get_all_industries(self) -> list[str]:
        return sorted(self._by_industry.keys())

    def get_all_countries(self) -> list[str]:
        return sorted(self._by_country.keys())

    def get_all_technology_categories(self) -> list[str]:
        return sorted(self._techs_by_category.keys())

    def get_all_technology_tags(self) -> list[str]:
        return sorted(self._by_tech_tag.keys())


_store: DataStore | None = None

def get_data_store() -> DataStore:
    global _store
    if _store is None:
        _store = DataStore()
        _store.load()
    return _store
