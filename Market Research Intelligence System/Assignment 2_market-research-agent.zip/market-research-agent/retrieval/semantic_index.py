"""
retrieval/semantic_index.py
FAISS-based semantic search for companies and technologies.
Used when keyword search is insufficient for ambiguous queries.
"""

import pickle
import numpy as np
from pathlib import Path
from loguru import logger
from config.settings import get_settings
from retrieval.data_store import get_data_store


class SemanticIndex:
    """
    FAISS flat index for cosine-similarity search.
    Built once at startup, persisted to disk for fast reload.
    """

    def __init__(self):
        self.settings = get_settings()
        self._model   = None
        self._comp_index = self._tech_index = None
        self._comp_docs: list[dict] = []
        self._tech_docs: list[dict] = []
        self._ready = False

    def _get_model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            logger.info(f"Loading embedding model: {self.settings.embedding_model}")
            self._model = SentenceTransformer(self.settings.embedding_model, device="cpu")
        return self._model

    def build_or_load(self):
        idx_dir   = self.settings.faiss_dir
        comp_path = idx_dir / "comp_semantic.pkl"
        tech_path = idx_dir / "tech_semantic.pkl"

        if comp_path.exists() and tech_path.exists():
            logger.info("Loading semantic indexes from disk...")
            with open(comp_path, "rb") as f:
                d = pickle.load(f)
                self._comp_index = d["index"]
                self._comp_docs  = d["docs"]
            with open(tech_path, "rb") as f:
                d = pickle.load(f)
                self._tech_index = d["index"]
                self._tech_docs  = d["docs"]
            self._ready = True
            return

        self._build()

    def _build(self):
        import faiss
        store = get_data_store()
        model = self._get_model()
        idx_dir = self.settings.faiss_dir
        logger.info("Building FAISS semantic indexes...")

        self._comp_docs = store.companies
        c_vecs = model.encode(
            [c["search_text"][:512] for c in self._comp_docs],
            normalize_embeddings=True, show_progress_bar=False, batch_size=32,
        ).astype(np.float32)
        dim = c_vecs.shape[1]
        self._comp_index = faiss.IndexFlatIP(dim)
        self._comp_index.add(c_vecs)

        self._tech_docs = store.technologies
        t_vecs = model.encode(
            [t["search_text"][:512] for t in self._tech_docs],
            normalize_embeddings=True, show_progress_bar=False, batch_size=32,
        ).astype(np.float32)
        self._tech_index = faiss.IndexFlatIP(dim)
        self._tech_index.add(t_vecs)

        with open(idx_dir / "comp_semantic.pkl", "wb") as f:
            pickle.dump({"index": self._comp_index, "docs": self._comp_docs}, f)
        with open(idx_dir / "tech_semantic.pkl", "wb") as f:
            pickle.dump({"index": self._tech_index, "docs": self._tech_docs}, f)

        self._ready = True
        logger.info(f"FAISS built: {len(self._comp_docs)} companies, {len(self._tech_docs)} techs")

    def search_companies(self, query: str, k: int = 15) -> list[tuple[dict, float]]:
        if not self._ready: self.build_or_load()
        return self._search(query, self._comp_index, self._comp_docs, k)

    def search_technologies(self, query: str, k: int = 5) -> list[tuple[dict, float]]:
        if not self._ready: self.build_or_load()
        return self._search(query, self._tech_index, self._tech_docs, k)

    def _search(self, query: str, index, docs, k: int) -> list[tuple[dict, float]]:
        model = self._get_model()
        q_vec = model.encode([query], normalize_embeddings=True).astype(np.float32)
        k     = min(k, len(docs))
        scores, indices = index.search(q_vec, k)
        return [
            (docs[idx], float(score))
            for score, idx in zip(scores[0], indices[0])
            # Keep low-similarity candidates so the hybrid system can still return
            # best-effort results for out-of-distribution queries.
            if idx >= 0 and float(score) > 0.01
        ]

    def invalidate(self):
        idx_dir = self.settings.faiss_dir
        for p in [idx_dir / "comp_semantic.pkl", idx_dir / "tech_semantic.pkl"]:
            if p.exists(): p.unlink()
        self._ready = False


_index: SemanticIndex | None = None

def get_semantic_index() -> SemanticIndex:
    global _index
    if _index is None:
        _index = SemanticIndex()
    return _index
