"""
Legacy retrieval modules live here.
"""

