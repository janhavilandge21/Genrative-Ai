"""
agent/llm_synthesizer.py
LLM layer — called ONLY for summarization and explanation, never for discovery.
Uses Groq LLaMA3-70b with minimal tokens.

Assignment requirement:
  "Don't use LLM directly for company identification"
  → LLM is used ONLY at the end to explain and structure results.
"""

import os
import time
from loguru import logger
from config.settings import get_settings


SYNTHESIS_SYSTEM = """You are a market research analyst. Your job is to synthesize structured company and technology data into a clear, professional research report.

Rules:
- Base your response ONLY on the provided data
- Do not invent companies or technologies not in the data
- Be factual, concise, and professional
- Use bullet points for clarity
- Always cite specific data points (maturity, novelty, applications)"""

SYNTHESIS_TEMPLATE = """Research Query: {query}

Discovered Companies ({n_companies} found):
{companies_text}

Relevant Technologies ({n_techs} found):
{techs_text}

Write a 3-4 paragraph executive research summary covering:
1. Overview of the market segment and what was found
2. Key companies and their positioning
3. Technology landscape (maturity levels, innovations)
4. Strategic insights and opportunities

Keep it under 300 words. Be specific with data from above."""


class LLMSynthesizer:
    """
    Thin LLM wrapper for synthesis-only use.
    Every call is logged with reason and token estimate.
    """

    def __init__(self):
        self.settings  = get_settings()
        self._client   = None
        self._call_log: list[dict] = []

    def _get_client(self):
        if self._client is None:
            from groq import Groq
            key = self.settings.groq_api_key
            if not key or key == "gsk_your_groq_key_here":
                raise ValueError("GROQ_API_KEY not configured in .env")
            self._client = Groq(api_key=key)
        return self._client

    def should_use_llm(self, reason: str) -> tuple[bool, str]:
        """
        Gate function — controls when LLM is allowed.
        Only synthesis/summary tasks qualify.
        """
        ALLOWED = {"executive_summary", "technology_explanation", "opportunity_analysis"}
        if reason in ALLOWED:
            return True, f"LLM approved for: {reason}"
        return False, f"LLM not needed for: {reason} — using deterministic logic"

    def synthesize_research(self, query: str, companies: list[dict], technologies: list[dict]) -> str:
        """Generate executive summary from validated research results."""
        use_llm, reason = self.should_use_llm("executive_summary")
        if not use_llm:
            return self._deterministic_summary(query, companies, technologies)

        # Build compact context (minimize tokens)
        companies_text = "\n".join([
            f"- {c['company']['name'].title()}: {c['company'].get('company_type','')} | "
            f"Industries: {', '.join(c['company'].get('industries',[])[:2])} | "
            f"Countries: {', '.join(c['company'].get('countries',[])[:3])} | "
            f"Score: {c['relevance_score']:.2f}"
            for c in companies[:8]
        ])

        techs_text = "\n".join([
            f"- {t['technology']['title']}: Maturity={t['technology']['maturity']}, "
            f"Novelty={t['technology']['novelty']}, "
            f"Category={t['technology'].get('category','')} | "
            f"Company: {t['technology'].get('company_name','')} | "
            f"Score: {t['relevance_score']:.2f}"
            for t in technologies[:5]
        ])

        prompt = SYNTHESIS_TEMPLATE.format(
            query=query,
            n_companies=len(companies),
            n_techs=len(technologies),
            companies_text=companies_text or "None found",
            techs_text=techs_text or "None found",
        )

        return self._call(SYNTHESIS_SYSTEM, prompt, reason="executive_summary", max_tokens=400)

    def explain_technology(self, tech: dict, query: str) -> str:
        """Generate a brief explanation of why a technology is relevant."""
        use_llm, _ = self.should_use_llm("technology_explanation")
        if not use_llm or not tech:
            apps = "; ".join(tech.get("applications", [])[:2])
            return f"{tech.get('description','')[:200]}. Applications: {apps}"

        prompt = (
            f"Query context: {query}\n\n"
            f"Technology: {tech.get('title','')}\n"
            f"Description: {tech.get('description','')[:300]}\n"
            f"Applications: {'; '.join(tech.get('applications',[])[:3])}\n\n"
            f"In 2-3 sentences, explain why this technology is relevant to the query. "
            f"Be specific about capabilities. Under 80 words."
        )
        return self._call(SYNTHESIS_SYSTEM, prompt, reason="technology_explanation", max_tokens=120)

    def _deterministic_summary(self, query: str, companies: list[dict], technologies: list[dict]) -> str:
        """Fallback when LLM is unavailable — structured text without LLM."""
        n_comp = len(companies)
        n_tech = len(technologies)
        top_comp = [c["company"]["name"].title() for c in companies[:3]]
        top_tech = [t["technology"]["title"] for t in technologies[:3]]
        return (
            f"Research completed for: '{query}'\n\n"
            f"Found {n_comp} relevant companies including {', '.join(top_comp)}. "
            f"Identified {n_tech} matching technologies: {', '.join(top_tech)}. "
            f"Results are ranked by multi-signal relevance scoring combining semantic similarity, "
            f"industry match, geographic alignment, and technology capability alignment."
        )

    def _call(self, system: str, user: str, reason: str, max_tokens: int = 400) -> str:
        t0 = time.time()
        try:
            client   = self._get_client()
            response = client.chat.completions.create(
                model=self.settings.llm_model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user",   "content": user},
                ],
                temperature=0.2,
                max_tokens=max_tokens,
            )
            answer = response.choices[0].message.content.strip()
            latency = round(time.time() - t0, 3)
            in_tok  = len(system + user) // 4
            out_tok = len(answer) // 4
            self._call_log.append({"reason": reason, "in_tokens": in_tok, "out_tokens": out_tok, "latency_s": latency})
            logger.info(f"[LLM] reason={reason} | tokens={in_tok}+{out_tok} | {latency}s")
            return answer
        except Exception as e:
            logger.error(f"[LLM] failed: {e}")
            return f"[Summary unavailable: {str(e)[:80]}]"

    def get_usage_stats(self) -> dict:
        if not self._call_log:
            return {"total_calls": 0, "total_tokens": 0, "avg_latency_s": 0}
        return {
            "total_calls":  len(self._call_log),
            "total_tokens": sum(e["in_tokens"] + e["out_tokens"] for e in self._call_log),
            "avg_latency_s":round(sum(e["latency_s"] for e in self._call_log) / len(self._call_log), 3),
            "recent":       self._call_log[-3:],
        }


_synthesizer: LLMSynthesizer | None = None

def get_synthesizer() -> LLMSynthesizer:
    global _synthesizer
    if _synthesizer is None:
        _synthesizer = LLMSynthesizer()
    return _synthesizer
