"""
agent/orchestrator.py
Multi-step Agentic Orchestrator for Market Research.

Pipeline (5 steps):
  Step 1: PARSE     — Extract structured constraints from NL query
  Step 2: DISCOVER  — Digital footprint discovery (multi-signal, no LLM)
  Step 3: SEARCH    — Semantic FAISS search for additional coverage
  Step 4: VALIDATE  — Score and filter by relevance criteria
  Step 5: SYNTHESIZE— Build structured output + LLM executive summary

Each step is logged with timing for full explainability.
"""

import time
from dataclasses import dataclass, field
from loguru import logger

from agent.intent_parser import IntentParser, ParsedIntent
from agent.llm_synthesizer import get_synthesizer
from tools.search_tools import (
    tool_digital_footprint_discovery,
    tool_semantic_search_technologies,
    tool_filter_technologies,
    tool_get_company_technologies,
)
from validation.relevance_validator import RelevanceValidator
from core.data_loader import get_data_store


@dataclass
class AgentStep:
    name:       str
    status:     str       # "completed" | "skipped" | "failed"
    latency_ms: float
    output_count: int
    notes:      str = ""


@dataclass
class ResearchResult:
    query:            str
    parsed_intent:    ParsedIntent
    companies:        list[dict]
    technologies:     list[dict]
    executive_summary: str
    agent_steps:      list[AgentStep]
    total_latency_ms: float
    llm_used:         bool
    total_companies_found: int
    total_techs_found: int
    metadata:         dict = field(default_factory=dict)


class MarketResearchOrchestrator:
    """
    Agentic controller that breaks research queries into multi-step reasoning.
    Implements: task decomposition → tool usage → validation → synthesis.
    """

    def __init__(self):
        self.intent_parser = IntentParser()
        self.validator     = RelevanceValidator()
        self.store         = get_data_store()

    def run(self, query: str, max_results: int = 10) -> ResearchResult:
        """
        Execute the full 5-step research pipeline.
        Returns structured ResearchResult with full explainability.
        """
        total_start = time.time()
        steps: list[AgentStep] = []
        logger.info(f"[AGENT] Starting research: '{query[:80]}'")

        # ══════════════════════════════════════════════════════════════════════
        # STEP 1: PARSE — Extract intent from natural language query
        # ══════════════════════════════════════════════════════════════════════
        t0 = time.time()
        intent = self.intent_parser.parse(query)
        parse_ms = round((time.time() - t0) * 1000, 1)

        if not intent.is_valid:
            steps.append(AgentStep("PARSE", "failed", parse_ms, 0, intent.rejection_reason))
            return self._empty_result(query, intent, steps, total_start)

        steps.append(AgentStep(
            "PARSE", "completed", parse_ms, 1,
            f"industries={intent.industries}, tech={intent.technologies}, geo={intent.geographies}, type={intent.company_types}"
        ))
        logger.info(f"[STEP 1 PARSE] {parse_ms}ms | intent={intent}")

        # ══════════════════════════════════════════════════════════════════════
        # STEP 2: DISCOVER — Multi-signal digital footprint discovery
        # (No LLM — discovers from dataset signals)
        # ══════════════════════════════════════════════════════════════════════
        t0 = time.time()
        discovery = tool_digital_footprint_discovery(intent)
        discovered_companies = discovery["results"]
        discover_ms = round((time.time() - t0) * 1000, 1)
        steps.append(AgentStep(
            "DISCOVER", "completed", discover_ms, len(discovered_companies),
            f"signals: semantic + industry + technology + geography + keyword"
        ))
        logger.info(f"[STEP 2 DISCOVER] {discover_ms}ms | discovered={len(discovered_companies)}")

        # ══════════════════════════════════════════════════════════════════════
        # STEP 3: SEMANTIC SEARCH — FAISS for additional technology coverage
        # ══════════════════════════════════════════════════════════════════════
        t0 = time.time()
        tech_query = query  # Use full query for tech search
        if intent.technologies:
            tech_query = " ".join(intent.technologies) + " " + " ".join(intent.industries)

        tech_semantic = tool_semantic_search_technologies(tech_query, k=10)
        tech_filter   = tool_filter_technologies(intent)

        # Merge tech results
        all_techs = {}
        for t in tech_semantic["results"] + tech_filter["results"]:
            tid = t["id"]
            if tid not in all_techs:
                all_techs[tid] = t
            else:
                # Boost score if found by multiple methods
                all_techs[tid]["semantic_score"] = max(
                    all_techs[tid].get("semantic_score", 0),
                    t.get("semantic_score", 0)
                )

        all_tech_list = list(all_techs.values())
        search_ms = round((time.time() - t0) * 1000, 1)
        steps.append(AgentStep(
            "SEARCH", "completed", search_ms, len(all_tech_list),
            f"FAISS tech search + structured filter merged"
        ))
        logger.info(f"[STEP 3 SEARCH] {search_ms}ms | techs={len(all_tech_list)}")

        # ══════════════════════════════════════════════════════════════════════
        # STEP 4: VALIDATE — Score and rank by relevance criteria
        # ══════════════════════════════════════════════════════════════════════
        t0 = time.time()

        # Validate companies
        validated_companies = self.validator.batch_validate_companies(
            discovered_companies, intent, top_n=max_results
        )

        # Validate technologies
        validated_techs = self.validator.batch_validate_technologies(all_tech_list, intent)

        # For each validated company — attach their technologies
        company_ids = {vc["company"]["id"] for vc in validated_companies}
        for vc in validated_companies:
            cid   = vc["company"]["id"]
            techs = self.store.get_techs_by_company(cid)
            vc["company_technologies"] = techs

        # Also get technologies from companies NOT yet in validated set but with tech data
        for cid in company_ids:
            company_techs = self.store.get_techs_by_company(cid)
            for ct in company_techs:
                if ct["id"] not in all_techs:
                    # Add to tech pool if company matched
                    vt = self.validator.validate_technology(ct, intent)
                    if vt.is_relevant:
                        validated_techs.append({
                            "technology":      ct,
                            "validation":      vt,
                            "relevance_score": vt.relevance_score,
                            "justification":   vt.justification,
                            "matched_criteria":vt.matched_criteria,
                        })

        # Re-sort techs after additions
        validated_techs.sort(key=lambda x: x["relevance_score"], reverse=True)

        validate_ms = round((time.time() - t0) * 1000, 1)
        steps.append(AgentStep(
            "VALIDATE", "completed", validate_ms,
            len(validated_companies) + len(validated_techs),
            f"companies={len(validated_companies)}/{len(discovered_companies)} passed | techs={len(validated_techs)}/{len(all_tech_list)} passed"
        ))
        logger.info(f"[STEP 4 VALIDATE] {validate_ms}ms | passed_comp={len(validated_companies)}, passed_tech={len(validated_techs)}")

        # ══════════════════════════════════════════════════════════════════════
        # STEP 5: SYNTHESIZE — Build output + LLM executive summary
        # (LLM used ONLY here, for synthesis)
        # ══════════════════════════════════════════════════════════════════════
        t0 = time.time()
        synthesizer = get_synthesizer()
        llm_used    = True

        try:
            executive_summary = synthesizer.synthesize_research(
                query, validated_companies, validated_techs
            )
        except Exception as e:
            logger.warning(f"LLM synthesis failed: {e} — using deterministic fallback")
            executive_summary = synthesizer._deterministic_summary(query, validated_companies, validated_techs)
            llm_used = False

        synth_ms = round((time.time() - t0) * 1000, 1)
        steps.append(AgentStep(
            "SYNTHESIZE", "completed", synth_ms, 1,
            f"LLM used={llm_used} | executive summary generated"
        ))
        logger.info(f"[STEP 5 SYNTHESIZE] {synth_ms}ms | llm={llm_used}")

        total_ms = round((time.time() - total_start) * 1000, 1)
        logger.info(f"[AGENT] Complete | {total_ms}ms | companies={len(validated_companies)} | techs={len(validated_techs)}")

        return ResearchResult(
            query=query,
            parsed_intent=intent,
            companies=validated_companies,
            technologies=validated_techs,
            executive_summary=executive_summary,
            agent_steps=steps,
            total_latency_ms=total_ms,
            llm_used=llm_used,
            total_companies_found=len(discovered_companies),
            total_techs_found=len(all_tech_list),
            metadata={
                "intent_summary": {
                    "industries":   intent.industries,
                    "technologies": intent.technologies,
                    "geographies":  intent.geographies,
                    "company_types":intent.company_types,
                    "maturity":     intent.maturity,
                    "novelty":      intent.novelty,
                },
                "llm_usage": synthesizer.get_usage_stats(),
                "step_timings": {s.name: s.latency_ms for s in steps},
            }
        )

    def _empty_result(self, query: str, intent: ParsedIntent, steps: list, start: float) -> ResearchResult:
        return ResearchResult(
            query=query,
            parsed_intent=intent,
            companies=[],
            technologies=[],
            executive_summary=f"Query rejected: {intent.rejection_reason}",
            agent_steps=steps,
            total_latency_ms=round((time.time() - start) * 1000, 1),
            llm_used=False,
            total_companies_found=0,
            total_techs_found=0,
        )


_orchestrator: MarketResearchOrchestrator | None = None

def get_orchestrator() -> MarketResearchOrchestrator:
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = MarketResearchOrchestrator()
    return _orchestrator
