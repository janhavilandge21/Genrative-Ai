"""
agent/intent_parser.py
Parses natural language research queries into structured constraints.
Uses ZERO LLM — pure rule-based + pattern matching.
Fast, free, deterministic.

Input:  "Industrial AI startups working on predictive maintenance in oil & gas"
Output: {
    "industries":    ["Oil & Gas", "Industrial AI"],
    "technologies":  ["predictive maintenance", "AI"],
    "company_types": ["startup"],
    "geographies":   [],
    "maturity":      None,
    "novelty":       None,
    "raw_query":     "..."
}
"""

import re
from dataclasses import dataclass, field


@dataclass
class ParsedIntent:
    raw_query:    str
    industries:   list[str] = field(default_factory=list)
    technologies: list[str] = field(default_factory=list)
    company_types: list[str] = field(default_factory=list)
    geographies:  list[str] = field(default_factory=list)
    maturity:     str | None = None
    novelty:      str | None = None
    focus_keywords: list[str] = field(default_factory=list)
    is_valid:     bool = True
    rejection_reason: str = ""


# ── Industry keyword maps ─────────────────────────────────────────────────────
INDUSTRY_KEYWORDS = {
    "semiconductor":     ["semiconductor", "chip", "integrated circuit", "ic design", "wafer", "fab"],
    "industrial ai":     ["industrial ai", "factory ai", "manufacturing ai", "industry 4.0", "smart factory"],
    "iot":               ["iot", "internet of things", "connected devices", "smart sensors", "sensor"],
    "automation":        ["automation", "robotics", "plc", "scada", "control systems"],
    "predictive maint":  ["predictive maintenance", "condition monitoring", "anomaly detection", "cbm"],
    "automotive":        ["automotive", "vehicle", "car", "ev", "electric vehicle", "adas"],
    "healthcare":        ["healthcare", "medical", "health tech", "medtech", "pharma"],
    "fintech":           ["fintech", "financial technology", "payments", "banking", "insurance"],
    "saas":              ["saas", "software as a service", "cloud software", "b2b software"],
    "analytics":         ["analytics", "data analytics", "business intelligence", "bi"],
    "retail":            ["retail", "e-commerce", "ecommerce", "consumer", "shopping"],
    "climate":           ["climate", "cleantech", "carbon", "renewable", "sustainability", "green tech"],
    "oil gas":           ["oil", "gas", "energy", "petroleum", "upstream", "downstream", "lng"],
    "cybersecurity":     ["cybersecurity", "security", "infosec", "zero trust"],
    "logistics":         ["logistics", "supply chain", "transportation", "freight"],
    "agriculture":       ["agriculture", "agtech", "farming", "precision agriculture"],
}

COMPANY_TYPE_KEYWORDS = {
    "startup":         ["startup", "start-up", "early stage", "seed", "series a", "emerging"],
    "Large Enterprise":["enterprise", "large company", "corporate", "fortune 500", "multinational"],
    "SME":             ["sme", "mid-size", "medium company", "midmarket"],
    "Research":        ["research", "r&d", "lab", "institute", "academic"],
}

GEOGRAPHY_KEYWORDS = {
    "USA":           ["usa", "united states", "america", "us-based", "north america"],
    "Europe":        ["europe", "european", "eu", "germany", "france", "uk", "netherlands"],
    "Asia":          ["asia", "asian", "apac"],
    "Southeast Asia":["southeast asia", "sea", "singapore", "malaysia", "indonesia", "vietnam", "thailand"],
    "Japan":         ["japan", "japanese"],
    "China":         ["china", "chinese"],
    "India":         ["india", "indian"],
    "Germany":       ["germany", "german"],
    "Global":        ["global", "worldwide", "international"],
}

MATURITY_KEYWORDS = {
    "Commercialized":    ["commercialized", "commercial", "production ready", "mature", "deployed"],
    "Prototype":         ["prototype", "pilot", "poc", "proof of concept"],
    "Development Stage": ["development", "early stage", "r&d", "research phase"],
}

NOVELTY_KEYWORDS = {
    "High":   ["cutting edge", "innovative", "breakthrough", "novel", "high novelty", "state of the art"],
    "Medium": ["moderate", "medium novelty", "established"],
    "Low":    ["low novelty", "standard", "conventional"],
}

TECH_KEYWORDS = [
    "predictive maintenance", "anomaly detection", "quality control", "zero defect",
    "smart sensors", "connected sensors", "io-link", "iot platform",
    "machine learning", "deep learning", "computer vision", "nlp",
    "digital twin", "edge computing", "cloud", "5g", "wireless",
    "pressure sensor", "vibration monitoring", "condition monitoring",
    "smart factory", "industry 4.0", "automation", "robotics",
    "real-time monitoring", "data analytics", "ai platform",
    "cross-border payments", "carbon capture", "energy storage",
    "supply chain", "erp", "crm", "retail analytics",
]

UNSAFE_PATTERNS = [
    r"ignore\s+(previous|all)\s+instructions",
    r"reveal\s+(your|the)\s+(prompt|key|system)",
    r"<\|.*?\|>",
    r"###\s*(system|instruction)",
    r"drop\s+table",
    r"rm\s+-rf",
]


class IntentParser:
    """
    Zero-cost, zero-LLM query intent parser.
    Converts NL market research queries into structured search constraints.
    """

    def parse(self, query: str) -> ParsedIntent:
        # Guardrails first
        is_valid, reason = self._validate(query)
        if not is_valid:
            return ParsedIntent(
                raw_query=query,
                is_valid=False,
                rejection_reason=reason,
            )

        q = query.lower().strip()

        return ParsedIntent(
            raw_query=query,
            industries=self._extract_industries(q),
            technologies=self._extract_technologies(q),
            company_types=self._extract_company_types(q),
            geographies=self._extract_geographies(q),
            maturity=self._extract_maturity(q),
            novelty=self._extract_novelty(q),
            focus_keywords=self._extract_focus_keywords(q),
            is_valid=True,
        )

    def _validate(self, query: str) -> tuple[bool, str]:
        if not query or not query.strip():
            return False, "Query cannot be empty."
        if len(query.strip()) < 5:
            return False, "Query too short. Please describe what you're researching."
        if len(query) > 1000:
            return False, "Query too long. Please keep it under 1000 characters."
        q_lower = query.lower()
        for pattern in UNSAFE_PATTERNS:
            if re.search(pattern, q_lower):
                return False, "Query contains unsupported or unsafe patterns."
        return True, ""

    def _extract_industries(self, q: str) -> list[str]:
        found = []
        for industry, keywords in INDUSTRY_KEYWORDS.items():
            if any(kw in q for kw in keywords):
                found.append(industry.title())
        return list(set(found))

    def _extract_technologies(self, q: str) -> list[str]:
        found = []
        for tech in TECH_KEYWORDS:
            if tech in q:
                found.append(tech)
        return list(set(found))

    def _extract_company_types(self, q: str) -> list[str]:
        found = []
        for ctype, keywords in COMPANY_TYPE_KEYWORDS.items():
            if any(kw in q for kw in keywords):
                found.append(ctype)
        return list(set(found))

    def _extract_geographies(self, q: str) -> list[str]:
        found = []
        for geo, keywords in GEOGRAPHY_KEYWORDS.items():
            if any(kw in q for kw in keywords):
                found.append(geo)
        return list(set(found))

    def _extract_maturity(self, q: str) -> str | None:
        for maturity, keywords in MATURITY_KEYWORDS.items():
            if any(kw in q for kw in keywords):
                return maturity
        return None

    def _extract_novelty(self, q: str) -> str | None:
        for novelty, keywords in NOVELTY_KEYWORDS.items():
            if any(kw in q for kw in keywords):
                return novelty
        return None

    def _extract_focus_keywords(self, q: str) -> list[str]:
        """Extract remaining important terms not captured by other extractors."""
        # Remove common stop words and extract meaningful nouns/phrases
        stop = {"companies", "company", "firms", "firm", "focused", "focus",
                 "working", "building", "offering", "providing", "based",
                 "the", "and", "or", "in", "on", "for", "with", "of", "a", "an"}
        words = re.findall(r'\b[a-zA-Z][a-zA-Z\-]{2,}\b', q)
        keywords = [w for w in words if w.lower() not in stop]
        # Deduplicate while preserving order
        seen = set()
        result = []
        for kw in keywords:
            if kw.lower() not in seen:
                seen.add(kw.lower())
                result.append(kw)
        return result[:10]
