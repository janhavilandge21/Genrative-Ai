from __future__ import annotations

import re
from difflib import SequenceMatcher
from functools import lru_cache
from typing import Iterable

from core.types import ExtractedEntities
from retrieval.data_store import get_data_store


def _normalize(q: str) -> str:
    q = q.lower().strip()
    q = re.sub(r"\s+", " ", q)
    return q


def _dedupe_preserve_order(items: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for x in items:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


@lru_cache(maxsize=1)
def _known_names_snapshot() -> tuple[list[str], list[str]]:
    store = get_data_store()
    company_names = [c["name_lower"] for c in store.companies]
    tech_titles = [t["title_lower"] for t in store.technologies]
    return company_names, tech_titles


def _extract_by_substring(q_lower: str, candidates: Iterable[str]) -> list[str]:
    found: list[str] = []
    for cand in candidates:
        if not cand:
            continue
        if cand in q_lower:
            found.append(cand)
    return found


def _extract_by_similarity(q_lower: str, candidates: Iterable[str], threshold: float = 0.85) -> list[str]:
    # Used as a fallback for short/partial entity mentions.
    found: list[str] = []
    for cand in candidates:
        if not cand:
            continue
        if len(cand) < 4:
            continue
        ratio = SequenceMatcher(None, cand, q_lower).ratio()
        if ratio >= threshold:
            found.append(cand)
    return found


def extract_entities_and_constraints(question: str) -> ExtractedEntities:
    store = get_data_store()
    q_lower = _normalize(question)

    entities = ExtractedEntities()

    # Entity mentions.
    company_names, tech_titles = _known_names_snapshot()
    entities.company_names = _dedupe_preserve_order(_extract_by_substring(q_lower, company_names))
    if not entities.company_names:
        entities.company_names = _dedupe_preserve_order(
            _extract_by_similarity(q_lower, company_names, threshold=0.9)
        )

    entities.technology_titles = _dedupe_preserve_order(_extract_by_substring(q_lower, tech_titles))
    if not entities.technology_titles:
        entities.technology_titles = _dedupe_preserve_order(
            _extract_by_similarity(q_lower, tech_titles, threshold=0.9)
        )

    # Constraints: industries, countries, technology categories/tags/maturities.
    # These are extracted by checking known terms against the user query.
    for ind in store.get_all_industries():
        if ind and ind.lower() in q_lower:
            entities.industries.append(ind)
    entities.industries = _dedupe_preserve_order(entities.industries)[:6]

    for ctry in store.get_all_countries():
        if ctry and ctry.lower() in q_lower:
            entities.countries.append(ctry)
    entities.countries = _dedupe_preserve_order(entities.countries)[:6]

    for cat in store.get_all_technology_categories():
        if cat and cat.lower() in q_lower:
            entities.technology_categories.append(cat)
    entities.technology_categories = _dedupe_preserve_order(entities.technology_categories)[:6]

    for tag in store.get_all_technology_tags():
        if tag and tag.lower() in q_lower:
            entities.technology_tags.append(tag)
    entities.technology_tags = _dedupe_preserve_order(entities.technology_tags)[:10]

    # Technology maturity: match on known tech maturities first.
    # If maturity keywords are explicit, we treat them as constraints.
    q_tokens = set(q_lower.split())
    for t in store.technologies:
        m = t.get("maturity_lower") or ""
        if not m:
            continue
        # Basic keyword match: allow "commercial-ready" and "commercial" to match.
        if m in q_lower:
            entities.technology_maturities.append(t.get("maturity") or m)
        else:
            for tok in m.replace("-", " ").split():
                if tok in q_tokens:
                    entities.technology_maturities.append(t.get("maturity") or m)
                    break
    entities.technology_maturities = _dedupe_preserve_order(entities.technology_maturities)[:6]

    return entities

