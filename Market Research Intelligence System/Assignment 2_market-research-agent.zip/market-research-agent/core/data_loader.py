"""
core/data_loader.py
Loads, normalizes, and indexes company + technology data.
Fixes triple-quoted JSON strings in raw files.
"""

import json
from pathlib import Path
from loguru import logger
from config.settings import get_settings


# ── JSON fixer ────────────────────────────────────────────────────────────────
def _fix_triple_quotes(content: str) -> str:
    result = []
    i = 0; n = len(content)
    while i < n:
        if content[i:i+3] == '"""':
            end = content.find('"""', i + 3)
            if end == -1:
                result.append('"'); i += 3
            else:
                inner = content[i+3:end]
                inner = (inner.replace('\\', '\\\\')
                              .replace('"', '\\"')
                              .replace('\n', '\\n')
                              .replace('\r', '\\r')
                              .replace('\t', '\\t'))
                result.append('"' + inner + '"')
                i = end + 3
        else:
            result.append(content[i]); i += 1
    return ''.join(result)


def _load_json(path: Path) -> list:
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    return json.loads(_fix_triple_quotes(content))


# ── Extraction helpers ────────────────────────────────────────────────────────
def _first(lst, key="content", default=""):
    if not lst: return default
    if isinstance(lst, list) and lst:
        item = lst[0]
        if isinstance(item, dict): return str(item.get(key, default)).strip()
    if isinstance(lst, dict): return str(lst.get(key, default)).strip()
    return default


def _all_contents(lst, key="content"):
    if not lst or not isinstance(lst, list): return []
    results = []
    for item in lst:
        if isinstance(item, dict):
            val = item.get(key, "")
            if isinstance(val, list):
                results.extend([str(v).strip() for v in val if v])
            elif val:
                results.append(str(val).strip())
    return [r for r in results if r]


# ── Company normalizer ────────────────────────────────────────────────────────
def normalize_company(raw: dict) -> dict:
    doc_id = raw.get("_id", "")
    src    = raw.get("_source", {})
    bi_list = src.get("basic_information", [])
    bi = bi_list[0] if isinstance(bi_list, list) and bi_list else (bi_list or {})

    name       = _first(bi.get("name_suggestion", [])) or _first(bi.get("name", []))
    company_id = src.get("id") or doc_id
    website    = _first(bi.get("website", []))
    ctype      = _first(bi.get("company_type", []))
    description= _first(bi.get("description", []))
    domain     = _first(bi.get("domain", []))
    ticker     = _first(bi.get("company_ticker_symbol", []))
    founded    = _first(bi.get("founded_year", []))
    employees  = _first(bi.get("total_employee", []))

    # Industries — handle nested lists
    industries = []
    for item in (bi.get("industries", []) or []):
        if isinstance(item, dict):
            val = item.get("content", "")
            if isinstance(val, list): industries.extend([v for v in val if v])
            elif val: industries.append(str(val))
        elif isinstance(item, list):
            industries.extend([str(v) for v in item if v])
        elif item: industries.append(str(item))

    # Focus areas
    focus_areas = []
    for item in (bi.get("focusarea", []) or []):
        if isinstance(item, dict):
            val = item.get("content", "")
            if isinstance(val, list): focus_areas.extend([v for v in val if v])
            elif val: focus_areas.append(str(val))

    # Addresses
    addresses = bi.get("address_info", []) or []
    hq, all_countries = "", []
    for addr in (addresses if isinstance(addresses, list) else []):
        if not isinstance(addr, dict): continue
        country = addr.get("country", "")
        city    = addr.get("city", "")
        if addr.get("headquarter", "").lower() == "yes":
            hq = f"{city}, {country}".strip(", ")
        if country: all_countries.append(country)

    # Activities
    activities_raw = src.get("activity_information", [])
    activities = []
    for act in (activities_raw if isinstance(activities_raw, list) else []):
        if isinstance(act, dict):
            activities.append({
                "title":       act.get("title", ""),
                "description": act.get("description", ""),
                "type":        act.get("type", ""),
                "date":        act.get("published_date", ""),
            })

    # Financial
    fi_list = src.get("financial_information", [])
    fi = fi_list[0] if isinstance(fi_list, list) and fi_list else (fi_list or {})
    prof = fi.get("profitability_performance", {}) if isinstance(fi, dict) else {}
    revenue    = _first(prof.get("revenue", [])    if isinstance(prof, dict) else [])
    net_margin = _first(prof.get("net_margin", []) if isinstance(prof, dict) else [])

    industries_clean = list(set(i for i in industries if i and i != "[]"))
    focus_clean      = list(set(f for f in focus_areas if f and f != "[]"))

    return {
        "id":             company_id,
        "doc_id":         doc_id,
        "name":           name,
        "name_lower":     name.lower(),
        "website":        website,
        "domain":         domain,
        "ticker":         ticker,
        "company_type":   ctype,
        "description":    description,
        "industries":     industries_clean,
        "focus_areas":    focus_clean,
        "founded_year":   founded,
        "total_employees":employees,
        "headquarters":   hq,
        "countries":      list(set(all_countries)),
        "revenue":        revenue,
        "net_margin":     net_margin,
        "activities":     activities,
        "full_text": (
            f"{name}. {description}. "
            f"Industries: {', '.join(industries_clean)}. "
            f"Countries: {', '.join(list(set(all_countries))[:5])}. "
            f"Focus: {', '.join(focus_clean)}."
        ),
    }


# ── Technology normalizer ─────────────────────────────────────────────────────
def normalize_technology(raw: dict) -> dict:
    doc_id = raw.get("_id", "")
    src    = raw.get("_source", {})

    title       = _first(src.get("title", []))
    description = _first(src.get("description", []))
    principle   = _first(src.get("principle", []))
    maturity    = _first(src.get("maturity", []))
    novelty     = _first(src.get("novelty", []))
    category    = _first(src.get("category", []))
    innovation  = _first(src.get("innovation", []))

    company_info   = src.get("company", {}) or {}
    company_id     = company_info.get("companyid", "")
    company_name   = company_info.get("name", "")

    applications   = _all_contents(src.get("applications", []))
    key_highlights = _all_contents(src.get("key_highlights", []))
    diff_factors   = _all_contents(src.get("differentiating_factor", []))
    comp_adv       = _all_contents(src.get("competition_advantage", []))

    return {
        "id":             src.get("id", doc_id),
        "doc_id":         doc_id,
        "title":          title,
        "title_lower":    title.lower(),
        "description":    description,
        "principle":      principle,
        "maturity":       maturity,
        "maturity_lower": maturity.lower(),
        "novelty":        novelty,
        "novelty_lower":  novelty.lower(),
        "category":       category,
        "innovation":     innovation,
        "company_id":     company_id,
        "company_name":   company_name,
        "applications":   applications,
        "key_highlights": key_highlights,
        "differentiating_factors": diff_factors,
        "competition_advantages":  comp_adv,
        "full_text": (
            f"{title}. {description}. {principle}. "
            f"Category: {category}. Maturity: {maturity}. Novelty: {novelty}. "
            f"Company: {company_name}. "
            f"Applications: {'. '.join(applications[:3])}. "
            f"Highlights: {'. '.join(key_highlights[:4])}."
        ),
    }


# ── DataStore ─────────────────────────────────────────────────────────────────
class DataStore:
    def __init__(self):
        self.companies:    list[dict] = []
        self.technologies: list[dict] = []
        self._company_by_id:     dict = {}
        self._company_by_name:   dict = {}
        self._tech_by_id:        dict = {}
        self._techs_by_company:  dict = {}
        self._loaded = False

    def load(self):
        if self._loaded: return
        settings = get_settings()
        logger.info("DataStore: loading...")

        self.companies    = [normalize_company(c) for c in _load_json(settings.companies_file)]
        self.technologies = [normalize_technology(t) for t in _load_json(settings.technologies_file)]

        for c in self.companies:
            self._company_by_id[c["id"]]         = c
            self._company_by_name[c["name_lower"]] = c

        for t in self.technologies:
            self._tech_by_id[t["id"]] = t
            cid = t["company_id"]
            if cid: self._techs_by_company.setdefault(cid, []).append(t)

        self._loaded = True
        logger.info(f"DataStore: {len(self.companies)} companies, {len(self.technologies)} technologies")

    def get_company_by_id(self, cid: str) -> dict | None:
        return self._company_by_id.get(cid)

    def get_company_by_name(self, name: str) -> dict | None:
        nl = name.lower().strip()
        if nl in self._company_by_name: return self._company_by_name[nl]
        for key, c in self._company_by_name.items():
            if nl in key or key in nl: return c
        return None

    def get_techs_by_company(self, company_id: str) -> list[dict]:
        return self._techs_by_company.get(company_id, [])

    def filter_companies(self,
                         industries: list[str] | None = None,
                         countries:  list[str] | None = None,
                         company_type: str | None = None) -> list[dict]:
        results = self.companies
        if industries:
            results = [c for c in results if any(
                any(ind.lower() in str(ci).lower() for ci in c["industries"])
                for ind in industries
            )]
        if countries:
            results = [c for c in results if any(
                any(co.lower() in cc.lower() for cc in c["countries"])
                for co in countries
            )]
        if company_type:
            results = [c for c in results if company_type.lower() in c.get("company_type","").lower()]
        return results

    def filter_technologies(self,
                             maturity: str | None = None,
                             novelty:  str | None = None,
                             category: str | None = None) -> list[dict]:
        results = self.technologies
        if maturity: results = [t for t in results if maturity.lower() in t["maturity_lower"]]
        if novelty:  results = [t for t in results if novelty.lower()  in t["novelty_lower"]]
        if category: results = [t for t in results if category.lower() in t.get("category","").lower()]
        return results

    def text_search_companies(self, keyword: str) -> list[dict]:
        kw = keyword.lower()
        return [c for c in self.companies
                if kw in c["full_text"].lower() or kw in c["name_lower"]]

    def text_search_technologies(self, keyword: str) -> list[dict]:
        kw = keyword.lower()
        return [t for t in self.technologies
                if kw in t["full_text"].lower() or kw in t["title_lower"]]


_store: DataStore | None = None

def get_data_store() -> DataStore:
    global _store
    if _store is None:
        _store = DataStore()
        _store.load()
    return _store
