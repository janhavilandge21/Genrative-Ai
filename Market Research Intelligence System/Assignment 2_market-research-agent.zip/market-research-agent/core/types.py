from dataclasses import dataclass, field
from typing import Literal


QueryType = Literal["FACT", "LOOKUP", "EXPLANATION", "COMPLEX"]
Confidence = Literal["high", "medium", "low"]


@dataclass
class ExtractedEntities:
    company_names: list[str] = field(default_factory=list)
    technology_titles: list[str] = field(default_factory=list)

    # Constraints inferred from the question.
    industries: list[str] = field(default_factory=list)
    countries: list[str] = field(default_factory=list)
    technology_categories: list[str] = field(default_factory=list)
    technology_tags: list[str] = field(default_factory=list)
    technology_maturities: list[str] = field(default_factory=list)


@dataclass
class QueryClassification:
    query_type: QueryType
    # A score expressing how much the answer can be produced deterministically.
    deterministic_score: float


@dataclass
class GuardrailsResult:
    ok: bool
    reason: str | None = None


@dataclass
class Candidate:
    kind: Literal["company", "technology"]
    entity: dict
    score: float
    matched_justification: list[str] = field(default_factory=list)


@dataclass
class RetrievalResult:
    companies: list[Candidate] = field(default_factory=list)
    technologies: list[Candidate] = field(default_factory=list)

