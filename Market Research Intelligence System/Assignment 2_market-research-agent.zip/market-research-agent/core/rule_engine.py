from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from core.entity_extractor import _normalize
from core.query_classifier import classify_query
from core.types import Candidate, ExtractedEntities, RetrievalResult
from retrieval.data_store import get_data_store


def _overlap_size(a: Iterable[str], b: Iterable[str]) -> int:
    sa = {x.lower() for x in a if x}
    sb = {x.lower() for x in b if x}
    return len(sa.intersection(sb))


def _score_company(
    c: dict,
    entities: ExtractedEntities,
) -> tuple[float, list[str]]:
    score = 0.0
    reasons: list[str] = []

    if entities.company_names:
        # Deterministic name match dominates.
        for name in entities.company_names:
            if name.lower() == c["name_lower"]:
                score += 3.0
                reasons.append(f"company name match: {c['name']}")
                break
        else:
            # Partial overlap fallback.
            if any(name in c["name_lower"] or c["name_lower"] in name for name in entities.company_names):
                score += 2.0
                reasons.append("company name partial match")

    if entities.industries:
        overlap = _overlap_size(entities.industries, c.get("industries", []))
        if overlap:
            score += 1.5
            reasons.append(f"industry overlap ({overlap})")

        # Also consider focus areas + tags as industry-like signals.
        focus_overlap = _overlap_size(entities.industries, c.get("focus_areas", []))
        if focus_overlap:
            score += 1.0
            reasons.append(f"focus area overlap ({focus_overlap})")

    if entities.countries:
        # Candidate's countries are already normalized in data_store.
        overlap = _overlap_size(entities.countries, c.get("countries", []))
        if overlap:
            score += 1.5
            reasons.append(f"geography overlap ({overlap})")

    # Mild keyword presence boost.
    q_tokens = set()
    # Rule engine doesn't have raw question here. We'll only apply based on constraints.
    if entities.industries:
        q_tokens.update(x.lower() for x in entities.industries)
    if entities.countries:
        q_tokens.update(x.lower() for x in entities.countries)
    if entities.company_names:
        q_tokens.update(x.lower() for x in entities.company_names)

    if q_tokens:
        hay = c.get("search_text", "")
        hits = sum(1 for t in q_tokens if t and t in hay)
        score += min(1.0, 0.1 * hits)

    return score, reasons


def _score_technology(t: dict, entities: ExtractedEntities) -> tuple[float, list[str]]:
    score = 0.0
    reasons: list[str] = []

    if entities.technology_titles:
        for name in entities.technology_titles:
            if name.lower() == t.get("title_lower", ""):
                score += 3.0
                reasons.append(f"technology title match: {t.get('title')}")
                break
        else:
            if any(name in t.get("title_lower", "") or t.get("title_lower", "") in name for name in entities.technology_titles):
                score += 2.0
                reasons.append("technology title partial match")

    if entities.technology_categories:
        overlap = _overlap_size(entities.technology_categories, [t.get("category", "")])
        if overlap:
            score += 1.5
            reasons.append("category overlap")

    if entities.technology_tags:
        overlap = _overlap_size(entities.technology_tags, t.get("tags", []))
        if overlap:
            score += 1.0
            reasons.append("tag overlap")

    if entities.technology_maturities:
        overlap = _overlap_size(entities.technology_maturities, [t.get("maturity", ""), t.get("maturity_lower", "")])
        # The overlap may be limited due to normalization; treat non-empty matches as signal.
        if overlap or (entities.technology_maturities and any(m.lower() in (t.get("maturity_lower") or "") for m in entities.technology_maturities)):
            score += 1.0
            reasons.append("maturity overlap")

    # Geography alignment via owning company.
    if entities.countries and t.get("company_id"):
        store = get_data_store()
        c = store.get_company(t["company_id"])
        if c:
            overlap = _overlap_size(entities.countries, c.get("countries", []))
            if overlap:
                score += 1.5
                reasons.append("technology owning-company geography match")

    return score, reasons


class RuleEngine:
    """
    Deterministic candidate generation from structured JSON fields.
    No LLM calls are made here.
    """

    def retrieve(self, question: str, query_type: str, entities: ExtractedEntities, top_k: int = 10) -> RetrievalResult:
        store = get_data_store()

        companies: list[Candidate] = []
        technologies: list[Candidate] = []

        # If the user mentions explicit entities, prefer deterministic lookups.
        explicit_company_ids: list[str] = []
        explicit_tech_ids: list[str] = []

        for cname in entities.company_names:
            c = store.get_by_name(cname)
            if c:
                explicit_company_ids.append(c["id"])

        for tname in entities.technology_titles:
            t = store.get_technology_by_name(tname)
            if t:
                explicit_tech_ids.append(t["id"])

        # Company handling.
        if explicit_company_ids:
            for cid in explicit_company_ids:
                c = store.get_company(cid)
                if not c:
                    continue
                score, reasons = _score_company(c, entities)
                companies.append(Candidate(kind="company", entity=c, score=score, matched_justification=reasons))
        else:
            # Constraint-based discovery.
            for c in store.companies:
                score, reasons = _score_company(c, entities)
                # Avoid weak matches: require at least one meaningful signal.
                if score >= 1.0 or (entities.industries or entities.countries):
                    companies.append(Candidate(kind="company", entity=c, score=score, matched_justification=reasons))

        # Technology handling.
        if explicit_tech_ids:
            for tid in explicit_tech_ids:
                t = store._tech_by_id.get(tid)  # internal fast path
                if not t:
                    continue
                score, reasons = _score_technology(t, entities)
                technologies.append(Candidate(kind="technology", entity=t, score=score, matched_justification=reasons))
        else:
            for t in store.technologies:
                score, reasons = _score_technology(t, entities)
                if score >= 1.0 or (entities.technology_categories or entities.technology_tags or entities.technology_maturities):
                    technologies.append(Candidate(kind="technology", entity=t, score=score, matched_justification=reasons))

        # Rank by rule score.
        companies = sorted(companies, key=lambda c: c.score, reverse=True)[:top_k]
        technologies = sorted(technologies, key=lambda t: t.score, reverse=True)[:top_k]

        # For lookup queries, we try to return related entities as well.
        if query_type == "LOOKUP" and companies:
            selected_company_ids = {c.entity["id"] for c in companies}
            rel_techs: list[Candidate] = []
            for cid in selected_company_ids:
                for t in store.get_techs_for_company(cid):
                    score, reasons = _score_technology(t, entities)
                    score += 0.5
                    rel_techs.append(
                        Candidate(kind="technology", entity=t, score=score, matched_justification=["related to selected company", *reasons])
                    )
            technologies = sorted((technologies + rel_techs), key=lambda t: t.score, reverse=True)[:top_k]

        return RetrievalResult(companies=companies, technologies=technologies)

