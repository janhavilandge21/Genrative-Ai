import re

from core.types import GuardrailsResult


_INJECTION_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\bignore\b.*\b(previous|instructions?)\b", re.IGNORECASE),
    re.compile(r"\b(system prompt|developer message)\b", re.IGNORECASE),
    re.compile(r"\b(reveal|disclose)\b.*\b(system|developer)\b", re.IGNORECASE),
    re.compile(r"\b(jailbreak|prompt injection)\b", re.IGNORECASE),
    re.compile(r"\bdo not\b.*\bcomply\b", re.IGNORECASE),
]

_UNSAFE_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\b(api key|secret|password|token|credentials)\b", re.IGNORECASE),
    re.compile(r"\b(drop table|sql injection)\b", re.IGNORECASE),
]


def sanitize_question(q: str) -> str:
    # Keep it simple and deterministic: remove null bytes and normalize whitespace.
    q = q.replace("\x00", " ").strip()
    q = re.sub(r"\s+", " ", q)
    return q


def check_prompt_injection(q: str) -> GuardrailsResult:
    if not q:
        return GuardrailsResult(ok=False, reason="Empty query.")

    for p in _UNSAFE_PATTERNS:
        if p.search(q):
            return GuardrailsResult(ok=False, reason="Unsafe request detected.")

    for p in _INJECTION_PATTERNS:
        if p.search(q):
            return GuardrailsResult(ok=False, reason="Prompt injection attempt detected.")

    return GuardrailsResult(ok=True)


def guardrail_validate_question(question: str) -> GuardrailsResult:
    q = sanitize_question(question)

    if len(q) < 3:
        return GuardrailsResult(ok=False, reason="Question is too short.")
    if len(q) > 2000:
        return GuardrailsResult(ok=False, reason="Question is too long.")

    inj = check_prompt_injection(q)
    if not inj.ok:
        return inj

    # Light heuristic: if the user isn't asking about companies/technologies at all,
    # we treat it as unsupported to reduce hallucinations.
    dataset_terms = [
        "company",
        "companies",
        "technology",
        "technologies",
        "startup",
        "industry",
        "sector",
        "country",
        "region",
        "analytics",
        "diagnostics",
        "predictive maintenance",
        "carbon capture",
        "payments",
        "retail",
    ]
    if not any(t in q.lower() for t in dataset_terms):
        return GuardrailsResult(
            ok=False,
            reason="Unsupported query: ask about companies or technologies from the dataset.",
        )

    return GuardrailsResult(ok=True)

