from __future__ import annotations

import re

from core.entity_extractor import _normalize
from core.types import ExtractedEntities, QueryClassification, QueryType


def _has_any(q_lower: str, patterns: list[str]) -> bool:
    return any(re.search(p, q_lower) for p in patterns)


def classify_query(question: str, entities: ExtractedEntities) -> QueryClassification:
    q = _normalize(question)

    # Intent patterns.
    count_patterns = [
        r"\bhow many\b",
        r"\bcount\b",
        r"\bnumber of\b",
        r"\btotal\b",
        r"\bwithout\b.*\b(an?)\b",  # not exhaustive; just keeps heuristics simple.
    ]
    explain_patterns = [
        r"\bwhy\b",
        r"\bexplain\b",
        r"\bjustif(y|ication)\b",
        r"\bhow does\b",
        r"\bwhat makes\b",
    ]
    lookup_patterns = [
        r"\bwhich\b",
        r"\bwho\b",
        r"\btell me about\b",
        r"\babout\b",
        r"\bshow\b",
        r"\blist\b",
        r"\bstartup(s)?\b",
        r"\bcompany\b",
        r"\btechnology\b",
    ]
    complex_patterns = [
        r"\bcompare\b",
        r"\bversus\b",
        r"\bbetween\b",
        r"\bversus\b",
        r"\btrade-?offs\b",
        r"\ball\b.*\bbut\b",
    ]

    if _has_any(q, explain_patterns):
        qtype: QueryType = "EXPLANATION"
    elif _has_any(q, complex_patterns):
        qtype = "COMPLEX"
    elif _has_any(q, count_patterns):
        qtype = "FACT"
    elif _has_any(q, lookup_patterns):
        qtype = "LOOKUP"
    else:
        qtype = "LOOKUP"

    # Determinism score: more extracted constraints => higher confidence in deterministic routing.
    det = 0.2
    det += 0.25 if (entities.industries or entities.countries) else 0.0
    det += 0.25 if entities.company_names else 0.0
    det += 0.25 if entities.technology_titles or entities.technology_categories or entities.technology_tags else 0.0
    det += 0.15 if qtype in ("FACT", "LOOKUP") else 0.0
    det = min(det, 1.0)

    return QueryClassification(query_type=qtype, deterministic_score=det)

