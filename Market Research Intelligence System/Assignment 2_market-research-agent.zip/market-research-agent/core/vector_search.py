"""
core/vector_search.py
FAISS-based semantic search for the Market Research Agent.
Separate indexes for companies and technologies.
Built once at startup, persisted to disk.
"""

import pickle
import numpy as np
from pathlib import Path
from loguru import logger
from config.settings import get_settings
from core.data_loader import get_data_store


class FAISSEngine:
    def __init__(self):
        self.settings     = get_settings()
        self._model       = None
        self._tech_index  = None
        self._comp_index  = None
        self._tech_docs:  list[dict] = []
        self._comp_docs:  list[dict] = []
        self._ready = False

    def _get_model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            logger.info(f"Loading embedding model: {self.settings.embedding_model}")
            self._model = SentenceTransformer(self.settings.embedding_model, device="cpu")
        return self._model

    def build_or_load(self):
        idx_dir   = self.settings.faiss_index_dir
        tech_path = idx_dir / "tech.pkl"
        comp_path = idx_dir / "comp.pkl"

        if tech_path.exists() and comp_path.exists():
            logger.info("FAISS: loading from cache...")
            with open(tech_path, "rb") as f: d = pickle.load(f); self._tech_index = d["index"]; self._tech_docs = d["docs"]
            with open(comp_path, "rb") as f: d = pickle.load(f); self._comp_index = d["index"]; self._comp_docs = d["docs"]
            self._ready = True
            logger.info(f"FAISS ready: {len(self._tech_docs)} techs, {len(self._comp_docs)} companies")
            return
        self._build()

    def _build(self):
        import faiss
        store = get_data_store()
        model = self._get_model()
        idx_dir = self.settings.faiss_index_dir

        logger.info("FAISS: building indexes...")
        self._tech_docs = store.technologies
        t_vecs = model.encode([t["full_text"] for t in self._tech_docs],
                               normalize_embeddings=True, show_progress_bar=False).astype(np.float32)
        dim = t_vecs.shape[1]
        self._tech_index = faiss.IndexFlatIP(dim)
        self._tech_index.add(t_vecs)

        self._comp_docs = store.companies
        c_vecs = model.encode([c["full_text"] for c in self._comp_docs],
                               normalize_embeddings=True, show_progress_bar=False).astype(np.float32)
        self._comp_index = faiss.IndexFlatIP(dim)
        self._comp_index.add(c_vecs)

        with open(idx_dir / "tech.pkl", "wb") as f: pickle.dump({"index": self._tech_index, "docs": self._tech_docs}, f)
        with open(idx_dir / "comp.pkl", "wb") as f: pickle.dump({"index": self._comp_index, "docs": self._comp_docs}, f)
        self._ready = True
        logger.info(f"FAISS built: {len(self._tech_docs)} techs, {len(self._comp_docs)} companies")

    def search_technologies(self, query: str, k: int = 5) -> list[dict]:
        if not self._ready: self.build_or_load()
        return self._search(query, self._tech_index, self._tech_docs, k)

    def search_companies(self, query: str, k: int = 15) -> list[dict]:
        if not self._ready: self.build_or_load()
        return self._search(query, self._comp_index, self._comp_docs, k)

    def _search(self, query: str, index, docs: list[dict], k: int) -> list[dict]:
        model = self._get_model()
        q_vec = model.encode([query], normalize_embeddings=True).astype(np.float32)
        k     = min(k, max(1, len(docs)))
        scores, indices = index.search(q_vec, k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx >= 0 and float(score) > 0.10:
                results.append({**docs[idx], "semantic_score": float(score)})
        return results

    def invalidate(self):
        idx_dir = self.settings.faiss_index_dir
        for p in [idx_dir / "tech.pkl", idx_dir / "comp.pkl"]:
            if p.exists(): p.unlink()
        self._ready = False


_engine: FAISSEngine | None = None

def get_faiss_engine() -> FAISSEngine:
    global _engine
    if _engine is None:
        _engine = FAISSEngine()
    return _engine
