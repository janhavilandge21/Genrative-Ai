"""
main.py — FastAPI entry point for Market Research Agent
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from loguru import logger

from api.routes import router
from core.data_loader import get_data_store
from core.vector_search import get_faiss_engine
from agent.orchestrator import get_orchestrator
from config.settings import get_settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    logger.info("=" * 60)
    logger.info("  Market Research Agent  v1.0")
    logger.info("  Assignment 2 — Agentic AI System")
    logger.info("=" * 60)

    logger.info("Loading data store...")
    store = get_data_store()
    logger.info(f"  {len(store.companies)} companies | {len(store.technologies)} technologies")

    logger.info("Building/loading FAISS indexes...")
    engine = get_faiss_engine()
    engine.build_or_load()

    logger.info("Warming up orchestrator...")
    get_orchestrator()

    groq_ok = bool(settings.groq_api_key) and settings.groq_api_key != "gsk_your_groq_key_here"
    logger.info(f"Groq: {'✅ configured' if groq_ok else '⚠️  not configured (LLM synthesis disabled)'}")
    logger.info("=" * 60)
    logger.info("API ready → http://localhost:8001/docs")
    logger.info("=" * 60)
    yield
    logger.info("Shutting down.")


app = FastAPI(
    title="Market Research Agent",
    description=(
        "Agentic AI system for automated market research. "
        "5-step pipeline: PARSE → DISCOVER → SEARCH → VALIDATE → SYNTHESIZE. "
        "Company identification uses digital footprint discovery, NOT direct LLM."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)

app.include_router(router, prefix="/api/v1")


@app.get("/")
def root():
    return {
        "service":  "Market Research Agent",
        "version":  "1.0.0",
        "docs":     "http://localhost:8001/docs",
        "research": "POST /api/v1/research",
        "health":   "GET /api/v1/health",
        "pipeline": ["PARSE", "DISCOVER", "SEARCH", "VALIDATE", "SYNTHESIZE"],
        "examples": "GET /api/v1/example-queries",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8001, reload=True)
