from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from core.types import Candidate, ExtractedEntities, Confidence
from retrieval.data_store import get_data_store


@dataclass
class ValidatedResult:
    companies: list[Candidate] = field(default_factory=list)
    technologies: list[Candidate] = field(default_factory=list)
    confidence: Confidence = "low"
    # Used for explainability in the response.
    inclusion_justifications: list[str] = field(default_factory=list)


def _overlap_size(a: list[str], b: list[str]) -> int:
    sa = {x.lower() for x in a if x}
    sb = {x.lower() for x in b if x}
    return len(sa.intersection(sb))


class RelevanceValidationService:
    def __init__(self):
        self.store = get_data_store()

    def validate(
        self,
        companies: list[Candidate],
        technologies: list[Candidate],
        entities: ExtractedEntities,
    ) -> ValidatedResult:
        result = ValidatedResult()

        # Score companies.
        for c in companies:
            entity_score = c.score
            reasons: list[str] = []

            if entities.company_names:
                if c.entity.get("name_lower") in {n.lower() for n in entities.company_names}:
                    entity_score += 2.0
                    reasons.append("direct company entity mention")

            if entities.industries:
                overlap = _overlap_size(entities.industries, c.entity.get("industries", []))
                if overlap:
                    entity_score += 1.0
                    reasons.append(f"industry match ({overlap})")

            if entities.countries:
                overlap = _overlap_size(entities.countries, c.entity.get("countries", []))
                if overlap:
                    entity_score += 1.0
                    reasons.append(f"geographic match ({overlap})")

            c.matched_justification.extend(reasons)
            c.score = entity_score
            # Include semantic-only candidates when they are still meaningfully similar.
            if entity_score >= 0.8:
                result.companies.append(c)
            elif entity_score >= 0.4 and c.score >= 0.4 and (reasons or c.matched_justification):
                result.companies.append(c)

        # Score technologies.
        for t in technologies:
            entity_score = t.score
            reasons: list[str] = []

            if entities.technology_titles:
                if t.entity.get("title_lower") in {n.lower() for n in entities.technology_titles}:
                    entity_score += 2.0
                    reasons.append("direct technology entity mention")

            if entities.technology_categories:
                overlap = _overlap_size(entities.technology_categories, [t.entity.get("category", "")])
                if overlap:
                    entity_score += 1.0
                    reasons.append("technology category match")

            if entities.technology_tags:
                overlap = _overlap_size(entities.technology_tags, t.entity.get("tags", []))
                if overlap:
                    entity_score += 0.75
                    reasons.append(f"technology tag match ({overlap})")

            if entities.technology_maturities:
                # Maturity normalization is sometimes inconsistent; do partial match.
                q_m = " ".join(entities.technology_maturities).lower()
                m = (t.entity.get("maturity") or t.entity.get("maturity_lower") or "").lower()
                if m and (m in q_m or q_m in m):
                    entity_score += 0.5
                    reasons.append("technology maturity match")

            # Geographic alignment via owning company.
            if entities.countries and t.entity.get("company_id"):
                c = self.store.get_company(t.entity["company_id"])
                if c:
                    overlap = _overlap_size(entities.countries, c.get("countries", []))
                    if overlap:
                        entity_score += 0.75
                        reasons.append("owning company geographic alignment")

            t.matched_justification.extend(reasons)
            t.score = entity_score
            if entity_score >= 0.8:
                result.technologies.append(t)
            elif entity_score >= 0.4 and t.score >= 0.4 and (reasons or t.matched_justification):
                result.technologies.append(t)

        # Sort again after validation.
        result.companies = sorted(result.companies, key=lambda x: x.score, reverse=True)
        result.technologies = sorted(result.technologies, key=lambda x: x.score, reverse=True)

        # Overall confidence based on top candidate evidence.
        top_score = 0.0
        if result.companies:
            top_score = max(top_score, result.companies[0].score)
        if result.technologies:
            top_score = max(top_score, result.technologies[0].score)

        if top_score >= 5.0:
            result.confidence = "high"
            result.inclusion_justifications.append("strong rule-based matches for constraints")
        elif top_score >= 2.5:
            result.confidence = "medium"
            result.inclusion_justifications.append("moderate matches across constraints")
        else:
            result.confidence = "low"
            result.inclusion_justifications.append("weak matches: verify constraints or provide more specifics")

        return result

