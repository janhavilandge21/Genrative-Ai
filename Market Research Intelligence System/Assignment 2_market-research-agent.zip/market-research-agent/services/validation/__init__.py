"""
Relevance validation services.
"""

