"""
Orchestration layer: agent controller coordinating retrieval, validation, optional LLM.
"""

