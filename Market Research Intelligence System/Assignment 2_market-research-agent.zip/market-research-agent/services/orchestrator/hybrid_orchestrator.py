from __future__ import annotations

import time
from typing import Any

from app.schemas.query import QueryRequest
from app.schemas.response import DataRef, QueryResponse
from core.guardrails import guardrail_validate_question
from core.entity_extractor import extract_entities_and_constraints
from core.query_classifier import classify_query
from core.rule_engine import RuleEngine
from core.types import Candidate
from memory.conversation_store import get_state, set_state, ConversationState
from services.cache.cache_service import cache_get, cache_set
from services.llm.llm_service import generate_explanation
from services.llm.should_use_llm import should_use_llm
from services.retrieval.vector_search_service import VectorSearchService
from services.validation.relevance_validation_service import RelevanceValidationService
from utils.query_rewriter import rewrite_for_follow_up


class HybridQueryOrchestrator:
    def __init__(self):
        self.rule_engine = RuleEngine()
        self.vector_service = VectorSearchService()
        self.validator = RelevanceValidationService()
        self._cache_version = 2

    def _normalize_key(self, s: str) -> str:
        return " ".join(s.strip().lower().split())

    def _safe_fallback(self, question: str, reason: str, query_type: str) -> QueryResponse:
        return QueryResponse(
            answer=(
                "I can help with market research over the provided companies/technologies datasets. "
                f"Request could not be processed: {reason} "
                "Try asking for company/technology counts, filtered lists, or lookups by name."
            ),
            source=["companies.json", "technologies.json"],
            data_used=[],
            confidence="low",
            llm_used=False,
            query_type=query_type,
            latency_ms=0.0,
            llm_reason=None,
            data_used_raw=[],
        )

    def handle(self, request: QueryRequest) -> QueryResponse:
        start = time.perf_counter()

        guard = guardrail_validate_question(request.question)
        if not guard.ok:
            # Return safe fallback (no LLM).
            return self._safe_fallback(request.question, guard.reason or "invalid request", "LOOKUP")

        # Multi-turn context.
        state = get_state(request.conversation_id)

        entities = extract_entities_and_constraints(request.question)
        resolved_question, entities = rewrite_for_follow_up(request.question, state, entities)

        classification = classify_query(resolved_question, entities)

        cache_key = f"resp:v{self._cache_version}:{request.conversation_id}:{classification.query_type}:{self._normalize_key(resolved_question)[:250]}:{request.top_k}"
        cached = cache_get(cache_key)
        if cached is not None:
            # latency_ms set at route; keep as 0 here.
            return QueryResponse(**cached)

        # Hybrid retrieval.
        retrieval = self.rule_engine.retrieve(
            question=resolved_question,
            query_type=classification.query_type,
            entities=entities,
            top_k=request.top_k,
        )

        # Vector search is used to improve recall/ranking for ambiguous or constraint-poor requests.
        use_vector = request.enable_semantic and (
            classification.query_type in ("COMPLEX", "LOOKUP") or classification.deterministic_score < 0.9
        )

        vector_result = None
        if use_vector:
            vector_result = self.vector_service.search(
                resolved_question,
                top_k_companies=min(30, max(15, request.top_k * 3)),
                top_k_tech=min(20, max(8, request.top_k * 2)),
            )

        # Combine + re-rank deterministically.
        def combine(rule_cands: list[Candidate], vec_cands: list[Candidate] | None) -> list[Candidate]:
            if vec_cands is None:
                return sorted(rule_cands, key=lambda x: x.score, reverse=True)[: request.top_k]

            by_id: dict[str, Candidate] = {}
            for c in rule_cands:
                by_id[c.entity["id"]] = c

            for vc in vec_cands:
                vid = vc.entity["id"]
                if vid in by_id:
                    # Rule score is usually stronger; vector refines.
                    by_id[vid].score = 0.65 * by_id[vid].score + 0.35 * (vc.score * 5.0)
                    by_id[vid].matched_justification.append("vector semantic refinement")
                else:
                    by_id[vid] = vc

            return sorted(by_id.values(), key=lambda x: x.score, reverse=True)[: request.top_k]

        combined_companies = combine(retrieval.companies, vector_result.companies if vector_result else None)
        combined_technologies = combine(retrieval.technologies, vector_result.technologies if vector_result else None)

        # Validation layer (relevance + explainability).
        validated = self.validator.validate(
            companies=combined_companies,
            technologies=combined_technologies,
            entities=entities,
        )

        # De-duplicate candidates (rule engine can append related items).
        def dedupe(cands: list[Candidate]) -> list[Candidate]:
            seen: set[str] = set()
            out: list[Candidate] = []
            for c in sorted(cands, key=lambda x: x.score, reverse=True):
                cid = c.entity.get("id")
                if not cid:
                    continue
                if cid in seen:
                    continue
                seen.add(cid)
                out.append(c)
            return out

        validated.companies = dedupe(validated.companies)
        validated.technologies = dedupe(validated.technologies)

        # Determine whether LLM is necessary for narrative/explanations.
        wants_llm, llm_reason = should_use_llm(
            query_type=classification.query_type,
            confidence=validated.confidence,
            enable_llm=request.enable_llm,
        )

        llm_used = wants_llm
        context_payload: dict[str, Any] = {
            "question": resolved_question,
            "classification": classification.query_type,
            "constraints": {
                "industries": entities.industries,
                "countries": entities.countries,
                "technology_categories": entities.technology_categories,
                "technology_tags": entities.technology_tags,
                "technology_maturities": entities.technology_maturities,
                "company_names": entities.company_names,
                "technology_titles": entities.technology_titles,
            },
            "validated_companies": [
                {
                    "id": c.entity.get("id"),
                    "name": c.entity.get("name"),
                    "website": c.entity.get("website"),
                    "company_type": c.entity.get("company_type"),
                    "geographic_focus": c.entity.get("headquarters"),
                    "financials": {"revenue": c.entity.get("revenue"), "net_margin": c.entity.get("net_margin")},
                    "business_activities": c.entity.get("activities", []),
                    "justification": c.matched_justification[:5],
                    "rule_score": c.score,
                }
                for c in validated.companies[:10]
            ],
            "validated_technologies": [
                {
                    "id": t.entity.get("id"),
                    "title": t.entity.get("title"),
                    "category": t.entity.get("category"),
                    "maturity": t.entity.get("maturity"),
                    "novelty": t.entity.get("novelty"),
                    "applications": t.entity.get("applications", []),
                    "core_principles": t.entity.get("principle", None),
                    "highlights": t.entity.get("highlights", []),
                    "relevance_justification": t.matched_justification[:5],
                    "rule_score": t.score,
                }
                for t in validated.technologies[:10]
            ],
        }

        # Build structured output + answer.
        if not validated.companies and not validated.technologies:
            # Best-effort semantic fallback: return FAISS top candidates even when
            # deterministic rule-based validation found nothing.
            if vector_result is not None:
                best_companies = sorted(vector_result.companies, key=lambda x: x.score, reverse=True)[: request.top_k]
                best_technologies = sorted(vector_result.technologies, key=lambda x: x.score, reverse=True)[: request.top_k]
                if best_companies or best_technologies:
                    data_refs: list[DataRef] = []
                    data_used_raw: list[dict[str, Any]] = []

                    for c in best_companies[: min(5, request.top_k)]:
                        data_refs.append(DataRef(type="company", id=c.entity.get("id"), name=c.entity.get("name")))
                        data_used_raw.append(
                            {
                                "type": "company",
                                "id": c.entity.get("id"),
                                "name": c.entity.get("name"),
                                "justification": c.matched_justification,
                                "semantic_score": c.score,
                            }
                        )

                    for t in best_technologies[: min(5, request.top_k)]:
                        data_refs.append(DataRef(type="technology", id=t.entity.get("id"), name=t.entity.get("title")))
                        data_used_raw.append(
                            {
                                "type": "technology",
                                "id": t.entity.get("id"),
                                "name": t.entity.get("title"),
                                "justification": t.matched_justification,
                                "semantic_score": t.score,
                            }
                        )

                    latency_ms = (time.perf_counter() - start) * 1000
                    return QueryResponse(
                        answer=(
                            "I couldn't find strong deterministic matches in the structured dataset for your exact constraints. "
                            "Showing best-effort semantic matches with low confidence."
                        ),
                        source=["companies.json", "technologies.json"],
                        data_used=data_refs,
                        confidence="low",
                        llm_used=False,
                        query_type=classification.query_type,
                        latency_ms=latency_ms,
                        llm_reason=None,
                        data_used_raw=data_used_raw,
                    )

            response = self._safe_fallback(
                resolved_question,
                "no strong deterministic matches",
                classification.query_type,
            )
            response.latency_ms = (time.perf_counter() - start) * 1000
            return response

        data_refs: list[DataRef] = []
        data_used_raw: list[dict[str, Any]] = []

        for c in validated.companies[: min(5, request.top_k)]:
            data_refs.append(DataRef(type="company", id=c.entity.get("id"), name=c.entity.get("name")))
            data_used_raw.append(
                {"type": "company", "id": c.entity.get("id"), "name": c.entity.get("name"), "justification": c.matched_justification}
            )

        for t in validated.technologies[: min(5, request.top_k)]:
            data_refs.append(DataRef(type="technology", id=t.entity.get("id"), name=t.entity.get("title")))
            data_used_raw.append(
                {"type": "technology", "id": t.entity.get("id"), "name": t.entity.get("title"), "justification": t.matched_justification}
            )

        source = ["companies.json", "technologies.json"]

        if llm_used:
            # Log LLM usage with reason.
            # (Assignment asks: log with reason; we log to loguru.)
            from loguru import logger

            logger.info("LLM used: reason={reason} query_type={qtype} confidence={conf}", reason=llm_reason, qtype=classification.query_type, conf=validated.confidence)
            llm_answer, llm_conf = generate_explanation(resolved_question, context_payload)
            confidence = llm_conf if llm_conf in ("high", "medium", "low") else validated.confidence
            answer = llm_answer
        else:
            # Deterministic, low-latency answer generation.
            company_lines = [
                f"- {c.entity.get('name')} ({c.entity.get('website') or 'no website'})"
                for c in validated.companies[: min(5, request.top_k)]
            ]
            tech_lines = [
                f"- {t.entity.get('title')} (category={t.entity.get('category')}, maturity={t.entity.get('maturity')})"
                for t in validated.technologies[: min(5, request.top_k)]
            ]

            q_lower = resolved_question.lower()
            if any(k in q_lower for k in ["how many", "count", "number of"]):
                answer = (
                    f"Deterministic counts from the dataset: "
                    f"{len(validated.companies)} matching companies and {len(validated.technologies)} matching technologies."
                )
            elif "technology" in q_lower and not ("company" in q_lower or "companies" in q_lower):
                answer = "Top matching technologies from your constraints:\n" + "\n".join(tech_lines)
            else:
                answer = (
                    "Top matching companies and technologies from your constraints.\n\n"
                    + "Companies:\n"
                    + ("\n".join(company_lines) if company_lines else "- None")
                    + "\n\nTechnologies:\n"
                    + ("\n".join(tech_lines) if tech_lines else "- None")
                )
            confidence = validated.confidence
            llm_reason = llm_reason if llm_used else None

        latency_ms = (time.perf_counter() - start) * 1000

        response = QueryResponse(
            answer=answer,
            source=source,
            data_used=data_refs,
            confidence=confidence,
            llm_used=llm_used,
            query_type=classification.query_type,
            latency_ms=latency_ms,
            llm_reason=(llm_reason if llm_used else None),
            data_used_raw=data_used_raw,
        )

        cache_set(cache_key, response.model_dump(), ttl_seconds=600)

        # Update conversation state for follow-ups.
        new_state = ConversationState(
            last_company_names=[c.entity.get("name") for c in validated.companies[:5] if c.entity.get("name")],
            last_technology_titles=[t.entity.get("title") for t in validated.technologies[:5] if t.entity.get("title")],
            last_industries=entities.industries,
            last_countries=entities.countries,
            last_question_norm=self._normalize_key(resolved_question),
        )
        set_state(request.conversation_id, new_state)

        from loguru import logger

        logger.info(
            "query_done conv_id={cid} query_type={qtype} confidence={conf} llm_used={llm} latency_ms={lat:.2f}",
            cid=request.conversation_id,
            qtype=classification.query_type,
            conf=confidence,
            llm=llm_used,
            lat=latency_ms,
        )

        return response

