from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from diskcache import Cache

from config.settings import get_settings


@dataclass
class CacheEntry:
    value: Any


def _make_cache() -> Cache:
    settings = get_settings()
    # diskcache uses a directory on disk.
    return Cache(str(settings.cache_dir / "backend"))


_CACHE: Cache | None = None


def get_backend_cache() -> Cache:
    global _CACHE
    if _CACHE is None:
        _CACHE = _make_cache()
    return _CACHE


def cache_get(key: str) -> Any | None:
    return get_backend_cache().get(key, default=None)


def cache_set(key: str, value: Any, ttl_seconds: int | None = None) -> None:
    settings = get_settings()
    ttl = ttl_seconds if ttl_seconds is not None else settings.cache_ttl
    get_backend_cache().set(key, value, expire=ttl)

