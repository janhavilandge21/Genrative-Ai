"""
Caching utilities.
"""

