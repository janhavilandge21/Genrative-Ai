from __future__ import annotations


def should_use_llm(
    query_type: str,
    confidence: str,
    enable_llm: bool,
) -> tuple[bool, str]:
    """
    Decide whether LLM is needed.
    We only use LLM for narrative/explanations, never for deterministic identification.
    """
    if not enable_llm:
        return False, "LLM disabled by request."

    if query_type in ("EXPLANATION", "COMPLEX"):
        return True, f"Query type requires explanation ({query_type})."

    if confidence == "low":
        return True, "Low confidence: use LLM to summarize/reconcile retrieved facts."

    return False, "Deterministic answer is sufficient."

