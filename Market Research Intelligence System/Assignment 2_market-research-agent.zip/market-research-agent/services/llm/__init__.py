"""
LLM integration (Groq/OpenAI) with cost/latency controls.
"""

