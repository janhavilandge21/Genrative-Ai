"""
Service layer: retrieval, orchestration, validation, LLM integration, caching.
"""

