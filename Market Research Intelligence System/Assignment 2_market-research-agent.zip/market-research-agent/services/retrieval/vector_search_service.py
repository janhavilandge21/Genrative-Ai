from __future__ import annotations

from dataclasses import dataclass

from core.types import Candidate
from retrieval.semantic_index import get_semantic_index


@dataclass
class VectorSearchResult:
    companies: list[Candidate]
    technologies: list[Candidate]


class VectorSearchService:
    def __init__(self):
        self.index = get_semantic_index()

    def search(self, query: str, top_k_companies: int = 15, top_k_tech: int = 8) -> VectorSearchResult:
        comp = self.index.search_companies(query, k=top_k_companies)
        tech = self.index.search_technologies(query, k=top_k_tech)

        # Rule engine scores are in a different numeric range than cosine similarity.
        # Scale vector scores so they can participate in hybrid re-ranking/validation.
        score_scale = 4.0

        comp_cands: list[Candidate] = [
            Candidate(
                kind="company",
                entity=d,
                score=float(score) * score_scale,
                matched_justification=["semantic match (faiss)"],
            )
            for d, score in comp
        ]
        tech_cands: list[Candidate] = [
            Candidate(
                kind="technology",
                entity=d,
                score=float(score) * score_scale,
                matched_justification=["semantic match (faiss)"],
            )
            for d, score in tech
        ]
        return VectorSearchResult(companies=comp_cands, technologies=tech_cands)

