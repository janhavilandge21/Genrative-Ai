"""
Retrieval services: deterministic rule-based and vector (FAISS) search.
"""

