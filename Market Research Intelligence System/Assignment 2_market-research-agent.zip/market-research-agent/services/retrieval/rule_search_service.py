from __future__ import annotations

from core.rule_engine import RuleEngine


class RuleSearchService:
    def __init__(self):
        self.engine = RuleEngine()

    def search(self, question: str, query_type: str, entities, top_k: int):
        # query_type is one of QueryType string literals; keep loose for runtime.
        return self.engine.retrieve(question=question, query_type=query_type, entities=entities, top_k=top_k)

