"""
tools/search_tools.py
Tool abstraction layer for the agentic orchestrator.
Each tool is a pure function: input → output, no side effects.
The agent calls these tools in sequence during multi-step reasoning.
"""

import time
from loguru import logger
from core.data_loader import get_data_store
from core.vector_search import get_faiss_engine
from agent.intent_parser import ParsedIntent


def tool_semantic_search_companies(query: str, k: int = 20) -> dict:
    """
    Tool: Semantic search for companies matching a free-text query.
    Uses FAISS vector similarity — no LLM.
    Returns ranked companies with similarity scores.
    """
    t0 = time.time()
    engine  = get_faiss_engine()
    results = engine.search_companies(query, k=k)
    logger.info(f"[TOOL] semantic_search_companies | query='{query[:50]}' | found={len(results)} | {round((time.time()-t0)*1000,1)}ms")
    return {
        "tool":    "semantic_search_companies",
        "query":   query,
        "results": results,
        "count":   len(results),
        "latency_ms": round((time.time()-t0)*1000, 1),
    }


def tool_semantic_search_technologies(query: str, k: int = 10) -> dict:
    """
    Tool: Semantic search for technologies matching a query.
    Returns ranked technologies with scores.
    """
    t0 = time.time()
    engine  = get_faiss_engine()
    results = engine.search_technologies(query, k=k)
    logger.info(f"[TOOL] semantic_search_technologies | query='{query[:50]}' | found={len(results)}")
    return {
        "tool":    "semantic_search_technologies",
        "query":   query,
        "results": results,
        "count":   len(results),
        "latency_ms": round((time.time()-t0)*1000, 1),
    }


def tool_filter_companies(intent: ParsedIntent) -> dict:
    """
    Tool: Filter companies by structured constraints extracted from intent.
    Deterministic — no LLM.
    """
    t0    = time.time()
    store = get_data_store()

    # Apply filters
    results = store.filter_companies(
        industries  =intent.industries if intent.industries else None,
        countries   =intent.geographies if intent.geographies else None,
        company_type=intent.company_types[0] if intent.company_types else None,
    )

    # Keyword fallback: search by focus keywords if structured filter gave nothing
    if not results and intent.focus_keywords:
        for kw in intent.focus_keywords[:3]:
            kw_results = store.text_search_companies(kw)
            results.extend(kw_results)
        # Deduplicate
        seen = set()
        deduped = []
        for c in results:
            if c["id"] not in seen:
                seen.add(c["id"])
                deduped.append(c)
        results = deduped

    logger.info(f"[TOOL] filter_companies | industries={intent.industries} | countries={intent.geographies} | found={len(results)}")
    return {
        "tool":    "filter_companies",
        "filters": {
            "industries":   intent.industries,
            "geographies":  intent.geographies,
            "company_types":intent.company_types,
        },
        "results": results,
        "count":   len(results),
        "latency_ms": round((time.time()-t0)*1000, 1),
    }


def tool_filter_technologies(intent: ParsedIntent) -> dict:
    """
    Tool: Filter technologies by maturity/novelty/category constraints.
    """
    t0    = time.time()
    store = get_data_store()

    results = store.filter_technologies(
        maturity=intent.maturity,
        novelty =intent.novelty,
    )

    # Also search by tech keywords from intent
    if intent.technologies:
        for tech_kw in intent.technologies[:3]:
            kw_results = store.text_search_technologies(tech_kw)
            results.extend(kw_results)
        seen = set()
        deduped = []
        for t in results:
            if t["id"] not in seen:
                seen.add(t["id"])
                deduped.append(t)
        results = deduped

    logger.info(f"[TOOL] filter_technologies | maturity={intent.maturity} | novelty={intent.novelty} | found={len(results)}")
    return {
        "tool":    "filter_technologies",
        "filters": {"maturity": intent.maturity, "novelty": intent.novelty, "tech_keywords": intent.technologies},
        "results": results,
        "count":   len(results),
        "latency_ms": round((time.time()-t0)*1000, 1),
    }


def tool_get_company_technologies(company_id: str, company_name: str) -> dict:
    """
    Tool: Get all technologies for a specific company.
    Direct O(1) lookup — no LLM.
    """
    store  = get_data_store()
    techs  = store.get_techs_by_company(company_id)
    logger.info(f"[TOOL] get_company_technologies | company={company_name} | techs={len(techs)}")
    return {
        "tool":       "get_company_technologies",
        "company_id": company_id,
        "company_name": company_name,
        "technologies": techs,
        "count":      len(techs),
    }


def tool_digital_footprint_discovery(intent: ParsedIntent) -> dict:
    """
    Tool: Discover companies from their 'digital footprint' in the dataset.
    Searches across: description, industries, focus areas, activities, domain.
    This implements the assignment requirement:
    'Company listing should discover from digital footprint'
    (NOT direct LLM identification).
    """
    t0    = time.time()
    store = get_data_store()

    # Build composite search query from all available signals
    search_parts = []
    if intent.industries:   search_parts.extend(intent.industries)
    if intent.technologies: search_parts.extend(intent.technologies)
    if intent.focus_keywords: search_parts.extend(intent.focus_keywords[:5])

    composite_query = " ".join(search_parts) if search_parts else intent.raw_query

    # Multi-signal discovery: combine results from different search dimensions
    discovered = {}

    # Signal 1: FAISS semantic similarity
    faiss_results = get_faiss_engine().search_companies(composite_query, k=25)
    for c in faiss_results:
        cid = c["id"]
        if cid not in discovered:
            discovered[cid] = {**c, "discovery_signals": [], "discovery_score": 0.0}
        discovered[cid]["discovery_signals"].append(f"semantic_match (score={c.get('semantic_score',0):.3f})")
        discovered[cid]["discovery_score"] += c.get("semantic_score", 0) * 0.5

    # Signal 2: Industry text match
    for ind in intent.industries:
        for c in store.text_search_companies(ind):
            cid = c["id"]
            if cid not in discovered:
                discovered[cid] = {**c, "discovery_signals": [], "discovery_score": 0.0}
            discovered[cid]["discovery_signals"].append(f"industry_match:{ind}")
            discovered[cid]["discovery_score"] += 0.3

    # Signal 3: Technology capability match
    for tech_kw in intent.technologies:
        for c in store.text_search_companies(tech_kw):
            cid = c["id"]
            if cid not in discovered:
                discovered[cid] = {**c, "discovery_signals": [], "discovery_score": 0.0}
            discovered[cid]["discovery_signals"].append(f"technology_match:{tech_kw}")
            discovered[cid]["discovery_score"] += 0.25

    # Signal 4: Geographic match
    for geo in intent.geographies:
        for c in store.companies:
            if any(geo.lower() in cc.lower() for cc in c.get("countries", [])):
                cid = c["id"]
                if cid not in discovered:
                    discovered[cid] = {**c, "discovery_signals": [], "discovery_score": 0.0}
                discovered[cid]["discovery_signals"].append(f"geography_match:{geo}")
                discovered[cid]["discovery_score"] += 0.2

    # Signal 5: Focus keyword match
    for kw in intent.focus_keywords[:5]:
        for c in store.text_search_companies(kw):
            cid = c["id"]
            if cid not in discovered:
                discovered[cid] = {**c, "discovery_signals": [], "discovery_score": 0.0}
            discovered[cid]["discovery_signals"].append(f"keyword_match:{kw}")
            discovered[cid]["discovery_score"] += 0.15

    # Sort by discovery score
    results = sorted(discovered.values(), key=lambda x: x["discovery_score"], reverse=True)

    logger.info(f"[TOOL] digital_footprint_discovery | discovered={len(results)} | {round((time.time()-t0)*1000,1)}ms")
    return {
        "tool":    "digital_footprint_discovery",
        "query":   composite_query,
        "results": results,
        "count":   len(results),
        "latency_ms": round((time.time()-t0)*1000, 1),
    }
