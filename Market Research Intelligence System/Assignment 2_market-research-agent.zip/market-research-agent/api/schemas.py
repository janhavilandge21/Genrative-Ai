"""
api/schemas.py — Pydantic request/response models
"""
from pydantic import BaseModel, Field
from typing import Any, Optional


class ResearchRequest(BaseModel):
    query: str = Field(
        ..., min_length=5, max_length=1000,
        description="Natural language market research query",
        examples=[
            "Industrial AI startups working on predictive maintenance in oil & gas",
            "Semiconductor companies developing smart sensors in Asia",
        ]
    )
    max_results: int = Field(10, ge=1, le=50)


class AgentStepOut(BaseModel):
    name:        str
    status:      str
    latency_ms:  float
    output_count: int
    notes:       str


class CompanyOut(BaseModel):
    name:              str
    website:           str
    company_type:      str
    industries:        list[str]
    countries:         list[str]
    headquarters:      str
    description:       str
    revenue:           str
    activities:        list[dict]
    relevance_score:   float
    justification:     str
    matched_criteria:  list[str]
    technologies:      list[dict]
    discovery_signals: list[str]


class TechnologyOut(BaseModel):
    title:             str
    company:           str
    maturity:          str
    novelty:           str
    category:          str
    description:       str
    applications:      list[str]
    key_highlights:    list[str]
    differentiating_factors: list[str]
    relevance_score:   float
    justification:     str
    matched_criteria:  list[str]


class ParsedIntentOut(BaseModel):
    industries:    list[str]
    technologies:  list[str]
    company_types: list[str]
    geographies:   list[str]
    maturity:      Optional[str]
    novelty:       Optional[str]
    focus_keywords: list[str]


class ResearchResponse(BaseModel):
    query:                 str
    executive_summary:     str
    parsed_intent:         ParsedIntentOut
    companies:             list[CompanyOut]
    technologies:          list[TechnologyOut]
    agent_steps:           list[AgentStepOut]
    total_latency_ms:      float
    llm_used:              bool
    total_candidates_found: dict
    metadata:              dict


class HealthResponse(BaseModel):
    status:            str
    data_loaded:       bool
    companies_count:   int
    technologies_count: int
    faiss_ready:       bool
    groq_configured:   bool
    llm_usage_stats:   dict
