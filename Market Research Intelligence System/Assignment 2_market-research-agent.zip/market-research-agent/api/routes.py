"""
api/routes.py — FastAPI route handlers
"""
from fastapi import APIRouter, HTTPException, BackgroundTasks
from loguru import logger
import time

from api.schemas import ResearchRequest, ResearchResponse, HealthResponse
from agent.orchestrator import get_orchestrator
from agent.llm_synthesizer import get_synthesizer
from core.data_loader import get_data_store
from core.vector_search import get_faiss_engine
from config.settings import get_settings

router = APIRouter()


def _build_response(result) -> dict:
    """Convert ResearchResult to API response dict."""

    companies_out = []
    for rc in result.companies:
        c = rc["company"]
        companies_out.append({
            "name":             c.get("name", "").title(),
            "website":          c.get("website", ""),
            "company_type":     c.get("company_type", ""),
            "industries":       c.get("industries", []),
            "countries":        c.get("countries", []),
            "headquarters":     c.get("headquarters", ""),
            "description":      c.get("description", "")[:500],
            "revenue":          c.get("revenue", ""),
            "activities":       c.get("activities", [])[:3],
            "relevance_score":  rc["relevance_score"],
            "justification":    rc["justification"],
            "matched_criteria": rc["matched_criteria"],
            "technologies":     [
                {"title": t["title"], "maturity": t["maturity"], "novelty": t["novelty"]}
                for t in rc.get("company_technologies", [])
            ],
            "discovery_signals": c.get("discovery_signals", [])[:3],
        })

    technologies_out = []
    for rt in result.technologies:
        t = rt["technology"]
        technologies_out.append({
            "title":           t.get("title", ""),
            "company":         t.get("company_name", ""),
            "maturity":        t.get("maturity", ""),
            "novelty":         t.get("novelty", ""),
            "category":        t.get("category", ""),
            "description":     t.get("description", "")[:400],
            "applications":    t.get("applications", [])[:4],
            "key_highlights":  t.get("key_highlights", [])[:4],
            "differentiating_factors": t.get("differentiating_factors", [])[:3],
            "relevance_score": rt["relevance_score"],
            "justification":   rt["justification"],
            "matched_criteria":rt["matched_criteria"],
        })

    intent = result.parsed_intent
    return {
        "query":             result.query,
        "executive_summary": result.executive_summary,
        "parsed_intent": {
            "industries":    intent.industries,
            "technologies":  intent.technologies,
            "company_types": intent.company_types,
            "geographies":   intent.geographies,
            "maturity":      intent.maturity,
            "novelty":       intent.novelty,
            "focus_keywords":intent.focus_keywords,
        },
        "companies":     companies_out,
        "technologies":  technologies_out,
        "agent_steps": [
            {
                "name":         s.name,
                "status":       s.status,
                "latency_ms":   s.latency_ms,
                "output_count": s.output_count,
                "notes":        s.notes,
            }
            for s in result.agent_steps
        ],
        "total_latency_ms": result.total_latency_ms,
        "llm_used":         result.llm_used,
        "total_candidates_found": {
            "companies":   result.total_companies_found,
            "technologies":result.total_techs_found,
        },
        "metadata": result.metadata,
    }


@router.post("/research", tags=["Research Agent"])
def run_research(req: ResearchRequest):
    """
    Run the full 5-step agentic market research pipeline.

    Pipeline: PARSE → DISCOVER → SEARCH → VALIDATE → SYNTHESIZE

    Returns structured company and technology profiles with relevance justification.
    LLM is used ONLY for executive summary synthesis, never for company identification.
    """
    logger.info(f"Research request: '{req.query[:80]}'")
    try:
        orchestrator = get_orchestrator()
        result       = orchestrator.run(req.query, max_results=req.max_results)

        if not result.parsed_intent.is_valid:
            raise HTTPException(
                status_code=422,
                detail={
                    "error":  "Invalid query",
                    "reason": result.parsed_intent.rejection_reason,
                    "query":  req.query,
                }
            )

        return _build_response(result)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Research pipeline error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/health", response_model=HealthResponse, tags=["System"])
def health():
    """System health check with component status."""
    settings = get_settings()
    store    = get_data_store()
    engine   = get_faiss_engine()
    synth    = get_synthesizer()
    groq_ok  = bool(settings.groq_api_key) and settings.groq_api_key != "gsk_your_groq_key_here"
    return HealthResponse(
        status="healthy",
        data_loaded=store._loaded,
        companies_count=len(store.companies),
        technologies_count=len(store.technologies),
        faiss_ready=engine._ready,
        groq_configured=groq_ok,
        llm_usage_stats=synth.get_usage_stats(),
    )


@router.get("/companies", tags=["Data"])
def list_companies(limit: int = 20, offset: int = 0, search: str | None = None):
    """Browse the company dataset."""
    store = get_data_store()
    companies = store.text_search_companies(search) if search else store.companies
    page = companies[offset: offset + limit]
    return {
        "total":  len(companies),
        "limit":  limit,
        "offset": offset,
        "companies": [
            {
                "id":       c["id"],
                "name":     c["name"].title(),
                "type":     c["company_type"],
                "hq":       c["headquarters"],
                "industries": c["industries"][:2],
                "countries": c["countries"][:3],
            }
            for c in page
        ],
    }


@router.get("/technologies", tags=["Data"])
def list_technologies(maturity: str | None = None, novelty: str | None = None):
    """Browse the technology dataset."""
    store = get_data_store()
    techs = store.filter_technologies(maturity=maturity, novelty=novelty)
    return {
        "total": len(techs),
        "technologies": [
            {
                "id":       t["id"],
                "title":    t["title"],
                "company":  t["company_name"],
                "maturity": t["maturity"],
                "novelty":  t["novelty"],
                "category": t["category"],
            }
            for t in techs
        ],
    }


@router.get("/example-queries", tags=["Research Agent"])
def example_queries():
    """Return example research queries to try."""
    return {
        "examples": [
            "Industrial AI companies working on predictive maintenance",
            "Semiconductor companies developing smart sensors",
            "Large enterprises in automation and Industry 4.0",
            "Companies with commercialized IoT technologies",
            "Analog semiconductor companies in USA and Europe",
            "Companies working on connected machinery",
            "High novelty technology companies in industrial automation",
        ]
    }


@router.post("/admin/rebuild-index", tags=["Admin"])
def rebuild_index():
    """Force rebuild FAISS index after data changes."""
    engine = get_faiss_engine()
    engine.invalidate()
    engine.build_or_load()
    return {"message": "FAISS index rebuilt."}
