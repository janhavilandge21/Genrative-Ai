from __future__ import annotations

import re

from core.types import ExtractedEntities
from memory.conversation_store import ConversationState


_PRONOUN_RE = re.compile(r"\b(it|this|that|these|those|they|them|their)\b", re.IGNORECASE)


def rewrite_for_follow_up(
    question: str,
    state: ConversationState,
    entities: ExtractedEntities,
) -> tuple[str, ExtractedEntities]:
    """
    Resolve pronoun-based follow-ups deterministically by injecting last entities.
    """
    q_lower = question.lower()

    has_pronoun = _PRONOUN_RE.search(question) is not None
    has_explicit_entities = bool(entities.company_names or entities.technology_titles)

    if not has_pronoun or has_explicit_entities:
        return question, entities

    tech_ref = any(k in q_lower for k in ["technology", "technologies", "platform", "solution", "model", "ai"])
    company_ref = any(k in q_lower for k in ["company", "startup", "firm", "provider", "business"])

    # If user isn't explicit, we inject both if available (hybrid ranking will handle it).
    if tech_ref and state.last_technology_titles:
        entities.technology_titles = [*entities.technology_titles, *state.last_technology_titles][:6]
    if company_ref and state.last_company_names:
        entities.company_names = [*entities.company_names, *state.last_company_names][:6]

    if (tech_ref is False and company_ref is False) or (not tech_ref and state.last_company_names):
        if state.last_company_names:
            entities.company_names = [*entities.company_names, *state.last_company_names][:6]
        if state.last_technology_titles:
            entities.technology_titles = [*entities.technology_titles, *state.last_technology_titles][:6]

    # Return question unmodified to preserve deterministic retrieval.
    return question, entities

