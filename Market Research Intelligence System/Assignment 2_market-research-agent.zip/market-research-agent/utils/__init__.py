"""
Shared utilities.
"""

