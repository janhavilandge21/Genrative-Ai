# Market Research Agent (Smart Data + AI Assisted)

This project is a backend-driven research assistant that helps answer business-related questions using structured company and technology data.

Instead of behaving like a generic chatbot, the system is designed to first understand the query using rule-based logic and data retrieval. AI is used only when needed—for generating explanations or summaries. This approach makes the system more reliable, faster, and cost-efficient.

---

##  What this project does

* Takes user questions related to companies and technologies
* Searches structured datasets (`companies.json`, `technologies.json`)
* Applies filtering, lookup, and reasoning logic
* Returns accurate and structured answers
* Uses AI only when deeper explanation is required

---

##  How to Run the Project

1. Install required dependencies:

```bash
pip install -r requirements.txt
```

2. Start the backend server:

```bash
uvicorn app.main:app --host 127.0.0.1 --port 8001
```

3. Run the frontend:

```bash
streamlit run frontend/app.py
```

---

## 📂 Data Used

The system works on two main datasets:

* `companies.json` → Contains company-related information
* `technologies.json` → Contains technology-related information

These are loaded and processed at the start of the application.

---

## 🔗 API Endpoints

### Health Check

* `GET /v1/health`
  Used to verify if the server is running properly.

### Query Endpoint

* `POST /v1/query`
  Used to ask research questions.

Example request:

```json
{
  "conversation_id": "c1",
  "question": "B2B healthcare analytics companies in United States",
  "top_k": 5
}
```

---

##  How the System Works

1. User asks a question
2. System validates input and extracts important entities
3. Classifies the query type (fact, lookup, explanation, etc.)
4. Searches data using:

   * Rule-based filtering
   * Optional semantic search
5. Validates results and ranks them
6. Uses AI only if explanation is required
7. Returns structured output

---

##  Key Features

* Clean modular architecture
* Fast and deterministic responses for most queries
* AI usage is controlled to reduce cost
* Supports follow-up questions using conversation memory
* Response caching for better performance

---

## ⚡ Performance Optimization

* Data is preloaded at startup
* AI is used only when necessary
* Caching avoids repeated computations
* Hybrid retrieval is used selectively

---

##  Design Decisions

* Priority is given to accuracy over unnecessary AI usage
* Rule-based logic ensures consistent results
* AI is treated as a helper, not the core decision-maker

---

##  Example Use Cases

* Finding companies in a specific domain
* Listing technologies used by a company
* Counting companies based on filters
* Multi-step research queries

---

## Summary

This project is built to demonstrate how structured data systems can be combined with controlled AI usage to create a reliable and efficient research assistant. It focuses on practical design, performance, and real-world usability rather than just using AI everywhere.

---
