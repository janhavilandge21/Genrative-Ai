"""
config/settings.py
Centralized configuration — reads from .env
"""
from pydantic_settings import BaseSettings
from pydantic import Field
from functools import lru_cache
from pathlib import Path


class Settings(BaseSettings):
    groq_api_key: str = Field("", env="GROQ_API_KEY")
    llm_model: str = Field("llama3-8b-8192", env="LLM_MODEL")
    embedding_model: str = Field("all-MiniLM-L6-v2", env="EMBEDDING_MODEL")
    cache_ttl: int = Field(3600, env="CACHE_TTL")
    max_conversation_turns: int = Field(20, env="MAX_CONVERSATION_TURNS")
    log_level: str = Field("INFO", env="LOG_LEVEL")

    # Resolved paths (relative to project root)
    @property
    def base_dir(self) -> Path:
        return Path(__file__).parent.parent

    @property
    def companies_file(self) -> Path:
        return self.base_dir / "data" / "companies.json"

    @property
    def technologies_file(self) -> Path:
        return self.base_dir / "data" / "technologies.json"

    @property
    def faiss_index_dir(self) -> Path:
        return self.base_dir / "data" / "faiss_index"

    @property
    def cache_dir(self) -> Path:
        return self.base_dir / "data" / "cache"

    model_config = {"env_file": ".env", "extra": "ignore"}

    def ensure_dirs(self):
        for d in [self.faiss_index_dir, self.cache_dir]:
            d.mkdir(parents=True, exist_ok=True)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    s = Settings()
    s.ensure_dirs()
    return s
