# Company Intelligence API

This project is a backend system that answers user questions about companies and technologies using structured data.

The main idea behind this project was to build something more reliable than a normal chatbot. Instead of depending completely on AI, I designed the system in a way that it first tries to answer questions using data and logic. AI is only used when explanation or comparison is actually needed.

---

## 🚀 What this project does

* Takes user queries in normal English
* Understands what the user is asking
* Searches company and technology data
* Applies filters, relationships, and logic
* Returns a structured and meaningful answer

For most questions, the system does not use AI at all. It directly answers using data, which makes it faster and more accurate.

---

## 🛠️ How to run the project

1. Install dependencies:

```bash
pip install -r requirements.txt
```

2. Add your API key in `.env` file:

```
GROQ_API_KEY=your_api_key
```

3. Run the backend:

```bash
python -m uvicorn main:app --reload --port 8000
```

4. (Optional) Run test file:

```bash
python tests/test_queries.py
```

---

## 📂 Data used

The project works on two datasets:

* `companies.json` → contains company information
* `technologies.json` → contains technology details

These files are loaded at startup and converted into a format that allows fast searching.

---

## 🔗 API endpoints

* `POST /api/v1/query` → main endpoint to ask questions
* `GET /api/v1/health` → check if server is running
* `GET /api/v1/companies` → list all companies
* `GET /api/v1/technologies` → list all technologies

---

## 🧠 How the system works (simple explanation)

1. User asks a question
2. System cleans and validates the input
3. It identifies key things like company name, technology, filters
4. It decides the type of question (lookup, count, explanation, etc.)
5. For most queries:

   * It directly fetches data using rules (fast and accurate)
6. For explanation-type queries:

   * It uses AI to generate a meaningful answer
7. Finally, it returns a structured response

---

## ⚙️ Key features

* Fast response (most queries are solved in milliseconds)
* Uses AI only when required
* Supports follow-up questions using session memory
* Clean and modular backend design
* Handles real-world query patterns

---

## ⚡ Performance approach

* Data is preloaded for faster access
* Rule-based logic avoids unnecessary API calls
* AI usage is limited to reduce cost and latency
* Caching is used to avoid repeated work

---

## ⚖️ Design thinking

While building this, I focused on:

* Not overusing AI
* Making responses reliable
* Keeping the system fast
* Designing something practical for real-world use

---

## 🧪 Example use cases

* Find companies in a specific domain
* Check which technologies a company uses
* Count companies based on filters
* Ask follow-up questions naturally

---

## 📌 Summary

This project shows how we can combine structured data with controlled AI usage to build a smart and efficient system. Instead of blindly relying on AI, it uses a balanced approach where logic handles most of the work and AI is used only when needed.

---
