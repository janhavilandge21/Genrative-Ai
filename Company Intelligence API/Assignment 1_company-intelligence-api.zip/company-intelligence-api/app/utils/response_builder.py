"""
app/utils/response_builder.py
Structured response payload used by all handlers.
"""
from dataclasses import dataclass, field


@dataclass
class ResponsePayload:
    answer:     str
    source:     list[str]
    data_used:  list[dict]
    confidence: str       # "high" | "medium" | "low"
    llm_used:   bool
    query_type: str
    latency_ms: float = 0.0
