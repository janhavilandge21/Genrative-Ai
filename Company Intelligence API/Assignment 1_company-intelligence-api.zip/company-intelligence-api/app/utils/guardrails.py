"""
app/utils/guardrails.py
Input validation, sanitization, and prompt injection protection.
All checks are deterministic — zero LLM cost.
"""

import re

MAX_LEN = 500
MIN_LEN = 2

_INJECTION_PATTERNS = [
    r"ignore (previous|above|all) instructions",
    r"disregard (your|all|previous) (instructions|rules|guidelines)",
    r"you are now\b",
    r"act as (a|an) (unrestricted|jailbreak|evil|hacker|different)",
    r"forget (everything|all|your training)",
    r"do not follow",
    r"override (your|all|previous)",
    r"system prompt",
    r"<\|.*?\|>",
    r"\[INST\]",
    r"###\s*(system|instruction)",
    r"reveal (your|the) (prompt|system|instructions|api key)",
    r"what is your (system prompt|instruction|api key)",
]


def validate_input(query: str) -> tuple[bool, str]:
    """Returns (is_valid, error_message)."""
    if not query or not query.strip():
        return False, "Query cannot be empty."

    q = query.strip()

    if len(q) < MIN_LEN:
        return False, f"Query too short (min {MIN_LEN} chars)."

    if len(q) > MAX_LEN:
        return False, (
            f"Query too long ({len(q)} chars, max {MAX_LEN}). "
            "Please be more concise."
        )

    for pattern in _INJECTION_PATTERNS:
        if re.search(pattern, q, re.IGNORECASE):
            return False, (
                "Your query contains patterns that are not allowed. "
                "Please ask a straightforward question about companies or technologies."
            )

    return True, ""


def sanitize_input(query: str) -> str:
    """Strip dangerous characters while preserving meaning."""
    q = query.strip()
    q = re.sub(r'[\x00-\x08\x0b-\x0c\x0e-\x1f\x7f]', '', q)  # control chars
    q = re.sub(r'<[^>]+>', '', q)   # HTML tags
    q = re.sub(r'\s+', ' ', q)      # collapse whitespace
    return q.strip()
