"""
app/utils/logger.py
Loguru-based structured logging setup.
"""
import sys
from pathlib import Path
from loguru import logger


def setup_logger(log_level: str = "INFO"):
    logger.remove()

    # Console — human-readable
    logger.add(
        sys.stdout,
        colorize=True,
        format=(
            "<green>{time:HH:mm:ss}</green> | "
            "<level>{level:<8}</level> | "
            "<cyan>{name}</cyan> | {message}"
        ),
        level=log_level,
    )

    # File — structured, rotating
    log_file = Path("logs") / "api.log"
    log_file.parent.mkdir(exist_ok=True)
    logger.add(
        str(log_file),
        rotation="10 MB",
        retention="7 days",
        level="DEBUG",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level} | {name}:{line} | {message}",
    )

    return logger
