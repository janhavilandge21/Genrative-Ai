"""
app/services/query_engine.py
Main orchestration service.

Flow for every query:
  1. Validate + sanitize input
  2. Get/create conversation session
  3. Classify query type (zero-cost)
  4. Route to the correct handler
  5. Build structured response
  6. Store turns in conversation memory
  7. Return explainable response dict
"""

import time
import json
from loguru import logger

from app.core.query_classifier import QueryClassifier, QueryType, ClassificationResult
from app.core.data_loader import get_data_store
from app.core.vector_search import get_search_engine
from app.core.llm_gate import get_llm_gate
from app.memory.conversation_store import get_conversation_store, Turn
from app.utils.response_builder import ResponsePayload
from app.utils.guardrails import validate_input, sanitize_input


class QueryEngine:

    def __init__(self):
        self.classifier = QueryClassifier()
        self.data       = get_data_store()
        self.search     = get_search_engine()
        self.llm        = get_llm_gate()
        self.conv       = get_conversation_store()

    # ── Entry point ────────────────────────────────────────────────────────────
    def process(self, query: str, session_id: str | None = None) -> dict:
        t0 = time.time()

        # 1. Validate
        ok, msg = validate_input(query)
        if not ok:
            return self._error(msg, session_id, t0)
        query = sanitize_input(query)

        # 2. Session
        session_id, session = self.conv.get_or_create(session_id)

        # 3. Classify
        ctx = session.get_context_for_classifier()
        clf = self.classifier.classify(query, ctx)
        logger.info(
            f"CLASSIFY | type={clf.query_type} "
            f"conf={clf.confidence:.2f} llm={clf.requires_llm} | {query[:60]}"
        )

        # 4. Route
        try:
            payload = self._route(query, clf)
        except Exception as e:
            logger.error(f"Handler error: {e}")
            payload = ResponsePayload(
                answer=f"Error processing your query: {str(e)[:120]}",
                source=[], data_used=[], confidence="low",
                llm_used=False, query_type=str(clf.query_type),
            )

        # 5. Timing
        latency_ms = round((time.time() - t0) * 1000, 1)
        payload.latency_ms = latency_ms

        # 6. Store in memory
        entities = clf.extracted_entities
        session.add_turn(Turn(
            role="user", content=query,
            query_type=str(clf.query_type), entities_mentioned=entities,
        ))
        session.add_turn(Turn(
            role="assistant", content=payload.answer,
            query_type=str(clf.query_type), entities_mentioned=entities,
            llm_used=payload.llm_used, latency_ms=latency_ms,
        ))

        logger.info(
            f"DONE | type={clf.query_type} "
            f"llm={payload.llm_used} conf={payload.confidence} "
            f"{latency_ms}ms"
        )

        return {
            "session_id":  session_id,
            "answer":      payload.answer,
            "source":      payload.source,
            "data_used":   payload.data_used,
            "confidence":  payload.confidence,
            "llm_used":    payload.llm_used,
            "llm_reason":  clf.llm_reason,
            "query_type":  str(clf.query_type),
            "latency_ms":  latency_ms,
            "entities":    entities,
        }

    # ── Router ─────────────────────────────────────────────────────────────────
    def _route(self, query: str, clf: ClassificationResult) -> ResponsePayload:
        qt = clf.query_type
        e  = clf.extracted_entities

        dispatch = {
            QueryType.UNSUPPORTED:    self._unsupported,
            QueryType.LOOKUP:         lambda q, e: self._lookup_tech(q, e),
            QueryType.COMPANY_LOOKUP: lambda q, e: self._lookup_company(q, e),
            QueryType.FACT:           lambda q, e: self._fact(q, e),
            QueryType.FILTER:         lambda q, e: self._filter(q, e),
            QueryType.RELATIONSHIP:   lambda q, e: self._relationship(q, e),
            QueryType.FINANCIAL:      lambda q, e: self._financial(q, e),
            QueryType.ACTIVITY:       lambda q, e: self._activity(q, e),
            QueryType.COMPARISON:     lambda q, e: self._comparison(q, e),
            QueryType.EXPLANATION:    lambda q, e: self._explanation(q, e),
        }
        handler = dispatch.get(qt, lambda q, e: self._explanation(q, e))
        if qt == QueryType.UNSUPPORTED:
            return self._unsupported()
        return handler(query, e)

    # ══════════════════════════════════════════════════════════════════════════
    # HANDLERS — each returns ResponsePayload
    # ══════════════════════════════════════════════════════════════════════════

    # ── LOOKUP ─────────────────────────────────────────────────────────────────
    def _lookup_tech(self, query: str, e: dict) -> ResponsePayload:
        """Direct technology lookup by name — O(1), no LLM."""
        tech = None
        if e.get("tech_name"):
            tech = self.data.get_tech_by_title(e["tech_name"])
        if not tech:
            results = self.search.search_technologies(query, k=1)
            tech    = results[0] if results else None
        if not tech:
            return self._not_found(query, "technology")

        return ResponsePayload(
            answer=self._fmt_tech(tech),
            source=["technologies.json"],
            data_used=[{
                "title":    tech["title"],
                "company":  tech["company_name"],
                "maturity": tech["maturity"],
                "novelty":  tech["novelty"],
            }],
            confidence="high",
            llm_used=False,
            query_type="LOOKUP",
        )

    # ── COMPANY LOOKUP ─────────────────────────────────────────────────────────
    def _lookup_company(self, query: str, e: dict) -> ResponsePayload:
        """Company profile lookup — no LLM."""
        company = None
        if e.get("company_name"):
            company = self.data.get_company_by_name(e["company_name"])
        if not company:
            results = self.search.search_companies(query, k=1)
            company = results[0] if results else None
        if not company:
            return self._not_found(query, "company")

        techs = self.data.get_techs_by_company(company["id"])
        return ResponsePayload(
            answer=self._fmt_company(company, techs),
            source=["companies.json"] + (["technologies.json"] if techs else []),
            data_used=[{
                "name": company["name"],
                "type": company["company_type"],
                "industries": company["industries"][:3],
            }],
            confidence="high",
            llm_used=False,
            query_type="COMPANY_LOOKUP",
        )

    # ── FACT ───────────────────────────────────────────────────────────────────
    def _fact(self, query: str, e: dict) -> ResponsePayload:
        """Deterministic fact/count resolution."""
        q = query.lower()

        # Count total technologies
        if "how many" in q and "technolog" in q and not any(
            w in q for w in ["novelty", "maturity", "production", "line"]
        ):
            n = len(self.data.technologies)
            return ResponsePayload(
                answer=f"There are **{n}** technologies in the dataset.",
                source=["technologies.json"],
                data_used=[{"total_technologies": n}],
                confidence="high", llm_used=False, query_type="FACT",
            )

        # Count total companies
        if "how many" in q and "compan" in q:
            n = len(self.data.companies)
            return ResponsePayload(
                answer=f"There are **{n}** companies in the dataset.",
                source=["companies.json"],
                data_used=[{"total_companies": n}],
                confidence="high", llm_used=False, query_type="FACT",
            )

        # Count by novelty
        if "how many" in q and "novelty" in q:
            for level in ["high", "medium", "low"]:
                if level in q:
                    filtered = self.data.filter_techs(novelty=level)
                    names = [t["title"] for t in filtered]
                    return ResponsePayload(
                        answer=(
                            f"There are **{len(filtered)}** technologies with "
                            f"**{level}** novelty: {', '.join(names)}."
                        ),
                        source=["technologies.json"],
                        data_used=[{"count": len(filtered), "novelty": level, "names": names}],
                        confidence="high", llm_used=False, query_type="FACT",
                    )

        # Count by maturity
        if "how many" in q and any(m in q for m in ["commercialized", "prototype", "development"]):
            for m in ["commercialized", "prototype", "development"]:
                if m in q:
                    filtered = self.data.filter_techs(maturity=m)
                    names = [t["title"] for t in filtered]
                    return ResponsePayload(
                        answer=(
                            f"There are **{len(filtered)}** technologies at "
                            f"**{m}** maturity stage: {', '.join(names)}."
                        ),
                        source=["technologies.json"],
                        data_used=[{"count": len(filtered), "maturity": m}],
                        confidence="high", llm_used=False, query_type="FACT",
                    )

        # Nexeed production lines — specific known fact
        if "production line" in q or ("nexeed" in q and "how many" in q):
            tech = self.data.get_tech_by_title("nexeed")
            if tech:
                for hl in tech["key_highlights"]:
                    if "production" in hl.lower() and any(c.isdigit() for c in hl):
                        return ResponsePayload(
                            answer=f"According to Nexeed key highlights: {hl}",
                            source=["technologies.json"],
                            data_used=[{"technology": "Nexeed", "highlight": hl}],
                            confidence="high", llm_used=False, query_type="FACT",
                        )

        # Fallback: semantic search + lightweight LLM extraction
        results = self.search.search_technologies(query, k=3)
        if not results:
            results = self.search.search_companies(query, k=2)
        if results:
            ctx    = "\n".join(r["full_text"] for r in results[:3])
            answer = self.llm.extract_fact(query, ctx)
            src    = ["technologies.json"] if results[0].get("title") else ["companies.json"]
            return ResponsePayload(
                answer=answer,
                source=src,
                data_used=[{"title": r.get("title", r.get("name", ""))} for r in results[:2]],
                confidence="medium", llm_used=True, query_type="FACT",
            )

        return self._not_found(query)

    # ── FILTER ─────────────────────────────────────────────────────────────────
    def _filter(self, query: str, e: dict) -> ResponsePayload:
        """Filter technologies by maturity/novelty — no LLM."""
        q = query.lower()
        maturity = e.get("maturity_filter")
        novelty  = e.get("novelty_filter")

        if not maturity:
            for m in ["commercialized", "prototype", "development"]:
                if m in q:
                    maturity = m
                    break
        if not novelty:
            import re
            m = re.search(r"(high|medium|low)\s*novelty|novelty.{0,10}(high|medium|low)", q)
            if m:
                novelty = m.group(1) or m.group(2)

        filtered = self.data.filter_techs(maturity=maturity, novelty=novelty)

        if not filtered:
            desc = []
            if maturity: desc.append(f"maturity={maturity}")
            if novelty:  desc.append(f"novelty={novelty}")
            return ResponsePayload(
                answer=f"No technologies found matching: {', '.join(desc) or 'your filter'}.",
                source=["technologies.json"],
                data_used=[],
                confidence="high", llm_used=False, query_type="FILTER",
            )

        lines = [
            f"• **{t['title']}** ({t['company_name']}) — "
            f"Maturity: {t['maturity']}, Novelty: {t['novelty']}"
            for t in filtered
        ]
        desc = []
        if maturity: desc.append(f"maturity=**{maturity}**")
        if novelty:  desc.append(f"novelty=**{novelty}**")

        answer = (
            f"Found **{len(filtered)}** technology/technologies"
            + (f" with {', '.join(desc)}" if desc else "")
            + ":\n\n" + "\n".join(lines)
        )
        return ResponsePayload(
            answer=answer,
            source=["technologies.json"],
            data_used=[{
                "title":    t["title"],
                "maturity": t["maturity"],
                "novelty":  t["novelty"],
            } for t in filtered],
            confidence="high", llm_used=False, query_type="FILTER",
        )

    # ── RELATIONSHIP ───────────────────────────────────────────────────────────
    def _relationship(self, query: str, e: dict) -> ResponsePayload:
        """Company → technologies join — no LLM."""
        company = None
        if e.get("company_name"):
            company = self.data.get_company_by_name(e["company_name"])
        if not company:
            results = self.search.search_companies(query, k=1)
            company = results[0] if results else None
        if not company:
            return ResponsePayload(
                answer="Please specify a company name in your query.",
                source=[], data_used=[],
                confidence="low", llm_used=False, query_type="RELATIONSHIP",
            )

        techs = self.data.get_techs_by_company(company["id"])
        if not techs:
            return ResponsePayload(
                answer=f"No technologies found for **{company['name']}** in the dataset.",
                source=["companies.json", "technologies.json"],
                data_used=[{"company": company["name"]}],
                confidence="high", llm_used=False, query_type="RELATIONSHIP",
            )

        lines = [
            f"• **{t['title']}** — Category: {t['category']}, "
            f"Maturity: {t['maturity']}, Novelty: {t['novelty']}"
            for t in techs
        ]
        answer = (
            f"**{company['name']}** has **{len(techs)}** "
            f"technology/technologies in the dataset:\n\n"
            + "\n".join(lines)
        )
        return ResponsePayload(
            answer=answer,
            source=["companies.json", "technologies.json"],
            data_used=[{"company": company["name"],
                        "technologies": [t["title"] for t in techs]}],
            confidence="high", llm_used=False, query_type="RELATIONSHIP",
        )

    # ── FINANCIAL ──────────────────────────────────────────────────────────────
    def _financial(self, query: str, e: dict) -> ResponsePayload:
        company = None
        if e.get("company_name"):
            company = self.data.get_company_by_name(e["company_name"])
        if not company:
            results = self.search.search_companies(query, k=1)
            company = results[0] if results else None
        if not company:
            return self._not_found(query, "company")

        parts = []
        if company.get("revenue"):    parts.append(f"Revenue: {company['revenue']}")
        if company.get("net_margin"): parts.append(f"Net Margin: {company['net_margin']}")

        answer = (
            f"**{company['name']}** — Financial Data:\n"
            + ("\n".join(f"• {p}" for p in parts)
               if parts else "Detailed financial data not available in the dataset.")
        )
        return ResponsePayload(
            answer=answer,
            source=["companies.json"],
            data_used=[{
                "company":    company["name"],
                "revenue":    company.get("revenue", ""),
                "net_margin": company.get("net_margin", ""),
            }],
            confidence="high" if parts else "medium",
            llm_used=False,
            query_type="FINANCIAL",
        )

    # ── ACTIVITY ───────────────────────────────────────────────────────────────
    def _activity(self, query: str, e: dict) -> ResponsePayload:
        company = None
        if e.get("company_name"):
            company = self.data.get_company_by_name(e["company_name"])
        if not company:
            results = self.search.search_companies(query, k=1)
            company = results[0] if results else None
        if not company:
            return self._not_found(query, "company")

        activities = company.get("activities", [])
        if not activities:
            return ResponsePayload(
                answer=f"No recent activity data available for **{company['name']}**.",
                source=["companies.json"],
                data_used=[{"company": company["name"]}],
                confidence="high", llm_used=False, query_type="ACTIVITY",
            )

        lines = []
        for act in activities[:5]:
            desc  = (act.get("description") or "")[:200]
            title = act.get("title") or act.get("type") or "Activity"
            date  = act.get("date", "")
            label = f"**{title}**" + (f" ({date})" if date else "")
            lines.append(f"• {label}: {desc}...")

        answer = (
            f"Recent activities for **{company['name']}** "
            f"({len(activities)} total):\n\n"
            + "\n\n".join(lines)
        )
        return ResponsePayload(
            answer=answer,
            source=["companies.json"],
            data_used=[{"company": company["name"],
                        "activity_count": len(activities)}],
            confidence="high", llm_used=True, query_type="ACTIVITY",
        )

    # ── COMPARISON ─────────────────────────────────────────────────────────────
    def _comparison(self, query: str, e: dict) -> ResponsePayload:
        """Compare two technologies — uses LLM for synthesis."""
        q_lower = query.lower()
        mentioned = []
        for tech in self.data.technologies:
            if tech["title_lower"] in q_lower:
                mentioned.append(tech)
        if len(mentioned) < 2:
            results = self.search.search_technologies(query, k=4)
            for r in results:
                if not any(m["title"] == r["title"] for m in mentioned):
                    mentioned.append(r)
        if len(mentioned) < 2:
            return ResponsePayload(
                answer="Please name two specific technologies to compare.",
                source=[], data_used=[],
                confidence="low", llm_used=False, query_type="COMPARISON",
            )

        e1, e2   = mentioned[0], mentioned[1]
        d1, d2   = self._tech_ctx(e1), self._tech_ctx(e2)
        answer   = self.llm.compare(e1["title"], d1, e2["title"], d2, query)

        return ResponsePayload(
            answer=answer,
            source=["technologies.json"],
            data_used=[
                {"title": e1["title"], "maturity": e1["maturity"], "novelty": e1["novelty"]},
                {"title": e2["title"], "maturity": e2["maturity"], "novelty": e2["novelty"]},
            ],
            confidence="high", llm_used=True, query_type="COMPARISON",
        )

    # ── EXPLANATION ────────────────────────────────────────────────────────────
    def _explanation(self, query: str, e: dict) -> ResponsePayload:
        """How/why queries — semantic retrieval + LLM synthesis."""
        t_results = self.search.search_technologies(query, k=3)
        c_results = self.search.search_companies(query, k=1)

        sources, ctx_parts = [], []

        if t_results:
            sources.append("technologies.json")
            for t in t_results:
                ctx_parts.append(f"[Technology: {t['title']}]\n{self._tech_ctx(t)}")

        if c_results:
            sources.append("companies.json")
            c = c_results[0]
            ctx_parts.append(
                f"[Company: {c['name']}]\n"
                f"Description: {c['description'][:400]}"
            )

        if not ctx_parts:
            return ResponsePayload(
                answer=(
                    "I could not find relevant data for your query. "
                    "Please ask about a specific company or technology in the dataset."
                ),
                source=[], data_used=[],
                confidence="low", llm_used=False, query_type="EXPLANATION",
            )

        context = "\n\n---\n\n".join(ctx_parts)
        answer  = self.llm.explain(query, context, reason=query[:60])
        top_score = t_results[0].get("semantic_score", 0) if t_results else 0

        return ResponsePayload(
            answer=answer,
            source=list(set(sources)),
            data_used=[{
                "title": t["title"],
                "score": round(t.get("semantic_score", 0), 3),
            } for t in t_results[:3]],
            confidence="high" if top_score > 0.4 else "medium",
            llm_used=True,
            query_type="EXPLANATION",
        )

    # ── Helpers ────────────────────────────────────────────────────────────────
    def _fmt_tech(self, t: dict) -> str:
        lines = [f"## {t['title']}"]
        if t.get("company_name"):
            lines.append(f"**Company:** {t['company_name']}")
        if t.get("category"):
            lines.append(f"**Category:** {t['category']}")
        lines.append(f"**Maturity:** {t['maturity']}  |  **Novelty:** {t['novelty']}")
        if t.get("description"):
            lines.append(f"\n**Description:**\n{t['description']}")
        if t.get("key_highlights"):
            lines.append("\n**Key Highlights:**")
            for h in t["key_highlights"][:4]:
                lines.append(f"• {h}")
        if t.get("applications"):
            lines.append("\n**Applications:**")
            for a in t["applications"][:3]:
                lines.append(f"• {a}")
        if t.get("differentiating_factors"):
            lines.append("\n**Differentiating Factors:**")
            for d in t["differentiating_factors"][:2]:
                lines.append(f"• {d}")
        return "\n".join(lines)

    def _fmt_company(self, c: dict, techs: list[dict]) -> str:
        lines = [f"## {c['name'].title()}"]
        if c.get("company_type"):
            lines.append(f"**Type:** {c['company_type']}")
        if c.get("headquarters"):
            lines.append(f"**HQ:** {c['headquarters']}")
        if c.get("founded_year"):
            lines.append(f"**Founded:** {c['founded_year']}")
        if c.get("industries"):
            lines.append(f"**Industries:** {', '.join(c['industries'][:3])}")
        if c.get("total_employees"):
            lines.append(f"**Employees:** {c['total_employees']}")
        if c.get("description"):
            lines.append(f"\n{c['description'][:400]}...")
        if techs:
            lines.append(f"\n**Technologies in Dataset ({len(techs)}):**")
            for t in techs:
                lines.append(f"• {t['title']} — {t['maturity']}, {t['novelty']} novelty")
        return "\n".join(lines)

    def _tech_ctx(self, t: dict) -> str:
        return (
            f"Title: {t['title']}\n"
            f"Description: {t['description']}\n"
            f"Principle: {t['principle']}\n"
            f"Maturity: {t['maturity']}, Novelty: {t['novelty']}\n"
            f"Category: {t['category']}\n"
            f"Key highlights: {'; '.join(t['key_highlights'][:4])}\n"
            f"Applications: {'; '.join(t['applications'][:3])}\n"
            f"Differentiating factors: {'; '.join(t['differentiating_factors'][:3])}"
        )

    # ── Fallbacks ──────────────────────────────────────────────────────────────
    def _unsupported(self) -> ResponsePayload:
        return ResponsePayload(
            answer=(
                "I can only answer questions about companies and technologies "
                "in the dataset. Try asking about specific technologies (e.g., "
                "Nexeed, OtoSense), company profiles, maturity/novelty levels, "
                "or how a technology works."
            ),
            source=[], data_used=[],
            confidence="high", llm_used=False, query_type="UNSUPPORTED",
        )

    def _not_found(self, query: str, entity_type: str = "entity") -> ResponsePayload:
        return ResponsePayload(
            answer=(
                f"No {entity_type} found matching your query. "
                "Please try a more specific name or check the available "
                "companies and technologies at GET /api/v1/companies or "
                "GET /api/v1/technologies."
            ),
            source=[], data_used=[],
            confidence="low", llm_used=False, query_type="NOT_FOUND",
        )

    def _error(self, message: str, session_id: str | None, t0: float) -> dict:
        return {
            "session_id": session_id or "none",
            "answer":     message,
            "source":     [], "data_used":  [],
            "confidence": "low", "llm_used": False,
            "llm_reason": None, "query_type": "ERROR",
            "latency_ms": round((time.time() - t0) * 1000, 1),
            "entities":   {},
        }


_engine: QueryEngine | None = None


def get_query_engine() -> QueryEngine:
    global _engine
    if _engine is None:
        _engine = QueryEngine()
    return _engine
