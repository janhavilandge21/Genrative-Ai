"""
app/memory/conversation_store.py
Per-session conversation state for multi-turn support.
Stores turn history, last-mentioned entities, session stats.
"""

import uuid
import time
from dataclasses import dataclass, field
from loguru import logger
from config.settings import get_settings


@dataclass
class Turn:
    role:               str
    content:            str
    query_type:         str | None = None
    entities_mentioned: dict       = field(default_factory=dict)
    llm_used:           bool       = False
    latency_ms:         float      = 0.0
    timestamp:          float      = field(default_factory=time.time)


class ConversationSession:
    """Single conversation session with capped turn history."""

    def __init__(self, session_id: str, max_turns: int = 20):
        self.session_id  = session_id
        self.max_turns   = max_turns
        self.turns: list[Turn] = []
        self.created_at  = time.time()
        self.last_active = time.time()
        # Fast-access entity cache
        self.last_tech_name:    str | None = None
        self.last_company_name: str | None = None

    def add_turn(self, turn: Turn):
        self.turns.append(turn)
        self.last_active = time.time()
        e = turn.entities_mentioned or {}
        if e.get("tech_name"):
            self.last_tech_name = e["tech_name"]
        if e.get("company_name"):
            self.last_company_name = e["company_name"]
        # Cap history
        if len(self.turns) > self.max_turns * 2:
            self.turns = self.turns[-(self.max_turns * 2):]

    def get_context_for_classifier(self) -> list[dict]:
        """Return last 6 turns for reference resolution."""
        return [
            {
                "role":               t.role,
                "content":            t.content,
                "entities_mentioned": t.entities_mentioned,
            }
            for t in self.turns[-6:]
        ]

    def get_history_for_display(self) -> list[dict]:
        return [
            {
                "role":      t.role,
                "content":   t.content,
                "timestamp": t.timestamp,
            }
            for t in self.turns
        ]

    def summary_stats(self) -> dict:
        user_turns = [t for t in self.turns if t.role == "user"]
        llm_turns  = [t for t in self.turns if t.llm_used]
        return {
            "session_id":    self.session_id,
            "total_turns":   len(self.turns),
            "user_messages": len(user_turns),
            "llm_calls":     len(llm_turns),
            "duration_s":    round(time.time() - self.created_at, 1),
        }


class ConversationStore:
    """In-memory session store with expiry."""

    def __init__(self, inactivity_timeout: int = 3600):
        self._sessions: dict[str, ConversationSession] = {}
        self.inactivity_timeout = inactivity_timeout
        self.max_turns = get_settings().max_conversation_turns

    def create_session(self) -> str:
        sid = str(uuid.uuid4())
        self._sessions[sid] = ConversationSession(sid, self.max_turns)
        logger.debug(f"Session created: {sid[:8]}")
        return sid

    def get_session(self, session_id: str) -> ConversationSession | None:
        s = self._sessions.get(session_id)
        if s and (time.time() - s.last_active) > self.inactivity_timeout:
            del self._sessions[session_id]
            logger.info(f"Session expired: {session_id[:8]}")
            return None
        return s

    def get_or_create(self, session_id: str | None) -> tuple[str, ConversationSession]:
        if session_id:
            s = self.get_session(session_id)
            if s:
                return session_id, s
        new_id = self.create_session()
        return new_id, self._sessions[new_id]

    def session_count(self) -> int:
        return len(self._sessions)

    def cleanup_expired(self) -> int:
        expired = [
            sid for sid, s in self._sessions.items()
            if (time.time() - s.last_active) > self.inactivity_timeout
        ]
        for sid in expired:
            del self._sessions[sid]
        return len(expired)


_store: ConversationStore | None = None


def get_conversation_store() -> ConversationStore:
    global _store
    if _store is None:
        _store = ConversationStore()
    return _store
