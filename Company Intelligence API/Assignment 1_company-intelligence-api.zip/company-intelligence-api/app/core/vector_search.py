"""
app/core/vector_search.py
FAISS-based semantic search over companies and technologies.
Index built once at startup and persisted to disk.
Subsequent restarts load from disk for fast startup.
"""

import os
import pickle
import numpy as np
from pathlib import Path
from loguru import logger
from config.settings import get_settings
from app.core.data_loader import get_data_store


class FAISSSearchEngine:
    """
    FAISS IndexFlatIP (inner product = cosine similarity for L2-normalized vectors).
    Separate indexes for companies and technologies.
    """

    def __init__(self):
        self.settings    = get_settings()
        self._model      = None
        self._tech_index  = None
        self._comp_index  = None
        self._tech_docs: list[dict] = []
        self._comp_docs: list[dict] = []
        self._ready = False

    # ── Model ──────────────────────────────────────────────────────────────────
    def _get_model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            logger.info(f"Loading embedding model: {self.settings.embedding_model}")
            self._model = SentenceTransformer(
                self.settings.embedding_model,
                device="cpu",
            )
            logger.info("Embedding model ready")
        return self._model

    # ── Build / Load ───────────────────────────────────────────────────────────
    def build_or_load(self):
        """Load FAISS indexes from disk if available, else build fresh."""
        idx_dir   = self.settings.faiss_index_dir
        tech_path = idx_dir / "tech_index.pkl"
        comp_path = idx_dir / "comp_index.pkl"

        if tech_path.exists() and comp_path.exists():
            logger.info("Loading FAISS indexes from disk cache...")
            with open(tech_path, "rb") as f:
                d = pickle.load(f)
                self._tech_index = d["index"]
                self._tech_docs  = d["docs"]
            with open(comp_path, "rb") as f:
                d = pickle.load(f)
                self._comp_index = d["index"]
                self._comp_docs  = d["docs"]
            self._ready = True
            logger.info(f"FAISS ready: {len(self._tech_docs)} techs, "
                        f"{len(self._comp_docs)} companies")
            return

        self._build_indexes()

    def _build_indexes(self):
        import faiss
        store = get_data_store()
        model = self._get_model()
        idx_dir = self.settings.faiss_index_dir

        logger.info("Building FAISS indexes from scratch...")

        # Technologies
        self._tech_docs = store.technologies
        t_vecs = model.encode(
            [t["full_text"] for t in self._tech_docs],
            normalize_embeddings=True,
            show_progress_bar=False,
            batch_size=32,
        ).astype(np.float32)
        dim = t_vecs.shape[1]
        self._tech_index = faiss.IndexFlatIP(dim)
        self._tech_index.add(t_vecs)

        # Companies
        self._comp_docs = store.companies
        c_vecs = model.encode(
            [c["full_text"] for c in self._comp_docs],
            normalize_embeddings=True,
            show_progress_bar=False,
            batch_size=32,
        ).astype(np.float32)
        self._comp_index = faiss.IndexFlatIP(dim)
        self._comp_index.add(c_vecs)

        # Persist
        with open(idx_dir / "tech_index.pkl", "wb") as f:
            pickle.dump({"index": self._tech_index, "docs": self._tech_docs}, f)
        with open(idx_dir / "comp_index.pkl", "wb") as f:
            pickle.dump({"index": self._comp_index, "docs": self._comp_docs}, f)

        self._ready = True
        logger.info(f"FAISS built: {len(self._tech_docs)} techs, "
                    f"{len(self._comp_docs)} companies")

    # ── Search ─────────────────────────────────────────────────────────────────
    def search_technologies(self, query: str, k: int = 3) -> list[dict]:
        if not self._ready:
            self.build_or_load()
        return self._search(query, self._tech_index, self._tech_docs, k)

    def search_companies(self, query: str, k: int = 3) -> list[dict]:
        if not self._ready:
            self.build_or_load()
        return self._search(query, self._comp_index, self._comp_docs, k)

    def _search(self, query: str, index, docs: list[dict], k: int) -> list[dict]:
        model  = self._get_model()
        q_vec  = model.encode([query], normalize_embeddings=True).astype(np.float32)
        k      = min(k, max(1, len(docs)))
        scores, indices = index.search(q_vec, k)
        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx >= 0 and float(score) > 0.15:
                results.append({**docs[idx], "semantic_score": float(score)})
        return results

    # ── Admin ──────────────────────────────────────────────────────────────────
    def invalidate_cache(self):
        idx_dir = self.settings.faiss_index_dir
        for p in [idx_dir / "tech_index.pkl", idx_dir / "comp_index.pkl"]:
            if p.exists():
                p.unlink()
        self._ready = False
        logger.warning("FAISS cache cleared — will rebuild on next query")


_engine: FAISSSearchEngine | None = None


def get_search_engine() -> FAISSSearchEngine:
    global _engine
    if _engine is None:
        _engine = FAISSSearchEngine()
    return _engine
