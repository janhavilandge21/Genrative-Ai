"""
app/core/query_classifier.py
Zero-cost, zero-LLM query classification and entity extraction.
Returns QueryType + extracted entities in <1ms.
"""

import re
from dataclasses import dataclass, field
from enum import Enum


class QueryType(str, Enum):
    LOOKUP         = "LOOKUP"
    COMPANY_LOOKUP = "COMPANY_LOOKUP"
    FACT           = "FACT"
    FILTER         = "FILTER"
    RELATIONSHIP   = "RELATIONSHIP"
    COMPARISON     = "COMPARISON"
    EXPLANATION    = "EXPLANATION"
    FINANCIAL      = "FINANCIAL"
    ACTIVITY       = "ACTIVITY"
    UNSUPPORTED    = "UNSUPPORTED"


@dataclass
class ClassificationResult:
    query_type:         QueryType
    confidence:         float
    requires_llm:       bool
    llm_reason:         str | None = None
    extracted_entities: dict = field(default_factory=dict)
    intent_signals:     list[str] = field(default_factory=list)


# ── Pattern lists ─────────────────────────────────────────────────────────────
FACT_PATTERNS = [
    r"\bhow many\b", r"\bin how many\b", r"\bcount of\b",
    r"\bnumber of\b", r"\btotal (number|count)\b",
    r"\bhow much\b", r"\bwhat percentage\b",
]

FILTER_PATTERNS = [
    r"\bwhich (technologies|companies|solutions)\b.{0,60}\b(have|with|are|is)\b",
    r"\blist (all|the) (technologies|companies)\b",
    r"\b(high|medium|low) novelty\b",
    r"\b(commercialized|prototype|development).{0,30}(technology|technologies)\b",
    r"\bshow (me|all) (technologies|companies)\b",
    r"\bfilter\b",
]

RELATIONSHIP_PATTERNS = [
    r"\bwhat technologies\b.{0,40}\b(does|do|has|have)\b",
    r"\btechnologies (of|by|from|owned by|developed by)\b",
    r"\btechnolog(y|ies) (for|from|by|of)\b",
]

# EXPLANATION must be checked BEFORE RELATIONSHIP in _classify_by_rules
EXPLANATION_PATTERNS = [
    r"\bhow does\b.{1,80}(contribute|enable|support|help|improve|achieve|work)\b",
    r"\bhow (can|would|could)\b.{1,50}\b(help|improve|enable|benefit)\b",
    r"\bexplain (how|why|the role|the benefit)\b",
    r"\bwhat (role|impact|benefit|value|advantage)\b",
    r"\bwhat (makes|causes|leads to)\b",
    r"\bwhy (is|does|do|are)\b",
    r"\bwhat is the (significance|importance|purpose|goal)\b",
]

COMPARISON_PATTERNS = [
    r"\bcompare\b", r"\bvs\.?\b", r"\bversus\b",
    r"\bdifference between\b", r"\bwhich is (better|more|higher|lower)\b",
]

FINANCIAL_PATTERNS = [
    r"\brevenue\b", r"\bprofit\b", r"\bearnings\b",
    r"\bebita\b", r"\bmarket cap\b", r"\bfinancial\b",
    r"\bstock\b", r"\bvaluation\b", r"\bfunding\b",
]

ACTIVITY_PATTERNS = [
    r"\brecent(ly)?.{0,40}\b(activit|news|development|announce|acqui)\b",
    r"\b(activities|news|announcements|acquisitions|partnerships)\b",
    r"\blatest\b.{0,30}\b(news|update|development)\b",
    r"\bwhat (has|have)\b.{0,50}\b(done|announced|launched|acquired)\b",
]

UNSUPPORTED_PATTERNS = [
    r"\b(weather|sport|joke|poem|cook|recipe)\b",
    r"\bwho (is|was)\b.{0,30}\b(president|prime minister|celebrity)\b",
    r"\b(hack|exploit|sql injection)\b",
]

# Company name aliases → canonical name
COMPANY_ALIASES = {
    "bosch":             "robert bosch gmbh",
    "robert bosch":      "robert bosch gmbh",
    "texas instruments": "texas instruments incorporated",
    "analog devices":    "analog devices",
    "nxp":               "nxp semiconductors n.v.",
    "renesas":           "renesas electronics corporation",
    "rockwell":          "rockwell automation, inc.",
    "keyence":           "keyence",
    "yokogawa":          "yokogawa electric corporation",
    "hitachi":           "hitachi vantara",
    "abb":               "abb group ltd.",
    "honeywell":         "honeywell",
}

TECH_ALIASES = [
    "nexeed", "otosense", "otosense smart motor sensor",
    "connected sensors", "ra2e1", "io-link",
    "secure cloud", "connected assets",
    "voyager 3", "vibration monitoring",
    "interactive industrial", "smart factory",
    "ad4130", "ntag smartsensor", "ntag",
]


class QueryClassifier:

    def classify(self, query: str,
                 conversation_context: list[dict] | None = None) -> ClassificationResult:
        q = query.lower().strip()

        if self._matches_any(q, UNSUPPORTED_PATTERNS):
            return ClassificationResult(
                query_type=QueryType.UNSUPPORTED, confidence=0.95,
                requires_llm=False, intent_signals=["unsupported"],
            )

        entities = self._extract_entities(q)
        if conversation_context:
            entities = self._resolve_references(q, entities, conversation_context)

        return self._classify_by_rules(q, entities)

    def _classify_by_rules(self, q: str, entities: dict) -> ClassificationResult:

        # COMPARISON — two entities
        if self._matches_any(q, COMPARISON_PATTERNS):
            return ClassificationResult(
                query_type=QueryType.COMPARISON, confidence=0.90,
                requires_llm=True,
                llm_reason="Comparison requires multi-entity synthesis",
                extracted_entities=entities, intent_signals=["comparison"],
            )

        # FACT — count/numeric
        if self._matches_any(q, FACT_PATTERNS):
            return ClassificationResult(
                query_type=QueryType.FACT, confidence=0.92,
                requires_llm=False,
                extracted_entities=entities, intent_signals=["count"],
            )

        # FINANCIAL
        if self._matches_any(q, FINANCIAL_PATTERNS):
            return ClassificationResult(
                query_type=QueryType.FINANCIAL, confidence=0.90,
                requires_llm=False,
                extracted_entities=entities, intent_signals=["financial"],
            )

        # ACTIVITY
        if self._matches_any(q, ACTIVITY_PATTERNS):
            return ClassificationResult(
                query_type=QueryType.ACTIVITY, confidence=0.88,
                requires_llm=False,
                extracted_entities=entities, intent_signals=["activity"],
            )

        # EXPLANATION — must come BEFORE RELATIONSHIP (contains "how does X enable Y")
        if self._matches_any(q, EXPLANATION_PATTERNS):
            return ClassificationResult(
                query_type=QueryType.EXPLANATION, confidence=0.88,
                requires_llm=True,
                llm_reason="How/why explanation requires LLM synthesis",
                extracted_entities=entities, intent_signals=["explanation"],
            )

        # FILTER
        if self._matches_any(q, FILTER_PATTERNS):
            return ClassificationResult(
                query_type=QueryType.FILTER, confidence=0.88,
                requires_llm=False,
                extracted_entities=entities, intent_signals=["filter"],
            )

        # RELATIONSHIP — tech ↔ company join
        if self._matches_any(q, RELATIONSHIP_PATTERNS) or (
            entities.get("company_name") and
            any(w in q for w in ["technolog", "solution", "product"])
        ):
            return ClassificationResult(
                query_type=QueryType.RELATIONSHIP, confidence=0.87,
                requires_llm=False,
                extracted_entities=entities, intent_signals=["relationship"],
            )

        # COMPANY LOOKUP
        if entities.get("company_name") and not entities.get("tech_name"):
            return ClassificationResult(
                query_type=QueryType.COMPANY_LOOKUP, confidence=0.85,
                requires_llm=False,
                extracted_entities=entities, intent_signals=["company_lookup"],
            )

        # TECH LOOKUP
        if entities.get("tech_name"):
            return ClassificationResult(
                query_type=QueryType.LOOKUP, confidence=0.85,
                requires_llm=False,
                extracted_entities=entities, intent_signals=["tech_lookup"],
            )

        # General lookup phrases
        if re.search(r"\b(what is|tell me about|describe|what does .{1,40} do)\b", q):
            return ClassificationResult(
                query_type=QueryType.LOOKUP, confidence=0.78,
                requires_llm=False,
                extracted_entities=entities, intent_signals=["lookup"],
            )

        # Default: explanation
        return ClassificationResult(
            query_type=QueryType.EXPLANATION, confidence=0.60,
            requires_llm=True,
            llm_reason="Ambiguous query — LLM fallback",
            extracted_entities=entities, intent_signals=["fallback"],
        )

    def _extract_entities(self, q: str) -> dict:
        entities: dict = {}

        for alias in TECH_ALIASES:
            if alias in q:
                entities["tech_name"] = alias
                break

        for short, full in COMPANY_ALIASES.items():
            if short in q:
                entities["company_name"] = full
                break

        for m in ["commercialized", "prototype", "development stage", "development"]:
            if m in q:
                entities["maturity_filter"] = m
                break

        match = re.search(r"(high|medium|low)\s+novelty|novelty.{0,15}(high|medium|low)", q)
        if match:
            entities["novelty_filter"] = match.group(1) or match.group(2)

        return entities

    def _resolve_references(self, q: str, entities: dict,
                             context: list[dict]) -> dict:
        ref_words = [" it ", "these", "them", "they", "those",
                     "the technology", "the company", "this"]
        if not any(w in q for w in ref_words):
            return entities

        for turn in reversed(context):
            if turn.get("role") == "assistant":
                last = turn.get("entities_mentioned", {})
                if last.get("tech_name") and "tech_name" not in entities:
                    entities["tech_name"] = last["tech_name"]
                if last.get("company_name") and "company_name" not in entities:
                    entities["company_name"] = last["company_name"]
                break
        return entities

    @staticmethod
    def _matches_any(text: str, patterns: list[str]) -> bool:
        return any(re.search(p, text, re.IGNORECASE) for p in patterns)
