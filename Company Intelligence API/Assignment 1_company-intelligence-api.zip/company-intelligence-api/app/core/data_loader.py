"""
app/core/data_loader.py
Loads, normalizes, and indexes the companies and technologies datasets.
Handles the malformed triple-quoted JSON in the raw files.
Provides clean flat dicts + O(1) lookup indexes.
"""

import json
from pathlib import Path
from functools import lru_cache
from typing import Any
from loguru import logger
from config.settings import get_settings


# ── JSON fix: triple-quoted strings ──────────────────────────────────────────
def _fix_triple_quotes(content: str) -> str:
    """
    The raw JSON files use triple-quoted strings (\"\"\"...\"\"\") for multiline values.
    This is invalid JSON. We convert them to properly escaped single-quoted strings.
    """
    result = []
    i = 0
    n = len(content)
    while i < n:
        if content[i:i+3] == '"""':
            end = content.find('"""', i + 3)
            if end == -1:
                result.append('"')
                i += 3
            else:
                inner = content[i+3:end]
                inner = inner.replace('\\', '\\\\')
                inner = inner.replace('"', '\\"')
                inner = inner.replace('\n', '\\n')
                inner = inner.replace('\r', '\\r')
                inner = inner.replace('\t', '\\t')
                result.append('"' + inner + '"')
                i = end + 3
        else:
            result.append(content[i])
            i += 1
    return ''.join(result)


def _load_json_file(path: Path) -> list:
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    fixed = _fix_triple_quotes(content)
    return json.loads(fixed)


# ── Extraction helpers ────────────────────────────────────────────────────────
def _first(lst: Any, key: str = "content", default: str = "") -> str:
    if not lst:
        return default
    if isinstance(lst, list) and lst:
        item = lst[0]
        if isinstance(item, dict):
            return str(item.get(key, default)).strip()
    if isinstance(lst, dict):
        return str(lst.get(key, default)).strip()
    return default


def _all_contents(lst: Any, key: str = "content") -> list[str]:
    if not lst or not isinstance(lst, list):
        return []
    return [str(item.get(key, "")).strip() for item in lst
            if isinstance(item, dict) and item.get(key)]


# ── Normalizers ───────────────────────────────────────────────────────────────
def normalize_company(raw: dict) -> dict:
    doc_id = raw.get("_id", "")
    src    = raw.get("_source", {})
    bi_list = src.get("basic_information", [])
    bi = bi_list[0] if isinstance(bi_list, list) and bi_list else (bi_list or {})

    name = _first(bi.get("name_suggestion", [])) or _first(bi.get("name", []))
    company_id = src.get("id") or doc_id
    website    = _first(bi.get("website", []))
    company_type = _first(bi.get("company_type", []))
    description  = _first(bi.get("description", []))
    industries   = _all_contents(bi.get("industries", []))
    focus_areas  = _all_contents(bi.get("focusarea", []))
    total_employees = _first(bi.get("total_employee", []))
    founded_year    = _first(bi.get("founded_year", []))
    ticker          = _first(bi.get("company_ticker_symbol", []))
    domain          = _first(bi.get("domain", []))

    addresses = bi.get("address_info", [])
    hq, all_countries = "", []
    for addr in (addresses if isinstance(addresses, list) else []):
        if isinstance(addr, dict):
            country = addr.get("country", "")
            city    = addr.get("city", "")
            if addr.get("headquarter", "").lower() == "yes":
                hq = f"{city}, {country}".strip(", ")
            if country:
                all_countries.append(country)

    competitors = []
    for c in (bi.get("competitor_info", []) or []):
        if isinstance(c, dict) and c.get("name"):
            competitors.append(c["name"])

    fi_list = src.get("financial_information", [])
    fi = fi_list[0] if isinstance(fi_list, list) and fi_list else (fi_list or {})
    prof = fi.get("profitability_performance", {}) if isinstance(fi, dict) else {}
    revenue    = _first(prof.get("revenue", []) if isinstance(prof, dict) else [])
    net_margin = _first(prof.get("net_margin", []) if isinstance(prof, dict) else [])

    activities_raw = src.get("activity_information", [])
    activities = []
    for act in (activities_raw if isinstance(activities_raw, list) else []):
        if isinstance(act, dict):
            activities.append({
                "title":       act.get("title", ""),
                "description": act.get("description", ""),
                "type":        act.get("type", ""),
                "date":        act.get("published_date", ""),
            })

    return {
        "doc_id":          doc_id,
        "id":              company_id,
        "name":            name,
        "name_lower":      name.lower(),
        "website":         website,
        "domain":          domain,
        "company_type":    company_type,
        "ticker":          ticker,
        "description":     description,
        "industries":      industries,
        "focus_areas":     focus_areas,
        "total_employees": total_employees,
        "founded_year":    founded_year,
        "headquarters":    hq,
        "countries":       list(set(all_countries)),
        "competitors":     competitors,
        "revenue":         revenue,
        "net_margin":      net_margin,
        "activities":      activities,
        "full_text": (
            f"{name}. {description}. "
            f"Industries: {', '.join(industries)}. "
            f"Focus: {', '.join(focus_areas)}."
        ),
    }


def normalize_technology(raw: dict) -> dict:
    doc_id = raw.get("_id", "")
    src    = raw.get("_source", {})

    title       = _first(src.get("title", []))
    description = _first(src.get("description", []))
    principle   = _first(src.get("principle", []))
    maturity    = _first(src.get("maturity", []))
    novelty     = _first(src.get("novelty", []))
    category    = _first(src.get("category", []))
    offering    = _first(src.get("offering_type", []))
    innovation  = _first(src.get("innovation", []))

    company_info   = src.get("company", {}) or {}
    company_id     = company_info.get("companyid", "")
    company_name   = company_info.get("name", "")
    company_domain = company_info.get("domain", "")

    applications = []
    for app in (src.get("applications", []) or []):
        if isinstance(app, dict) and app.get("content"):
            applications.append(app["content"])

    key_highlights = []
    for kh in (src.get("key_highlights", []) or []):
        if isinstance(kh, dict):
            items = kh.get("content", [])
            if isinstance(items, list):
                key_highlights.extend([str(x) for x in items if x])
            elif items:
                key_highlights.append(str(items))

    diff_factors = []
    for df in (src.get("differentiating_factor", []) or []):
        if isinstance(df, dict) and df.get("content"):
            diff_factors.append(df["content"])

    comp_adv = []
    for ca in (src.get("competition_advantage", []) or []):
        if isinstance(ca, dict) and ca.get("content"):
            comp_adv.append(ca["content"])

    tags = []
    for tg in (src.get("tags", []) or []):
        if isinstance(tg, dict) and tg.get("content"):
            tags.append(tg["content"])

    tech_id = src.get("id", doc_id)
    patents = _first(src.get("noofpatents", []))

    return {
        "doc_id":          doc_id,
        "id":              tech_id,
        "title":           title,
        "title_lower":     title.lower(),
        "description":     description,
        "principle":       principle,
        "maturity":        maturity,
        "maturity_lower":  maturity.lower(),
        "novelty":         novelty,
        "novelty_lower":   novelty.lower(),
        "category":        category,
        "offering_type":   offering,
        "innovation":      innovation,
        "company_id":      company_id,
        "company_name":    company_name,
        "company_domain":  company_domain,
        "applications":    applications,
        "key_highlights":  key_highlights,
        "differentiating_factors": diff_factors,
        "competition_advantages":  comp_adv,
        "tags":            tags,
        "patents":         patents,
        "full_text": (
            f"{title}. {description}. {principle}. "
            f"Category: {category}. Maturity: {maturity}. Novelty: {novelty}. "
            f"Company: {company_name}. "
            f"Applications: {'. '.join(applications[:3])}. "
            f"Highlights: {'. '.join(key_highlights[:5])}."
        ),
    }


# ── DataStore ─────────────────────────────────────────────────────────────────
class DataStore:
    def __init__(self):
        self.companies:    list[dict] = []
        self.technologies: list[dict] = []
        self._company_by_id:    dict[str, dict] = {}
        self._company_by_name:  dict[str, dict] = {}
        self._tech_by_id:       dict[str, dict] = {}
        self._tech_by_title:    dict[str, dict] = {}
        self._techs_by_company: dict[str, list[dict]] = {}
        self._loaded = False

    def load(self):
        if self._loaded:
            return
        settings = get_settings()
        logger.info("Loading data files...")

        raw_companies = _load_json_file(settings.companies_file)
        raw_techs     = _load_json_file(settings.technologies_file)

        self.companies    = [normalize_company(c) for c in raw_companies]
        self.technologies = [normalize_technology(t) for t in raw_techs]

        for c in self.companies:
            self._company_by_id[c["id"]]          = c
            self._company_by_name[c["name_lower"]] = c

        for t in self.technologies:
            self._tech_by_id[t["id"]]             = t
            self._tech_by_title[t["title_lower"]]  = t
            cid = t["company_id"]
            if cid:
                self._techs_by_company.setdefault(cid, []).append(t)

        self._loaded = True
        logger.info(f"Loaded {len(self.companies)} companies, {len(self.technologies)} technologies")

    def get_company_by_id(self, cid: str) -> dict | None:
        return self._company_by_id.get(cid)

    def get_company_by_name(self, name: str) -> dict | None:
        nl = name.lower().strip()
        if nl in self._company_by_name:
            return self._company_by_name[nl]
        for key, company in self._company_by_name.items():
            if nl in key or key in nl:
                return company
        return None

    def get_tech_by_title(self, title: str) -> dict | None:
        tl = title.lower().strip()
        if tl in self._tech_by_title:
            return self._tech_by_title[tl]
        for key, tech in self._tech_by_title.items():
            if tl in key or key in tl:
                return tech
        return None

    def get_techs_by_company(self, company_id: str) -> list[dict]:
        return self._techs_by_company.get(company_id, [])

    def filter_techs(self, maturity: str | None = None,
                     novelty: str | None = None,
                     category: str | None = None) -> list[dict]:
        results = self.technologies
        if maturity:
            results = [t for t in results if maturity.lower() in t["maturity_lower"]]
        if novelty:
            results = [t for t in results if novelty.lower() in t["novelty_lower"]]
        if category:
            results = [t for t in results if category.lower() in t.get("category", "").lower()]
        return results

    def search_companies(self, keyword: str) -> list[dict]:
        kw = keyword.lower()
        return [c for c in self.companies
                if kw in c["full_text"].lower() or kw in c["name_lower"]]

    def search_technologies(self, keyword: str) -> list[dict]:
        kw = keyword.lower()
        return [t for t in self.technologies
                if kw in t["full_text"].lower() or kw in t["title_lower"]]


_store: DataStore | None = None


def get_data_store() -> DataStore:
    global _store
    if _store is None:
        _store = DataStore()
        _store.load()
    return _store
