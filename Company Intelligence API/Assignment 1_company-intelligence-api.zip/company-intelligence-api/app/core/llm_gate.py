"""
app/core/llm_gate.py
Centralized LLM access layer.

Design principles:
  1. LLM called ONLY for EXPLANATION and COMPARISON query types
  2. Every call logged: reason, tokens (estimated), latency, model
  3. Minimal prompt tokens — structured context, no bloat
  4. Temperature=0.1 for factual consistency
  5. should_use_llm() is deterministic and free
"""

import time
from loguru import logger
from config.settings import get_settings


def _est_tokens(text: str) -> int:
    """Rough token estimate: 1 token ≈ 4 chars."""
    return max(1, len(text) // 4)


# ── System prompts ────────────────────────────────────────────────────────────
_SYS_BASE = (
    "You are a precise business intelligence assistant. "
    "Answer based ONLY on the provided data context. "
    "Do not add information not present in the data. "
    "Be concise and factual."
)

# ── User prompt templates ─────────────────────────────────────────────────────
_EXPLAIN_TMPL = (
    "Data context:\n{context}\n\n"
    "Question: {question}\n\n"
    "Answer using only the data above. Use bullet points for complex answers."
)

_COMPARE_TMPL = (
    "{name1}:\n{data1}\n\n"
    "{name2}:\n{data2}\n\n"
    "Provide a structured comparison covering: purpose, maturity, novelty, "
    "applications, and key differences. Use only the data provided."
)

_FACT_TMPL = (
    "Data:\n{data}\n\n"
    "Extract the specific answer to: {question}\n"
    "Reply with just the fact or number. Be brief."
)


class LLMGate:
    """Controls and logs all LLM calls."""

    def __init__(self):
        self.settings  = get_settings()
        self._client   = None
        self._call_log: list[dict] = []

    def _get_client(self):
        if self._client is None:
            from groq import Groq
            key = self.settings.groq_api_key
            if not key or key == "gsk_your_groq_key_here":
                raise ValueError(
                    "GROQ_API_KEY not set. Add it to your .env file. "
                    "Get a free key at https://console.groq.com"
                )
            self._client = Groq(api_key=key)
        return self._client

    # ── Gate decision — deterministic, zero cost ───────────────────────────────
    def should_use_llm(self, query_type: str) -> tuple[bool, str]:
        """
        Returns (use_llm: bool, reason: str).
        This function is the single source of truth for LLM usage policy.
        """
        NO_LLM = {
            "LOOKUP", "COMPANY_LOOKUP", "FACT",
            "FILTER", "RELATIONSHIP", "FINANCIAL", "ACTIVITY",
        }
        YES_LLM = {"EXPLANATION", "COMPARISON"}

        if query_type in NO_LLM:
            return False, f"{query_type} resolved deterministically — no LLM needed"
        if query_type in YES_LLM:
            return True, f"{query_type} requires LLM synthesis"
        return True, f"Unknown type '{query_type}' — LLM fallback"

    # ── Public call methods ────────────────────────────────────────────────────
    def explain(self, question: str, context: str, reason: str = "") -> str:
        """Answer an explanation/how/why query from structured context."""
        prompt = _EXPLAIN_TMPL.format(
            context=context[:3500],
            question=question,
        )
        return self._call(
            system=_SYS_BASE,
            user=prompt,
            reason=f"EXPLANATION | {reason or question[:50]}",
            max_tokens=600,
        )

    def compare(self, name1: str, data1: str,
                name2: str, data2: str, question: str = "") -> str:
        """Compare two entities from structured context."""
        prompt = _COMPARE_TMPL.format(
            name1=name1, data1=data1[:1800],
            name2=name2, data2=data2[:1800],
        )
        return self._call(
            system=_SYS_BASE,
            user=prompt,
            reason=f"COMPARISON | {name1} vs {name2}",
            max_tokens=700,
        )

    def extract_fact(self, question: str, data: str) -> str:
        """Extract a single fact from data — minimal tokens."""
        prompt = _FACT_TMPL.format(question=question, data=data[:1500])
        return self._call(
            system="Extract only the requested fact. Be brief.",
            user=prompt,
            reason=f"FACT_EXTRACT | {question[:50]}",
            max_tokens=120,
        )

    # ── Core call ──────────────────────────────────────────────────────────────
    def _call(self, system: str, user: str,
              reason: str, max_tokens: int = 500) -> str:
        client    = self._get_client()
        in_tokens = _est_tokens(system) + _est_tokens(user)
        t0        = time.time()

        # Ensure the model name doesn't have an extraneous "model=" prefix
        model_name = self.settings.llm_model
        logger.info(f"LLM_MODEL from settings: {model_name}") # Added for debugging
        if model_name.startswith("model="):
            model_name = model_name.replace("model=", "")

        try:
            resp = client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user",   "content": user},
                ],
                temperature=0.1,
                max_tokens=max_tokens,
            )
            answer     = resp.choices[0].message.content.strip()
            out_tokens = _est_tokens(answer)
            latency    = round(time.time() - t0, 3)

            self._call_log.append({
                "reason":     reason,
                "model":      self.settings.llm_model,
                "in_tokens":  in_tokens,
                "out_tokens": out_tokens,
                "latency_s":  latency,
                "timestamp":  time.time(),
            })
            logger.info(
                f"LLM | {reason} | "
                f"tokens={in_tokens}+{out_tokens} | {latency}s"
            )
            return answer

        except Exception as e:
            logger.error(f"LLM call failed ({reason}): {e}")
            return f"[AI analysis unavailable: {str(e)[:100]}]"

    # ── Observability ──────────────────────────────────────────────────────────
    def get_usage_stats(self) -> dict:
        if not self._call_log:
            return {
                "total_calls": 0, "total_tokens": 0,
                "avg_latency_s": 0.0, "recent_calls": [],
            }
        total_in  = sum(e["in_tokens"]  for e in self._call_log)
        total_out = sum(e["out_tokens"] for e in self._call_log)
        avg_lat   = sum(e["latency_s"]  for e in self._call_log) / len(self._call_log)
        return {
            "total_calls":      len(self._call_log),
            "total_in_tokens":  total_in,
            "total_out_tokens": total_out,
            "total_tokens":     total_in + total_out,
            "avg_latency_s":    round(avg_lat, 3),
            "recent_calls":     self._call_log[-5:],
        }


_gate: LLMGate | None = None


def get_llm_gate() -> LLMGate:
    global _gate
    if _gate is None:
        _gate = LLMGate()
    return _gate
