"""
app/api/routes.py
Thin FastAPI route layer — all logic delegated to services.
"""
from fastapi import APIRouter, HTTPException
from app.api.schemas import (
    QueryRequest, QueryResponse,
    SessionHistoryResponse, HealthResponse, LLMUsageResponse,
)
from app.services.query_engine import get_query_engine
from app.core.data_loader import get_data_store
from app.core.vector_search import get_search_engine
from app.core.llm_gate import get_llm_gate
from app.memory.conversation_store import get_conversation_store
from config.settings import get_settings
from loguru import logger

router = APIRouter()


# ── Main query ─────────────────────────────────────────────────────────────────
@router.post("/query", response_model=QueryResponse, tags=["Query"])
def query(req: QueryRequest):
    """
    Submit a natural language question.
    Returns a structured, explainable answer with source attribution.
    Pass the returned `session_id` back on subsequent queries to maintain context.
    """
    try:
        engine = get_query_engine()
        result = engine.process(req.query, req.session_id)
        return QueryResponse(**result)
    except Exception as e:
        logger.error(f"Query error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ── Session ────────────────────────────────────────────────────────────────────
@router.get("/session/{session_id}/history",
            response_model=SessionHistoryResponse, tags=["Session"])
def session_history(session_id: str):
    """Get conversation history for a session."""
    store   = get_conversation_store()
    session = store.get_session(session_id)
    if not session:
        raise HTTPException(404, "Session not found or expired.")
    return SessionHistoryResponse(
        session_id=session_id,
        turns=session.get_history_for_display(),
        stats=session.summary_stats(),
    )


@router.delete("/session/{session_id}", tags=["Session"])
def clear_session(session_id: str):
    """Clear conversation history for a session."""
    store   = get_conversation_store()
    session = store.get_session(session_id)
    if not session:
        raise HTTPException(404, "Session not found.")
    session.turns.clear()
    session.last_tech_name    = None
    session.last_company_name = None
    return {"message": f"Session {session_id[:8]}... cleared."}


# ── Data browsing ──────────────────────────────────────────────────────────────
@router.get("/companies", tags=["Data"])
def list_companies(limit: int = 20, offset: int = 0):
    """List all companies (paginated)."""
    store = get_data_store()
    page  = store.companies[offset: offset + limit]
    return {
        "total":  len(store.companies),
        "limit":  limit,
        "offset": offset,
        "companies": [
            {
                "id":           c["id"],
                "name":         c["name"],
                "type":         c["company_type"],
                "headquarters": c["headquarters"],
                "industries":   c["industries"][:2],
            }
            for c in page
        ],
    }


@router.get("/technologies", tags=["Data"])
def list_technologies(
    limit: int = 20,
    offset: int = 0,
    maturity: str | None = None,
    novelty: str | None = None,
):
    """List technologies with optional maturity/novelty filters."""
    store = get_data_store()
    techs = store.filter_techs(maturity=maturity, novelty=novelty)
    page  = techs[offset: offset + limit]
    return {
        "total":  len(techs),
        "limit":  limit,
        "offset": offset,
        "technologies": [
            {
                "id":       t["id"],
                "title":    t["title"],
                "company":  t["company_name"],
                "maturity": t["maturity"],
                "novelty":  t["novelty"],
                "category": t["category"],
            }
            for t in page
        ],
    }


@router.get("/companies/{company_id}", tags=["Data"])
def get_company(company_id: str):
    """Get a company by ID including its technologies."""
    store   = get_data_store()
    company = store.get_company_by_id(company_id)
    if not company:
        raise HTTPException(404, "Company not found.")
    techs = store.get_techs_by_company(company_id)
    return {
        **{k: v for k, v in company.items() if k not in ("full_text", "name_lower")},
        "technologies": [{"id": t["id"], "title": t["title"]} for t in techs],
    }


@router.get("/technologies/{tech_id}", tags=["Data"])
def get_technology(tech_id: str):
    """Get a technology by ID."""
    store = get_data_store()
    tech  = store._tech_by_id.get(tech_id)
    if not tech:
        raise HTTPException(404, "Technology not found.")
    return {
        k: v for k, v in tech.items()
        if k not in ("full_text", "title_lower", "maturity_lower", "novelty_lower")
    }


# ── Health & observability ─────────────────────────────────────────────────────
@router.get("/health", response_model=HealthResponse, tags=["System"])
def health():
    """System health check."""
    settings  = get_settings()
    store     = get_data_store()
    engine    = get_search_engine()
    llm       = get_llm_gate()
    groq_ok   = (
        bool(settings.groq_api_key)
        and settings.groq_api_key != "gsk_your_groq_key_here"
    )
    return HealthResponse(
        status="healthy",
        companies_loaded=len(store.companies),
        technologies_loaded=len(store.technologies),
        faiss_ready=engine._ready,
        groq_configured=groq_ok,
        llm_usage_stats=llm.get_usage_stats(),
    )


@router.get("/llm-usage", response_model=LLMUsageResponse, tags=["System"])
def llm_usage():
    """LLM call statistics for cost monitoring."""
    stats = get_llm_gate().get_usage_stats()
    return LLMUsageResponse(
        total_calls=stats.get("total_calls", 0),
        total_tokens=stats.get("total_tokens", 0),
        avg_latency_s=stats.get("avg_latency_s", 0.0),
        recent_calls=stats.get("recent_calls", []),
    )


@router.post("/admin/rebuild-index", tags=["Admin"])
def rebuild_index():
    """Force rebuild of FAISS index (use after data updates)."""
    engine = get_search_engine()
    engine.invalidate_cache()
    engine.build_or_load()
    return {"message": "FAISS index rebuilt successfully."}
