"""
app/api/schemas.py
Pydantic v2 request/response models.
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Any


class QueryRequest(BaseModel):
    query: str = Field(
        ..., min_length=2, max_length=500,
        description="Natural language question",
        examples=["How does Nexeed enable zero-defect production?"],
    )
    session_id: Optional[str] = Field(
        None,
        description="Session ID for multi-turn conversation. "
                    "Omit on first query — one is created and returned.",
    )


class QueryResponse(BaseModel):
    session_id:  str
    answer:      str
    source:      List[str]
    data_used:   List[Any]
    confidence:  str
    llm_used:    bool
    llm_reason:  Optional[str]
    query_type:  str
    latency_ms:  float
    entities:    dict


class SessionHistoryResponse(BaseModel):
    session_id: str
    turns:      List[dict]
    stats:      dict


class HealthResponse(BaseModel):
    status:               str
    companies_loaded:     int
    technologies_loaded:  int
    faiss_ready:          bool
    groq_configured:      bool
    llm_usage_stats:      dict


class LLMUsageResponse(BaseModel):
    total_calls:     int
    total_tokens:    int
    avg_latency_s:   float
    recent_calls:    List[dict]
