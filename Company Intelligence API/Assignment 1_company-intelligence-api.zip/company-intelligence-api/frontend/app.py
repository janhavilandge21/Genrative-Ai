"""
frontend/app.py
Advanced Streamlit frontend for Company Intelligence API.

Features:
  - Chat interface with multi-turn conversation
  - Company explorer with search/filter
  - Technology browser with maturity/novelty visualization
  - Live analytics dashboard
  - Query type breakdown
  - LLM usage monitoring
"""

import streamlit as st
import requests
import json
import time
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime

# ── Config ─────────────────────────────────────────────────────────────────────
API_BASE = "http://localhost:8000/api/v1"

st.set_page_config(
    page_title="Company Intelligence",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ────────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap');

:root {
    --bg:       #050709;
    --s1:       #0b0f18;
    --s2:       #111827;
    --s3:       #1c2333;
    --s4:       #253047;
    --accent:   #3b82f6;
    --accent2:  #8b5cf6;
    --green:    #10b981;
    --yellow:   #f59e0b;
    --red:      #ef4444;
    --text:     #e2e8f0;
    --muted:    #94a3b8;
    --border:   #1e2a3d;
}

html, body, [data-testid="stAppViewContainer"] {
    background: var(--bg) !important;
    color: var(--text);
    font-family: 'Inter', sans-serif;
}
[data-testid="stSidebar"] {
    background: var(--s1) !important;
    border-right: 1px solid var(--border);
}
[data-testid="stSidebar"] * { color: var(--text) !important; }

.stTabs [data-baseweb="tab-list"] {
    background: var(--s2) !important;
    border-radius: 12px;
    padding: 4px;
    gap: 4px;
}
.stTabs [data-baseweb="tab"] {
    color: var(--muted) !important;
    font-weight: 500;
    border-radius: 8px !important;
    padding: 8px 18px !important;
}
.stTabs [aria-selected="true"] {
    background: var(--s4) !important;
    color: var(--text) !important;
}

.stButton > button {
    background: linear-gradient(135deg, #3b82f6, #8b5cf6) !important;
    color: white !important;
    border: none !important;
    border-radius: 8px !important;
    font-weight: 600 !important;
    font-family: 'Inter', sans-serif !important;
    padding: 8px 20px !important;
    transition: opacity 0.2s !important;
}
.stButton > button:hover { opacity: 0.85 !important; }

.stTextInput input, .stTextArea textarea, .stSelectbox div {
    background: var(--s2) !important;
    color: var(--text) !important;
    border: 1px solid var(--border) !important;
    border-radius: 8px !important;
    font-family: 'Inter', sans-serif !important;
}

/* Chat bubbles */
.bubble-user {
    background: linear-gradient(135deg, #1d3a6e, #2d4a8e);
    border: 1px solid #2d4a8e;
    border-radius: 16px 16px 4px 16px;
    padding: 14px 18px;
    margin: 8px 0 8px 40px;
    line-height: 1.6;
    font-size: 0.95rem;
}
.bubble-assistant {
    background: var(--s2);
    border: 1px solid var(--border);
    border-radius: 16px 16px 16px 4px;
    padding: 14px 18px;
    margin: 8px 40px 8px 0;
    line-height: 1.6;
    font-size: 0.95rem;
}

/* Meta badges */
.meta-row {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-top: 10px;
}
.badge {
    display: inline-block;
    border-radius: 6px;
    padding: 3px 10px;
    font-size: 0.75rem;
    font-family: 'JetBrains Mono', monospace;
    font-weight: 600;
    letter-spacing: 0.03em;
}
.badge-type    { background: #1e3a5f; color: #60a5fa; border: 1px solid #2d4a8e; }
.badge-source  { background: #1a3a2a; color: #34d399; border: 1px solid #1e5a3a; }
.badge-conf-h  { background: #1a3a2a; color: #34d399; border: 1px solid #1e5a3a; }
.badge-conf-m  { background: #3a2a0a; color: #fbbf24; border: 1px solid #5a3a0a; }
.badge-conf-l  { background: #3a1a1a; color: #f87171; border: 1px solid #5a1a1a; }
.badge-llm-y   { background: #2d1a4e; color: #c084fc; border: 1px solid #4a2a7e; }
.badge-llm-n   { background: #1c2333; color: #94a3b8; border: 1px solid #253047; }
.badge-lat     { background: #1c2333; color: #94a3b8; border: 1px solid #253047; }

/* Cards */
.card {
    background: var(--s2);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 18px 20px;
    margin: 8px 0;
}
.card-company {
    border-left: 4px solid var(--accent);
}
.card-tech {
    border-left: 4px solid var(--accent2);
}

/* Metric tiles */
.metric-tile {
    background: var(--s2);
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: 16px;
    text-align: center;
}
.metric-value {
    font-size: 2rem;
    font-weight: 800;
    background: linear-gradient(135deg, #3b82f6, #8b5cf6);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}
.metric-label {
    font-size: 0.8rem;
    color: var(--muted);
    margin-top: 4px;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.08em;
}

/* Hero */
.hero-title {
    font-size: 2.2rem;
    font-weight: 800;
    background: linear-gradient(135deg, #3b82f6, #8b5cf6, #10b981);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: 4px;
}
.hero-sub {
    color: var(--muted);
    font-size: 0.95rem;
}

/* Tech maturity badge */
.mat-comm  { background: #0d2a1a; color: #34d399; border: 1px solid #1e5a3a; }
.mat-proto { background: #3a2a0a; color: #fbbf24; border: 1px solid #5a3a0a; }
.mat-dev   { background: #1e2a4e; color: #93c5fd; border: 1px solid #2d4a8e; }
.nov-high  { background: #2d1a4e; color: #c084fc; border: 1px solid #4a2a7e; }
.nov-med   { background: #3a2a0a; color: #fbbf24; border: 1px solid #5a3a0a; }
.nov-low   { background: #1c2333; color: #94a3b8; border: 1px solid #253047; }

/* Scrollable chat */
.chat-scroll {
    max-height: 520px;
    overflow-y: auto;
    padding-right: 8px;
}

/* Divider */
.my-divider {
    border: none;
    border-top: 1px solid var(--border);
    margin: 16px 0;
}

/* Section header */
.section-header {
    font-weight: 700;
    font-size: 0.78rem;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: var(--accent);
    margin: 16px 0 8px 0;
    border-bottom: 1px solid var(--border);
    padding-bottom: 6px;
}

/* Query chips */
.chip {
    display: inline-block;
    background: var(--s3);
    border: 1px solid var(--border);
    border-radius: 20px;
    padding: 4px 14px;
    font-size: 0.82rem;
    color: var(--muted);
    margin: 3px 2px;
    cursor: pointer;
}
.chip:hover { border-color: var(--accent); color: var(--text); }

/* Data table */
.stDataFrame { background: var(--s2) !important; }
</style>
""", unsafe_allow_html=True)

# ── API helpers ────────────────────────────────────────────────────────────────
@st.cache_data(ttl=60)
def fetch_companies(limit=136, offset=0):
    try:
        r = requests.get(f"{API_BASE}/companies", params={"limit": limit, "offset": offset}, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        return {"total": 0, "companies": [], "error": str(e)}

@st.cache_data(ttl=60)
def fetch_technologies(maturity=None, novelty=None):
    params = {"limit": 20}
    if maturity: params["maturity"] = maturity
    if novelty:  params["novelty"]  = novelty
    try:
        r = requests.get(f"{API_BASE}/technologies", params=params, timeout=10)
        r.raise_for_status()
        return r.json()
    except Exception as e:
        return {"total": 0, "technologies": [], "error": str(e)}

@st.cache_data(ttl=30)
def fetch_health():
    try:
        r = requests.get(f"{API_BASE}/health", timeout=5)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None

def post_query(query: str, session_id: str | None = None) -> dict | None:
    try:
        payload = {"query": query}
        if session_id:
            payload["session_id"] = session_id
        r = requests.post(f"{API_BASE}/query", json=payload, timeout=60)
        r.raise_for_status()
        return r.json()
    except requests.exceptions.ConnectionError:
        return {"error": "backend_offline"}
    except Exception as e:
        return {"error": str(e)}

def fetch_llm_usage():
    try:
        r = requests.get(f"{API_BASE}/llm-usage", timeout=5)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None

def fetch_session_history(session_id: str):
    try:
        r = requests.get(f"{API_BASE}/session/{session_id}/history", timeout=5)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return None

# ── Session state ──────────────────────────────────────────────────────────────
defaults = {
    "session_id":     None,
    "messages":       [],     # [{role, content, meta}]
    "query_stats":    [],     # [{type, llm, latency, ts}]
    "llm_call_count": 0,
    "total_queries":  0,
}
for k, v in defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown('<p style="font-size:1.3rem;font-weight:800;background:linear-gradient(135deg,#3b82f6,#8b5cf6);-webkit-background-clip:text;-webkit-text-fill-color:transparent">🏭 Company Intelligence</p>', unsafe_allow_html=True)
    st.markdown('<p style="color:#94a3b8;font-size:0.82rem">AI-Powered NL Query System</p>', unsafe_allow_html=True)
    st.divider()

    # ── Backend status
    health = fetch_health()
    if health:
        st.success("✅ API Online")
        c1, c2 = st.columns(2)
        c1.metric("Companies", health.get("companies_loaded", 0))
        c2.metric("Technologies", health.get("technologies_loaded", 0))
        groq = health.get("groq_configured", False)
        faiss = health.get("faiss_ready", False)
        st.markdown(
            f"Groq LLM: {'✅' if groq else '⚠️ Not configured'}  \n"
            f"FAISS: {'✅ Ready' if faiss else '⏳ Building...'}",
        )
    else:
        st.error("❌ API Offline\n\nRun: `uvicorn main:app --reload`")

    st.divider()

    # ── Session info
    st.markdown('<p class="section-header" style="font-size:0.72rem">Session</p>', unsafe_allow_html=True)
    if st.session_state.session_id:
        st.markdown(f'<span style="font-family:monospace;font-size:0.78rem;color:#60a5fa">{st.session_state.session_id[:16]}...</span>', unsafe_allow_html=True)
    else:
        st.markdown('<span style="color:#94a3b8;font-size:0.82rem">No active session</span>', unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    c1.metric("Queries", st.session_state.total_queries)
    c2.metric("LLM Calls", st.session_state.llm_call_count)

    if st.button("🔄 New Session", use_container_width=True):
        st.session_state.session_id  = None
        st.session_state.messages    = []
        st.session_state.query_stats = []
        st.session_state.llm_call_count = 0
        st.session_state.total_queries  = 0
        fetch_companies.clear()
        fetch_technologies.clear()
        fetch_health.clear()
        st.rerun()

    st.divider()

    # ── LLM Usage stats
    usage = fetch_llm_usage()
    if usage:
        st.markdown('<p class="section-header" style="font-size:0.72rem">LLM Usage</p>', unsafe_allow_html=True)
        st.markdown(f"Total calls: **{usage.get('total_calls', 0)}**")
        st.markdown(f"Total tokens: **{usage.get('total_tokens', 0):,}**")
        st.markdown(f"Avg latency: **{usage.get('avg_latency_s', 0):.2f}s**")

# ── Main area ──────────────────────────────────────────────────────────────────
st.markdown('<h1 class="hero-title">🏭 Company Intelligence</h1>', unsafe_allow_html=True)
st.markdown('<p class="hero-sub">Natural language Q&A over industrial technology company data — powered by hybrid rule-based + FAISS + Groq LLM</p>', unsafe_allow_html=True)

# ── Tabs ───────────────────────────────────────────────────────────────────────
tab_chat, tab_companies, tab_techs, tab_analytics = st.tabs([
    "💬  Chat",
    "🏢  Companies",
    "⚙️  Technologies",
    "📊  Analytics",
])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — CHAT
# ══════════════════════════════════════════════════════════════════════════════
with tab_chat:
    col_chat, col_info = st.columns([2, 1])

    with col_chat:
        st.markdown('<p class="section-header">Ask anything about companies & technologies</p>', unsafe_allow_html=True)

        # ── Example prompts
        EXAMPLES = [
            "How does Nexeed enable zero-defect production?",
            "Which technologies have High novelty?",
            "What technologies does Analog Devices have?",
            "In how many production lines is AI quality control implemented?",
            "Tell me about Robert Bosch",
            "Compare Nexeed and OtoSense",
            "How does real-time anomaly detection contribute to product quality?",
            "What are the recent activities of Texas Instruments?",
        ]

        st.markdown("**💡 Try these:**")
        ex_cols = st.columns(4)
        for i, ex in enumerate(EXAMPLES[:4]):
            if ex_cols[i % 4].button(ex[:32] + "…", key=f"ex_{i}", use_container_width=True):
                st.session_state["_pending_query"] = ex

        ex_cols2 = st.columns(4)
        for i, ex in enumerate(EXAMPLES[4:]):
            if ex_cols2[i % 4].button(ex[:32] + "…", key=f"ex2_{i}", use_container_width=True):
                st.session_state["_pending_query"] = ex

        st.markdown('<hr class="my-divider">', unsafe_allow_html=True)

        # ── Chat history
        chat_container = st.container()
        with chat_container:
            if not st.session_state.messages:
                st.markdown(
                    '<div style="text-align:center;padding:40px;color:#4a5568">'
                    '<div style="font-size:3rem">🏭</div>'
                    '<p style="color:#6b7280">Start a conversation — ask about companies, technologies, or industry trends</p>'
                    '</div>',
                    unsafe_allow_html=True,
                )
            else:
                for msg in st.session_state.messages:
                    if msg["role"] == "user":
                        st.markdown(
                            f'<div class="bubble-user">👤 {msg["content"]}</div>',
                            unsafe_allow_html=True,
                        )
                    else:
                        content  = msg["content"].replace("\n", "<br>")
                        meta     = msg.get("meta", {})
                        qt       = meta.get("query_type", "")
                        conf     = meta.get("confidence", "")
                        sources  = meta.get("source", [])
                        llm_used = meta.get("llm_used", False)
                        latency  = meta.get("latency_ms", 0)

                        # Confidence badge class
                        conf_cls = {"high": "badge-conf-h", "medium": "badge-conf-m", "low": "badge-conf-l"}.get(conf, "badge-conf-m")

                        badges = ""
                        if qt:
                            badges += f'<span class="badge badge-type">⚡ {qt}</span>'
                        for src in sources:
                            badges += f'<span class="badge badge-source">📂 {src}</span>'
                        if conf:
                            badges += f'<span class="badge {conf_cls}">🎯 {conf} confidence</span>'
                        if llm_used:
                            badges += f'<span class="badge badge-llm-y">🤖 LLM used</span>'
                        else:
                            badges += f'<span class="badge badge-llm-n">⚡ No LLM</span>'
                        if latency:
                            badges += f'<span class="badge badge-lat">⏱ {latency}ms</span>'

                        st.markdown(
                            f'<div class="bubble-assistant">'
                            f'🤖 {content}'
                            f'<div class="meta-row">{badges}</div>'
                            f'</div>',
                            unsafe_allow_html=True,
                        )

        # ── Input
        query = st.chat_input("Ask a question about companies or technologies...")
        if st.session_state.pop("_pending_query", None):
            query = st.session_state.get("_pending_query") or query

        # Handle injected pending query from example buttons
        for k in list(st.session_state.keys()):
            if k == "_pending_query":
                query = st.session_state.pop(k)
                break

        if query:
            if not health:
                st.error("API is offline. Please start the backend first.")
            else:
                # Add user message
                st.session_state.messages.append({"role": "user", "content": query})
                st.session_state.total_queries += 1

                with st.spinner("🤖 Processing..."):
                    result = post_query(query, st.session_state.session_id)

                if result and not result.get("error"):
                    # Update session
                    st.session_state.session_id = result.get("session_id", st.session_state.session_id)
                    if result.get("llm_used"):
                        st.session_state.llm_call_count += 1

                    # Track stats
                    st.session_state.query_stats.append({
                        "type":    result.get("query_type", "UNKNOWN"),
                        "llm":     result.get("llm_used", False),
                        "latency": result.get("latency_ms", 0),
                        "ts":      datetime.now().strftime("%H:%M:%S"),
                        "query":   query[:50],
                    })

                    # Add assistant message
                    st.session_state.messages.append({
                        "role":    "assistant",
                        "content": result.get("answer", "No answer"),
                        "meta":    result,
                    })
                elif result and result.get("error") == "backend_offline":
                    st.session_state.messages.append({
                        "role":    "assistant",
                        "content": "❌ Cannot connect to the API. Please start the backend: `uvicorn main:app --reload --port 8000`",
                        "meta":    {},
                    })
                else:
                    err = result.get("error", "Unknown error") if result else "No response"
                    st.session_state.messages.append({
                        "role":    "assistant",
                        "content": f"⚠️ Error: {err}",
                        "meta":    {},
                    })

                st.rerun()

    # ── Right info panel
    with col_info:
        st.markdown('<p class="section-header">Query Guide</p>', unsafe_allow_html=True)

        guide = {
            "🔍 LOOKUP": "What is Nexeed?",
            "🏢 COMPANY": "Tell me about Bosch",
            "🔢 FACT": "How many High novelty techs?",
            "📋 FILTER": "List commercialized techs",
            "🔗 RELATION": "Bosch technologies?",
            "💡 EXPLAIN": "How does Nexeed work?",
            "⚖️ COMPARE": "Compare Nexeed vs OtoSense",
            "💰 FINANCIAL": "TI revenue?",
            "📰 ACTIVITY": "Bosch recent news?",
        }
        for qtype, example in guide.items():
            st.markdown(
                f'<div style="background:#111827;border:1px solid #1e2a3d;border-radius:8px;'
                f'padding:8px 12px;margin:4px 0;font-size:0.82rem">'
                f'<span style="font-weight:600;color:#60a5fa">{qtype}</span><br>'
                f'<span style="color:#94a3b8;font-style:italic">{example}</span>'
                f'</div>',
                unsafe_allow_html=True,
            )

        st.markdown('<p class="section-header" style="margin-top:20px">LLM Policy</p>', unsafe_allow_html=True)
        st.markdown("""
        <div style="background:#111827;border:1px solid #1e2a3d;border-radius:8px;padding:12px;font-size:0.82rem;color:#94a3b8">
        ✅ <b style="color:#34d399">No LLM needed:</b><br>
        LOOKUP, FILTER, FACT, RELATIONSHIP, FINANCIAL, ACTIVITY
        <br><br>
        🤖 <b style="color:#c084fc">LLM used for:</b><br>
        EXPLANATION, COMPARISON
        </div>
        """, unsafe_allow_html=True)

        if st.session_state.query_stats:
            st.markdown('<p class="section-header" style="margin-top:16px">Recent Queries</p>', unsafe_allow_html=True)
            for qs in reversed(st.session_state.query_stats[-5:]):
                llm_icon = "🤖" if qs["llm"] else "⚡"
                st.markdown(
                    f'<div style="font-size:0.78rem;color:#94a3b8;border-bottom:1px solid #1e2a3d;padding:4px 0">'
                    f'{llm_icon} <b style="color:#e2e8f0">{qs["type"]}</b> '
                    f'<span style="color:#4a5568">{qs["latency"]}ms</span><br>'
                    f'<span style="color:#6b7280">{qs["query"][:40]}…</span>'
                    f'</div>',
                    unsafe_allow_html=True,
                )

# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — COMPANIES
# ══════════════════════════════════════════════════════════════════════════════
with tab_companies:
    st.markdown('<p class="section-header">Company Explorer — 136 Industrial Technology Companies</p>', unsafe_allow_html=True)

    comp_data = fetch_companies(limit=136)

    if comp_data.get("error"):
        st.error(f"Could not load companies: {comp_data['error']}")
    elif comp_data.get("companies"):
        companies = comp_data["companies"]
        df_comp = pd.DataFrame(companies)

        # Stats row
        m1, m2, m3, m4 = st.columns(4)
        m1.markdown('<div class="metric-tile"><div class="metric-value">136</div><div class="metric-label">Companies</div></div>', unsafe_allow_html=True)
        total_types = df_comp["type"].value_counts() if "type" in df_comp.columns else {}
        m2.markdown(f'<div class="metric-tile"><div class="metric-value">{len(df_comp["type"].unique()) if "type" in df_comp.columns else "—"}</div><div class="metric-label">Company Types</div></div>', unsafe_allow_html=True)
        m3.markdown(f'<div class="metric-tile"><div class="metric-value">10</div><div class="metric-label">Technologies</div></div>', unsafe_allow_html=True)
        m4.markdown(f'<div class="metric-tile"><div class="metric-value">6</div><div class="metric-label">Tech Companies</div></div>', unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # Search + filter
        cs1, cs2, cs3 = st.columns([2, 1, 1])
        search_term = cs1.text_input("🔍 Search companies...", placeholder="e.g. Bosch, Texas Instruments, NXP")
        type_filter = cs2.selectbox("Type", ["All"] + sorted(df_comp["type"].dropna().unique().tolist()) if "type" in df_comp.columns else ["All"])
        hq_filter   = cs3.text_input("🌍 HQ contains...", placeholder="e.g. Germany, USA")

        # Filter
        filtered = companies
        if search_term:
            filtered = [c for c in filtered if search_term.lower() in c.get("name", "").lower()]
        if type_filter != "All":
            filtered = [c for c in filtered if c.get("type", "") == type_filter]
        if hq_filter:
            filtered = [c for c in filtered if hq_filter.lower() in c.get("headquarters", "").lower()]

        st.markdown(f"**Showing {len(filtered)} of {len(companies)} companies**")

        # Company cards (first 20 for performance)
        for c in filtered[:20]:
            name = c.get("name", "N/A").title()
            ctype = c.get("type", "N/A")
            hq    = c.get("headquarters", "N/A")
            inds  = ", ".join(c.get("industries", [])[:2]) or "N/A"
            cid   = c.get("id", "")[:16]

            st.markdown(
                f'<div class="card card-company">'
                f'<div style="display:flex;justify-content:space-between;align-items:flex-start">'
                f'<div><b style="font-size:1rem;color:#e2e8f0">{name}</b>'
                f'<div style="color:#94a3b8;font-size:0.82rem;margin-top:3px">'
                f'📍 {hq} &nbsp;|&nbsp; 🏭 {inds}'
                f'</div></div>'
                f'<span class="badge badge-type">{ctype}</span>'
                f'</div>'
                f'<div style="font-size:0.75rem;color:#4a5568;margin-top:6px;font-family:monospace">id: {cid}...</div>'
                f'</div>',
                unsafe_allow_html=True,
            )

        if len(filtered) > 20:
            st.info(f"Showing first 20 of {len(filtered)} results. Refine your search to see more.")

        # Company type distribution chart
        if "type" in df_comp.columns:
            st.markdown("<br>", unsafe_allow_html=True)
            st.markdown('<p class="section-header">Company Type Distribution</p>', unsafe_allow_html=True)
            type_counts = df_comp["type"].value_counts().reset_index()
            type_counts.columns = ["Type", "Count"]
            fig = px.bar(
                type_counts, x="Count", y="Type", orientation="h",
                color="Count",
                color_continuous_scale=[[0, "#3b82f6"], [1, "#8b5cf6"]],
                title="",
            )
            fig.update_layout(
                paper_bgcolor="#111827", plot_bgcolor="#111827",
                font=dict(color="#e2e8f0"),
                xaxis=dict(gridcolor="#1e2a3d"),
                yaxis=dict(autorange="reversed"),
                height=300,
                margin=dict(l=10, r=20, t=20, b=30),
                coloraxis_showscale=False,
            )
            st.plotly_chart(fig, use_container_width=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — TECHNOLOGIES
# ══════════════════════════════════════════════════════════════════════════════
with tab_techs:
    st.markdown('<p class="section-header">Technology Browser — 10 Industrial Technology Profiles</p>', unsafe_allow_html=True)

    ts1, ts2, ts3 = st.columns(3)
    mat_filter = ts1.selectbox("Maturity", ["All", "Commercialized", "Development Stage", "Prototype"])
    nov_filter = ts2.selectbox("Novelty", ["All", "High", "Medium", "Low"])
    ts3.markdown("<br>", unsafe_allow_html=True)
    ts3.markdown("")

    mat_param = None if mat_filter == "All" else mat_filter
    nov_param = None if nov_filter == "All" else nov_filter

    tech_data = fetch_technologies(maturity=mat_param, novelty=nov_param)

    if tech_data.get("technologies"):
        technologies = tech_data["technologies"]

        # Stats
        t1, t2, t3, t4 = st.columns(4)
        total_t = tech_data.get("total", len(technologies))
        t1.markdown(f'<div class="metric-tile"><div class="metric-value">{total_t}</div><div class="metric-label">Total</div></div>', unsafe_allow_html=True)
        comm  = sum(1 for t in technologies if "commerc" in t.get("maturity","").lower())
        proto = sum(1 for t in technologies if "proto"   in t.get("maturity","").lower())
        dev   = sum(1 for t in technologies if "develop" in t.get("maturity","").lower())
        t2.markdown(f'<div class="metric-tile"><div class="metric-value" style="color:#34d399">{comm}</div><div class="metric-label">Commercialized</div></div>', unsafe_allow_html=True)
        t3.markdown(f'<div class="metric-tile"><div class="metric-value" style="color:#fbbf24">{proto}</div><div class="metric-label">Prototype</div></div>', unsafe_allow_html=True)
        t4.markdown(f'<div class="metric-tile"><div class="metric-value" style="color:#93c5fd">{dev}</div><div class="metric-label">Development</div></div>', unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # Tech cards — 2 column layout
        col_a, col_b = st.columns(2)
        for i, tech in enumerate(technologies):
            col = col_a if i % 2 == 0 else col_b
            title   = tech.get("title", "N/A")
            company = tech.get("company", "N/A")
            maturity= tech.get("maturity", "")
            novelty = tech.get("novelty", "")
            cat     = tech.get("category", "")

            # Maturity badge class
            mat_cls = "mat-comm" if "comm" in maturity.lower() else "mat-proto" if "proto" in maturity.lower() else "mat-dev"
            nov_cls = "nov-high" if "high" in novelty.lower() else "nov-med" if "med" in novelty.lower() else "nov-low"

            col.markdown(
                f'<div class="card card-tech" style="height:auto">'
                f'<div style="font-weight:700;font-size:0.95rem;color:#e2e8f0;margin-bottom:6px">{title}</div>'
                f'<div style="color:#94a3b8;font-size:0.82rem;margin-bottom:10px">🏭 {company}</div>'
                f'<div style="color:#6b7280;font-size:0.78rem;margin-bottom:10px">📂 {cat}</div>'
                f'<div style="display:flex;gap:6px;flex-wrap:wrap">'
                f'<span class="badge {mat_cls}">⚙️ {maturity}</span>'
                f'<span class="badge {nov_cls}">✨ {novelty} Novelty</span>'
                f'</div>'
                f'</div>',
                unsafe_allow_html=True,
            )

        # ── Charts
        st.markdown("<br>", unsafe_allow_html=True)
        ch1, ch2 = st.columns(2)

        with ch1:
            st.markdown('<p class="section-header">Maturity Distribution</p>', unsafe_allow_html=True)
            df_t = pd.DataFrame(technologies)
            if "maturity" in df_t.columns:
                mat_counts = df_t["maturity"].value_counts()
                fig_mat = go.Figure(go.Pie(
                    labels=mat_counts.index,
                    values=mat_counts.values,
                    hole=0.55,
                    marker_colors=["#10b981", "#f59e0b", "#3b82f6"],
                    textfont=dict(color="#e2e8f0"),
                ))
                fig_mat.update_layout(
                    paper_bgcolor="#111827",
                    font=dict(color="#e2e8f0"),
                    height=260,
                    margin=dict(l=10, r=10, t=10, b=10),
                    legend=dict(bgcolor="#111827", font=dict(color="#94a3b8")),
                )
                st.plotly_chart(fig_mat, use_container_width=True)

        with ch2:
            st.markdown('<p class="section-header">Novelty Distribution</p>', unsafe_allow_html=True)
            if "novelty" in df_t.columns:
                nov_counts = df_t["novelty"].value_counts()
                fig_nov = go.Figure(go.Bar(
                    x=nov_counts.values,
                    y=nov_counts.index,
                    orientation="h",
                    marker_color=["#8b5cf6", "#f59e0b", "#94a3b8"],
                    text=nov_counts.values,
                    textposition="outside",
                    textfont=dict(color="#e2e8f0"),
                ))
                fig_nov.update_layout(
                    paper_bgcolor="#111827",
                    plot_bgcolor="#111827",
                    font=dict(color="#e2e8f0"),
                    xaxis=dict(gridcolor="#1e2a3d"),
                    yaxis=dict(color="#e2e8f0"),
                    height=260,
                    margin=dict(l=10, r=60, t=10, b=10),
                )
                st.plotly_chart(fig_nov, use_container_width=True)

        # Company ↔ Technology matrix
        st.markdown('<p class="section-header">Company — Technology Mapping</p>', unsafe_allow_html=True)
        if technologies:
            matrix_data = []
            company_techs: dict = {}
            for tech in technologies:
                cname = tech.get("company", "Unknown")
                company_techs.setdefault(cname, []).append(tech.get("title", "N/A"))
            for cname, techs_list in company_techs.items():
                matrix_data.append({
                    "Company":    cname,
                    "Technologies": ", ".join(techs_list),
                    "Count":      len(techs_list),
                })
            df_matrix = pd.DataFrame(matrix_data).sort_values("Count", ascending=False)
            fig_matrix = px.bar(
                df_matrix, x="Company", y="Count",
                color="Count",
                color_continuous_scale=[[0, "#3b82f6"], [1, "#8b5cf6"]],
                text="Count",
            )
            fig_matrix.update_layout(
                paper_bgcolor="#111827", plot_bgcolor="#111827",
                font=dict(color="#e2e8f0"),
                xaxis=dict(gridcolor="#1e2a3d", tickangle=-20),
                yaxis=dict(gridcolor="#1e2a3d"),
                height=320,
                margin=dict(l=10, r=10, t=10, b=80),
                coloraxis_showscale=False,
                showlegend=False,
            )
            fig_matrix.update_traces(textfont_color="#e2e8f0", textposition="outside")
            st.plotly_chart(fig_matrix, use_container_width=True)

    else:
        if tech_data.get("error"):
            st.error(f"Could not load technologies: {tech_data['error']}")
        else:
            st.info("No technologies match the selected filters.")

# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — ANALYTICS
# ══════════════════════════════════════════════════════════════════════════════
with tab_analytics:
    st.markdown('<p class="section-header">Session Analytics</p>', unsafe_allow_html=True)

    if not st.session_state.query_stats:
        st.markdown(
            '<div style="text-align:center;padding:60px;color:#4a5568">'
            '<div style="font-size:3rem">📊</div>'
            '<p style="color:#6b7280">Analytics will appear after you run some queries in the Chat tab.</p>'
            '</div>',
            unsafe_allow_html=True,
        )
    else:
        stats = st.session_state.query_stats
        df_stats = pd.DataFrame(stats)

        # ── Summary metrics
        total_q     = len(stats)
        llm_calls   = sum(1 for s in stats if s["llm"])
        avg_latency = sum(s["latency"] for s in stats) / max(len(stats), 1)
        llm_pct     = (llm_calls / max(total_q, 1)) * 100

        m1, m2, m3, m4 = st.columns(4)
        m1.markdown(f'<div class="metric-tile"><div class="metric-value">{total_q}</div><div class="metric-label">Total Queries</div></div>', unsafe_allow_html=True)
        m2.markdown(f'<div class="metric-tile"><div class="metric-value" style="color:#c084fc">{llm_calls}</div><div class="metric-label">LLM Calls</div></div>', unsafe_allow_html=True)
        m3.markdown(f'<div class="metric-tile"><div class="metric-value" style="color:#f59e0b">{llm_pct:.0f}%</div><div class="metric-label">LLM Usage Rate</div></div>', unsafe_allow_html=True)
        m4.markdown(f'<div class="metric-tile"><div class="metric-value" style="color:#10b981">{avg_latency:.0f}ms</div><div class="metric-label">Avg Latency</div></div>', unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        ac1, ac2 = st.columns(2)

        # Query type distribution
        with ac1:
            st.markdown('<p class="section-header">Query Type Breakdown</p>', unsafe_allow_html=True)
            type_dist = df_stats["type"].value_counts().reset_index()
            type_dist.columns = ["Type", "Count"]
            fig_types = px.bar(
                type_dist, x="Count", y="Type", orientation="h",
                color="Count",
                color_continuous_scale=[[0, "#3b82f6"], [1, "#8b5cf6"]],
                text="Count",
            )
            fig_types.update_layout(
                paper_bgcolor="#111827", plot_bgcolor="#111827",
                font=dict(color="#e2e8f0"),
                xaxis=dict(gridcolor="#1e2a3d"),
                yaxis=dict(autorange="reversed"),
                height=280,
                margin=dict(l=10, r=50, t=10, b=20),
                coloraxis_showscale=False,
            )
            fig_types.update_traces(textfont_color="#e2e8f0")
            st.plotly_chart(fig_types, use_container_width=True)

        # LLM vs No-LLM pie
        with ac2:
            st.markdown('<p class="section-header">LLM Usage Split</p>', unsafe_allow_html=True)
            llm_dist = df_stats["llm"].value_counts()
            labels  = ["LLM Used" if x else "No LLM" for x in llm_dist.index]
            fig_llm = go.Figure(go.Pie(
                labels=labels,
                values=llm_dist.values,
                hole=0.6,
                marker_colors=["#8b5cf6", "#3b82f6"],
                textfont=dict(color="#e2e8f0"),
            ))
            fig_llm.update_layout(
                paper_bgcolor="#111827",
                font=dict(color="#e2e8f0"),
                height=280,
                margin=dict(l=10, r=10, t=10, b=10),
                legend=dict(bgcolor="#111827", font=dict(color="#94a3b8")),
            )
            st.plotly_chart(fig_llm, use_container_width=True)

        # Latency over time
        st.markdown('<p class="section-header">Latency Over Time</p>', unsafe_allow_html=True)
        df_stats["Query #"] = range(1, len(df_stats) + 1)
        fig_lat = go.Figure()
        colors  = ["#ef4444" if r["llm"] else "#3b82f6" for _, r in df_stats.iterrows()]
        fig_lat.add_trace(go.Scatter(
            x=df_stats["Query #"],
            y=df_stats["latency"],
            mode="lines+markers",
            line=dict(color="#3b82f6", width=2),
            marker=dict(color=colors, size=9),
            name="Latency (ms)",
        ))
        # Add threshold line for LLM calls
        fig_lat.add_hline(
            y=500, line_dash="dash", line_color="#f59e0b", opacity=0.5,
            annotation_text="LLM threshold ~500ms",
            annotation_font_color="#f59e0b",
        )
        fig_lat.update_layout(
            paper_bgcolor="#111827", plot_bgcolor="#111827",
            font=dict(color="#e2e8f0"),
            xaxis=dict(title="Query #", gridcolor="#1e2a3d"),
            yaxis=dict(title="Latency (ms)", gridcolor="#1e2a3d"),
            height=280,
            margin=dict(l=40, r=20, t=20, b=40),
        )
        st.plotly_chart(fig_lat, use_container_width=True)
        st.caption("🔴 Red markers = LLM used   🔵 Blue markers = deterministic (no LLM)")

        # Query log table
        st.markdown('<p class="section-header">Query Log</p>', unsafe_allow_html=True)
        df_log = df_stats[["ts", "query", "type", "llm", "latency"]].copy()
        df_log.columns = ["Time", "Query", "Type", "LLM Used", "Latency (ms)"]
        df_log["LLM Used"] = df_log["LLM Used"].map({True: "✅ Yes", False: "⚡ No"})
        st.dataframe(
            df_log.sort_index(ascending=False),
            use_container_width=True,
            hide_index=True,
            height=250,
        )

    # ── LLM Cost Optimizer widget
    st.markdown('<p class="section-header" style="margin-top:20px">LLM Cost Optimization</p>', unsafe_allow_html=True)
    st.markdown("""
    <div style="background:#111827;border:1px solid #1e2a3d;border-radius:12px;padding:18px">
    <table style="width:100%;border-collapse:collapse;font-size:0.85rem;color:#94a3b8">
    <tr style="border-bottom:1px solid #1e2a3d">
        <th style="text-align:left;padding:8px;color:#e2e8f0">Query Type</th>
        <th style="text-align:center;padding:8px;color:#e2e8f0">LLM?</th>
        <th style="text-align:center;padding:8px;color:#e2e8f0">Approx Latency</th>
        <th style="text-align:center;padding:8px;color:#e2e8f0">Cost</th>
    </tr>
    <tr style="border-bottom:1px solid #1e2a3d">
        <td style="padding:8px">LOOKUP, FILTER, FACT, RELATIONSHIP, FINANCIAL, ACTIVITY</td>
        <td style="text-align:center;padding:8px"><span style="color:#34d399">❌ No</span></td>
        <td style="text-align:center;padding:8px">2–15ms</td>
        <td style="text-align:center;padding:8px"><span style="color:#34d399">$0.00</span></td>
    </tr>
    <tr>
        <td style="padding:8px">EXPLANATION, COMPARISON</td>
        <td style="text-align:center;padding:8px"><span style="color:#c084fc">✅ Yes</span></td>
        <td style="text-align:center;padding:8px">600–1400ms</td>
        <td style="text-align:center;padding:8px"><span style="color:#fbbf24">~$0.001/call</span></td>
    </tr>
    </table>
    <p style="color:#6b7280;font-size:0.78rem;margin-top:12px">
    ⚡ <b style="color:#e2e8f0">80% of queries</b> are resolved without any LLM call.<br>
    🤖 LLM (Groq LLaMA3-70b) is invoked <b style="color:#c084fc">only for synthesis and comparison</b>.<br>
    📉 Token minimization: context truncated to 3500 chars, temperature=0.1, max_tokens capped.
    </p>
    </div>
    """, unsafe_allow_html=True)
