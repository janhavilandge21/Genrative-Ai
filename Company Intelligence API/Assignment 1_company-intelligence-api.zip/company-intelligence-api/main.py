"""
main.py — FastAPI application entry point.

Startup sequence:
  1. Load environment config
  2. Load + index company and technology data
  3. Build or load FAISS vector indexes
  4. Warm up query engine singleton
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from loguru import logger

from app.api.routes import router
from app.core.data_loader import get_data_store
from app.core.vector_search import get_search_engine
from app.services.query_engine import get_query_engine
from app.utils.logger import setup_logger
from config.settings import get_settings


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ── Startup ───────────────────────────────────────────────────────────────
    settings = get_settings()
    setup_logger(settings.log_level)

    logger.info("=" * 55)
    logger.info("  Company Intelligence API  v1.0")
    logger.info("=" * 55)

    logger.info("Loading data...")
    store = get_data_store()
    logger.info(f"  {len(store.companies)} companies | "
                f"{len(store.technologies)} technologies")

    logger.info("Initializing FAISS search engine...")
    search = get_search_engine()
    search.build_or_load()

    logger.info("Warming up query engine...")
    get_query_engine()

    groq_ok = (
        bool(settings.groq_api_key)
        and settings.groq_api_key != "gsk_your_groq_key_here"
    )
    logger.info(f"Groq LLM: {'✅ configured' if groq_ok else '⚠️  NOT configured (add key to .env)'}")
    logger.info("=" * 55)
    logger.info("API ready — http://localhost:8000/docs")
    logger.info("=" * 55)

    yield

    # ── Shutdown ──────────────────────────────────────────────────────────────
    logger.info("Shutting down.")


app = FastAPI(
    title="Company Intelligence API",
    description=(
        "Natural language Q&A over structured company and technology data. "
        "Hybrid rule-based + FAISS semantic search + selective LLM system."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix="/api/v1")


@app.get("/", tags=["Root"])
def root():
    return {
        "service":  "Company Intelligence API",
        "version":  "1.0.0",
        "docs":     "http://localhost:8000/docs",
        "health":   "http://localhost:8000/api/v1/health",
        "query":    "POST /api/v1/query",
        "examples": [
            "How does Nexeed enable zero-defect production?",
            "Which technologies have High novelty?",
            "What technologies does Analog Devices have?",
            "Tell me about Robert Bosch",
            "How many commercialized technologies are there?",
        ],
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
